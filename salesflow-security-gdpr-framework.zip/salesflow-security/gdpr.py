"""
SalesFlow AI - GDPR Compliance Framework
========================================
Vollständige DSGVO-Implementierung für DACH-Markt.

Implementiert:
- Art. 15: Right to Access (Auskunftsrecht)
- Art. 17: Right to Erasure (Recht auf Löschung)
- Art. 20: Right to Data Portability
- Art. 25: Data Protection by Design
- Art. 30: Records of Processing Activities
"""

import json
import hashlib
import asyncio
from datetime import datetime, timedelta
from typing import Any, Optional, Dict, List, Set, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class DataCategory(Enum):
    """DSGVO Datenkategorien"""
    IDENTITY = "identity"              # Name, ID
    CONTACT = "contact"                # Email, Telefon, Adresse
    FINANCIAL = "financial"            # Umsätze, Provisionen
    BEHAVIORAL = "behavioral"          # Nutzungsverhalten, Aktivitäten
    HEALTH = "health"                  # Art. 9 - Gesundheitsdaten
    PREFERENCES = "preferences"        # Einstellungen, Präferenzen
    COMMUNICATIONS = "communications"  # Nachrichten, Gespräche
    AI_GENERATED = "ai_generated"      # KI-generierte Daten
    TECHNICAL = "technical"            # IP, User-Agent, Logs


class LegalBasis(Enum):
    """Rechtsgrundlagen nach Art. 6 DSGVO"""
    CONSENT = "consent"                      # Art. 6(1)(a) - Einwilligung
    CONTRACT = "contract"                    # Art. 6(1)(b) - Vertrag
    LEGAL_OBLIGATION = "legal_obligation"    # Art. 6(1)(c) - Rechtliche Verpflichtung
    VITAL_INTERESTS = "vital_interests"      # Art. 6(1)(d) - Lebenswichtige Interessen
    PUBLIC_INTEREST = "public_interest"      # Art. 6(1)(e) - Öffentliches Interesse
    LEGITIMATE_INTEREST = "legitimate_interest"  # Art. 6(1)(f) - Berechtigtes Interesse


class DeletionStatus(Enum):
    """Status der Löschoperation"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    PARTIALLY_COMPLETED = "partially_completed"
    FAILED = "failed"
    RETAINED_LEGAL = "retained_legal"  # Aufbewahrungspflicht


@dataclass
class DataSubjectRequest:
    """DSGVO Betroffenenanfrage"""
    request_id: str
    request_type: str  # access, erasure, rectification, portability
    user_id: str
    tenant_id: str
    requested_at: datetime
    requester_email: str
    verification_token: str
    verified_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    status: str = "pending"
    response_data: Optional[Dict] = None
    notes: List[str] = field(default_factory=list)
    
    @classmethod
    def create(
        cls,
        request_type: str,
        user_id: str,
        tenant_id: str,
        email: str
    ) -> 'DataSubjectRequest':
        return cls(
            request_id=str(uuid4()),
            request_type=request_type,
            user_id=user_id,
            tenant_id=tenant_id,
            requested_at=datetime.utcnow(),
            requester_email=email,
            verification_token=hashlib.sha256(
                f"{uuid4()}{datetime.utcnow()}".encode()
            ).hexdigest()[:32]
        )


@dataclass
class ProcessingActivity:
    """Verzeichnis von Verarbeitungstätigkeiten (Art. 30)"""
    activity_id: str
    name: str
    purpose: str
    legal_basis: LegalBasis
    data_categories: List[DataCategory]
    recipients: List[str]
    retention_period_days: int
    third_country_transfers: List[str]
    technical_measures: List[str]
    organizational_measures: List[str]
    dpia_required: bool = False
    dpia_conducted: bool = False
    last_review: Optional[datetime] = None


class DeletionCascade:
    """
    Kaskadierte Löschung aller User-Daten.
    
    Lösch-Reihenfolge (abhängigkeitsbasiert):
    1. AI Logs & Embeddings
    2. Message Summaries
    3. Messages
    4. Conversations
    5. Events & Activities
    6. Leads & Contacts
    7. Financial Records
    8. User Account
    """
    
    # Lösch-Reihenfolge mit Abhängigkeiten
    DELETION_ORDER = [
        ("ai_logs", "AI-generierte Logs und Embeddings"),
        ("ai_summaries", "KI-Zusammenfassungen"),
        ("messages", "Chat-Nachrichten"),
        ("conversations", "Konversationen"),
        ("events", "Termine und Events"),
        ("activities", "Aktivitäts-Logs"),
        ("leads", "Lead-Daten"),
        ("contacts", "Kontakt-Daten"),
        ("financial_records", "Finanzdaten"),
        ("consent_records", "Einwilligungen"),
        ("user_preferences", "Benutzer-Präferenzen"),
        ("user_account", "Benutzerkonto"),
    ]
    
    # Felder mit Aufbewahrungspflicht (nicht löschbar)
    RETENTION_REQUIRED = {
        "financial_records": {
            "fields": ["invoice_id", "amount", "date", "tax_info"],
            "reason": "Steuerrechtliche Aufbewahrungspflicht (§147 AO)",
            "retention_years": 10
        },
        "consent_records": {
            "fields": ["consent_id", "granted_at", "scope"],
            "reason": "Nachweispflicht für Einwilligungen",
            "retention_years": 3
        }
    }
    
    def __init__(self, db_session):
        self.db = db_session
        self._deletion_handlers: Dict[str, Callable] = {}
        self._register_default_handlers()
    
    def _register_default_handlers(self):
        """Registriert Standard-Lösch-Handler"""
        self._deletion_handlers = {
            "ai_logs": self._delete_ai_logs,
            "ai_summaries": self._delete_ai_summaries,
            "messages": self._delete_messages,
            "conversations": self._delete_conversations,
            "events": self._delete_events,
            "activities": self._delete_activities,
            "leads": self._delete_leads,
            "contacts": self._delete_contacts,
            "financial_records": self._delete_financial_records,
            "consent_records": self._delete_consent_records,
            "user_preferences": self._delete_user_preferences,
            "user_account": self._delete_user_account,
        }
    
    async def execute_deletion(
        self,
        user_id: str,
        tenant_id: str,
        request: DataSubjectRequest
    ) -> Dict[str, Any]:
        """
        Führt vollständige Löschkaskade aus.
        
        Returns:
            Lösch-Report mit Status pro Kategorie
        """
        report = {
            "request_id": request.request_id,
            "user_id": user_id,
            "tenant_id": tenant_id,
            "started_at": datetime.utcnow().isoformat(),
            "categories": {},
            "retained_data": [],
            "errors": []
        }
        
        for category, description in self.DELETION_ORDER:
            try:
                logger.info(f"Lösche {category} für User {user_id}")
                
                handler = self._deletion_handlers.get(category)
                if not handler:
                    report["errors"].append(f"Kein Handler für {category}")
                    continue
                
                # Prüfe Aufbewahrungspflicht
                if category in self.RETENTION_REQUIRED:
                    retained = await self._handle_retention(
                        category, user_id, tenant_id
                    )
                    if retained:
                        report["retained_data"].append(retained)
                
                # Führe Löschung aus
                result = await handler(user_id, tenant_id)
                
                report["categories"][category] = {
                    "status": "deleted",
                    "count": result.get("deleted_count", 0),
                    "description": description
                }
                
            except Exception as e:
                logger.error(f"Fehler bei Löschung {category}: {e}")
                report["categories"][category] = {
                    "status": "error",
                    "error": str(e)
                }
                report["errors"].append(f"{category}: {str(e)}")
        
        report["completed_at"] = datetime.utcnow().isoformat()
        report["success"] = len(report["errors"]) == 0
        
        return report
    
    async def _handle_retention(
        self,
        category: str,
        user_id: str,
        tenant_id: str
    ) -> Optional[Dict]:
        """
        Handhabt Aufbewahrungspflichten.
        Anonymisiert statt löscht, behält nur rechtlich notwendige Daten.
        """
        retention_info = self.RETENTION_REQUIRED[category]
        
        # Anonymisiere personenbezogene Daten, behalte rechtlich notwendige
        return {
            "category": category,
            "reason": retention_info["reason"],
            "retention_until": (
                datetime.utcnow() + 
                timedelta(days=retention_info["retention_years"] * 365)
            ).isoformat(),
            "retained_fields": retention_info["fields"]
        }
    
    # Lösch-Handler für jede Kategorie
    async def _delete_ai_logs(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht AI-Logs und Embeddings"""
        # DELETE FROM ai_logs WHERE user_id = ? AND tenant_id = ?
        # DELETE FROM embeddings WHERE user_id = ? AND tenant_id = ?
        return {"deleted_count": 0}  # Placeholder
    
    async def _delete_ai_summaries(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht AI-generierte Zusammenfassungen"""
        return {"deleted_count": 0}
    
    async def _delete_messages(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Chat-Nachrichten"""
        return {"deleted_count": 0}
    
    async def _delete_conversations(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Konversationen"""
        return {"deleted_count": 0}
    
    async def _delete_events(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Events und Termine"""
        return {"deleted_count": 0}
    
    async def _delete_activities(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Aktivitäts-Logs"""
        return {"deleted_count": 0}
    
    async def _delete_leads(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Lead-Daten"""
        return {"deleted_count": 0}
    
    async def _delete_contacts(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Kontakt-Daten"""
        return {"deleted_count": 0}
    
    async def _delete_financial_records(self, user_id: str, tenant_id: str) -> Dict:
        """Anonymisiert Finanzdaten (Aufbewahrungspflicht)"""
        return {"deleted_count": 0, "anonymized": True}
    
    async def _delete_consent_records(self, user_id: str, tenant_id: str) -> Dict:
        """Archiviert Einwilligungen (Nachweispflicht)"""
        return {"deleted_count": 0, "archived": True}
    
    async def _delete_user_preferences(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht Benutzer-Präferenzen"""
        return {"deleted_count": 0}
    
    async def _delete_user_account(self, user_id: str, tenant_id: str) -> Dict:
        """Löscht/Anonymisiert Benutzerkonto"""
        return {"deleted_count": 1}


class DataExporter:
    """
    DSGVO Art. 20 - Recht auf Datenübertragbarkeit.
    Exportiert alle User-Daten in maschinenlesbarem Format.
    """
    
    EXPORT_CATEGORIES = [
        "profile",
        "contacts",
        "leads",
        "conversations",
        "messages",
        "events",
        "activities",
        "preferences",
        "consents",
        "ai_interactions"
    ]
    
    def __init__(self, db_session, encryption_proxy=None):
        self.db = db_session
        self.encryption = encryption_proxy
    
    async def export_user_data(
        self,
        user_id: str,
        tenant_id: str,
        include_categories: Optional[List[str]] = None,
        format: str = "json"
    ) -> Dict[str, Any]:
        """
        Exportiert alle User-Daten für DSGVO Auskunft.
        
        Args:
            user_id: User ID
            tenant_id: Tenant ID
            include_categories: Welche Kategorien (None = alle)
            format: Export-Format (json, csv)
            
        Returns:
            Strukturierter Export aller Daten
        """
        categories = include_categories or self.EXPORT_CATEGORIES
        
        export = {
            "export_metadata": {
                "version": "1.0",
                "format": format,
                "exported_at": datetime.utcnow().isoformat(),
                "user_id": user_id,
                "tenant_id": tenant_id,
                "categories_included": categories,
                "gdpr_reference": "Art. 15, 20 DSGVO"
            },
            "data": {}
        }
        
        for category in categories:
            exporter = getattr(self, f"_export_{category}", None)
            if exporter:
                try:
                    data = await exporter(user_id, tenant_id)
                    # Entschlüssele sensitive Felder für Export
                    if self.encryption:
                        data = self._decrypt_sensitive_data(data, category)
                    export["data"][category] = data
                except Exception as e:
                    logger.error(f"Export-Fehler für {category}: {e}")
                    export["data"][category] = {"error": str(e)}
        
        return export
    
    def _decrypt_sensitive_data(
        self,
        data: Any,
        category: str
    ) -> Any:
        """Entschlüsselt sensitive Felder für Export"""
        if isinstance(data, list):
            return [self._decrypt_sensitive_data(item, category) for item in data]
        elif isinstance(data, dict):
            result = {}
            for key, value in data.items():
                if isinstance(value, str) and value.startswith("$ENC$"):
                    result[key] = self.encryption.decrypt_field(value)
                else:
                    result[key] = self._decrypt_sensitive_data(value, category)
            return result
        return data
    
    # Export-Handler für jede Kategorie
    async def _export_profile(self, user_id: str, tenant_id: str) -> Dict:
        """Exportiert Profildaten"""
        return {
            "user_id": user_id,
            "account_created": None,  # From DB
            "last_login": None,
            "profile_data": {}
        }
    
    async def _export_contacts(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Kontakte"""
        return []
    
    async def _export_leads(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Leads"""
        return []
    
    async def _export_conversations(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Konversationen"""
        return []
    
    async def _export_messages(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Nachrichten"""
        return []
    
    async def _export_events(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Events"""
        return []
    
    async def _export_activities(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Aktivitäten"""
        return []
    
    async def _export_preferences(self, user_id: str, tenant_id: str) -> Dict:
        """Exportiert Präferenzen"""
        return {}
    
    async def _export_consents(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert Einwilligungen"""
        return []
    
    async def _export_ai_interactions(self, user_id: str, tenant_id: str) -> List[Dict]:
        """Exportiert AI-Interaktionen"""
        return []


class DataMinimizer:
    """
    Data Minimization für AI-Calls.
    Entfernt unnötige PII aus AI-Kontext.
    """
    
    # PII-Felder die aus AI-Kontext entfernt werden
    PII_FIELDS = {
        "email", "phone", "phone_number", "mobile",
        "address", "street", "city", "postal_code", "zip",
        "ssn", "social_security", "tax_id",
        "credit_card", "card_number", "cvv", "iban",
        "date_of_birth", "birthday", "dob",
        "passport", "id_number", "license_number"
    }
    
    # Patterns für PII-Erkennung
    PII_PATTERNS = [
        (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL]'),
        (r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', '[PHONE]'),
        (r'\b\d{5}\b', '[ZIP]'),
        (r'\bDE\d{2}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{2}\b', '[IBAN]'),
        (r'\b\d{2}[./-]\d{2}[./-]\d{4}\b', '[DATE]'),
    ]
    
    def __init__(self):
        import re
        self._patterns = [
            (re.compile(pattern, re.IGNORECASE), replacement)
            for pattern, replacement in self.PII_PATTERNS
        ]
    
    def minimize_for_ai(
        self,
        data: Dict[str, Any],
        preserve_fields: Optional[Set[str]] = None
    ) -> Dict[str, Any]:
        """
        Minimiert Daten für AI-Verarbeitung.
        
        Args:
            data: Input-Daten
            preserve_fields: Felder die behalten werden sollen
            
        Returns:
            Minimierte Daten ohne unnötige PII
        """
        preserve = preserve_fields or set()
        result = {}
        
        for key, value in data.items():
            # Behalte explizit gewünschte Felder
            if key in preserve:
                result[key] = value
                continue
            
            # Entferne PII-Felder
            if key.lower() in self.PII_FIELDS:
                result[key] = f"[REDACTED:{key.upper()}]"
                continue
            
            # Rekursive Verarbeitung
            if isinstance(value, dict):
                result[key] = self.minimize_for_ai(value, preserve)
            elif isinstance(value, list):
                result[key] = [
                    self.minimize_for_ai(item, preserve) 
                    if isinstance(item, dict) else self._redact_string(item)
                    for item in value
                ]
            elif isinstance(value, str):
                result[key] = self._redact_string(value)
            else:
                result[key] = value
        
        return result
    
    def _redact_string(self, text: str) -> str:
        """Entfernt PII aus String via Regex"""
        if not isinstance(text, str):
            return text
        
        result = text
        for pattern, replacement in self._patterns:
            result = pattern.sub(replacement, result)
        
        return result
    
    def create_ai_context(
        self,
        lead_data: Dict,
        conversation_history: List[Dict],
        user_preferences: Dict
    ) -> Dict[str, Any]:
        """
        Erstellt minimalen AI-Kontext für Lead-Analyse.
        
        Behält:
        - Relevante Business-Informationen
        - Konversations-Kontext
        - Präferenzen
        
        Entfernt:
        - Direkte Kontaktdaten
        - Finanzielle Details
        - Sensitive persönliche Informationen
        """
        return {
            "lead_context": self.minimize_for_ai(
                lead_data,
                preserve_fields={"status", "source", "interests", "tags"}
            ),
            "conversation_summary": self._summarize_conversation(conversation_history),
            "user_context": self.minimize_for_ai(
                user_preferences,
                preserve_fields={"language", "timezone", "communication_style"}
            )
        }
    
    def _summarize_conversation(
        self,
        history: List[Dict],
        max_messages: int = 10
    ) -> List[Dict]:
        """Erstellt minimale Konversations-Zusammenfassung"""
        recent = history[-max_messages:] if len(history) > max_messages else history
        
        return [
            {
                "role": msg.get("role", "unknown"),
                "content": self._redact_string(msg.get("content", "")[:500]),
                "timestamp": msg.get("timestamp")
            }
            for msg in recent
        ]


class GDPRComplianceManager:
    """
    Zentrale DSGVO-Compliance-Verwaltung.
    Koordiniert alle Compliance-Operationen.
    """
    
    def __init__(
        self,
        db_session,
        encryption_proxy=None,
        audit_logger=None
    ):
        self.db = db_session
        self.deletion_cascade = DeletionCascade(db_session)
        self.data_exporter = DataExporter(db_session, encryption_proxy)
        self.data_minimizer = DataMinimizer()
        self.audit = audit_logger
        self._pending_requests: Dict[str, DataSubjectRequest] = {}
    
    async def create_access_request(
        self,
        user_id: str,
        tenant_id: str,
        email: str
    ) -> DataSubjectRequest:
        """
        Erstellt Auskunftsanfrage (Art. 15).
        Muss innerhalb 30 Tagen beantwortet werden.
        """
        request = DataSubjectRequest.create(
            request_type="access",
            user_id=user_id,
            tenant_id=tenant_id,
            email=email
        )
        
        self._pending_requests[request.request_id] = request
        
        if self.audit:
            await self.audit.log(
                action="gdpr_access_request_created",
                user_id=user_id,
                tenant_id=tenant_id,
                details={"request_id": request.request_id}
            )
        
        return request
    
    async def fulfill_access_request(
        self,
        request_id: str
    ) -> Dict[str, Any]:
        """Erfüllt Auskunftsanfrage"""
        request = self._pending_requests.get(request_id)
        if not request:
            raise ValueError(f"Request {request_id} nicht gefunden")
        
        if not request.verified_at:
            raise ValueError("Request nicht verifiziert")
        
        export = await self.data_exporter.export_user_data(
            user_id=request.user_id,
            tenant_id=request.tenant_id
        )
        
        request.completed_at = datetime.utcnow()
        request.status = "completed"
        request.response_data = export
        
        return export
    
    async def create_deletion_request(
        self,
        user_id: str,
        tenant_id: str,
        email: str
    ) -> DataSubjectRequest:
        """
        Erstellt Löschanfrage (Art. 17).
        """
        request = DataSubjectRequest.create(
            request_type="erasure",
            user_id=user_id,
            tenant_id=tenant_id,
            email=email
        )
        
        self._pending_requests[request.request_id] = request
        
        if self.audit:
            await self.audit.log(
                action="gdpr_erasure_request_created",
                user_id=user_id,
                tenant_id=tenant_id,
                details={"request_id": request.request_id}
            )
        
        return request
    
    async def execute_deletion_request(
        self,
        request_id: str
    ) -> Dict[str, Any]:
        """Führt Löschanfrage aus"""
        request = self._pending_requests.get(request_id)
        if not request:
            raise ValueError(f"Request {request_id} nicht gefunden")
        
        if not request.verified_at:
            raise ValueError("Request nicht verifiziert")
        
        report = await self.deletion_cascade.execute_deletion(
            user_id=request.user_id,
            tenant_id=request.tenant_id,
            request=request
        )
        
        request.completed_at = datetime.utcnow()
        request.status = "completed" if report["success"] else "partially_completed"
        
        if self.audit:
            await self.audit.log(
                action="gdpr_erasure_executed",
                user_id=request.user_id,
                tenant_id=request.tenant_id,
                details=report
            )
        
        return report
    
    def verify_request(
        self,
        request_id: str,
        token: str
    ) -> bool:
        """Verifiziert Betroffenenanfrage"""
        request = self._pending_requests.get(request_id)
        if not request:
            return False
        
        if request.verification_token == token:
            request.verified_at = datetime.utcnow()
            return True
        
        return False
    
    def get_request_status(self, request_id: str) -> Optional[Dict]:
        """Gibt Status einer Anfrage zurück"""
        request = self._pending_requests.get(request_id)
        if not request:
            return None
        
        return {
            "request_id": request.request_id,
            "type": request.request_type,
            "status": request.status,
            "requested_at": request.requested_at.isoformat(),
            "verified": request.verified_at is not None,
            "completed": request.completed_at is not None,
            "deadline": (
                request.requested_at + timedelta(days=30)
            ).isoformat()
        }
