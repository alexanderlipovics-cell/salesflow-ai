"""
SalesFlow AI - Audit Logging System
====================================
Vollständiges Audit-Trail für DSGVO-Compliance und SOC 2.

Features:
- Immutable Audit Logs
- Tamper Detection via Hash Chain
- Real-time Streaming
- Retention Management
- Query & Reporting
"""

import json
import hashlib
import asyncio
from datetime import datetime, timedelta
from typing import Any, Optional, Dict, List, Callable, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
from uuid import uuid4
import logging
from collections import deque
import threading

logger = logging.getLogger(__name__)


class AuditAction(Enum):
    """Kategorisierte Audit-Aktionen"""
    # Authentication
    AUTH_LOGIN = "auth.login"
    AUTH_LOGOUT = "auth.logout"
    AUTH_FAILED = "auth.failed"
    AUTH_MFA_ENABLED = "auth.mfa_enabled"
    AUTH_PASSWORD_CHANGED = "auth.password_changed"
    AUTH_API_KEY_CREATED = "auth.api_key_created"
    AUTH_API_KEY_REVOKED = "auth.api_key_revoked"
    
    # Data Access
    DATA_READ = "data.read"
    DATA_CREATE = "data.create"
    DATA_UPDATE = "data.update"
    DATA_DELETE = "data.delete"
    DATA_EXPORT = "data.export"
    DATA_IMPORT = "data.import"
    DATA_BULK_OPERATION = "data.bulk_operation"
    
    # Sensitive Data
    SENSITIVE_ACCESS = "sensitive.access"
    SENSITIVE_DECRYPT = "sensitive.decrypt"
    SENSITIVE_EXPORT = "sensitive.export"
    
    # GDPR
    GDPR_ACCESS_REQUEST = "gdpr.access_request"
    GDPR_DELETION_REQUEST = "gdpr.deletion_request"
    GDPR_CONSENT_GRANTED = "gdpr.consent_granted"
    GDPR_CONSENT_REVOKED = "gdpr.consent_revoked"
    GDPR_DATA_EXPORTED = "gdpr.data_exported"
    
    # Admin
    ADMIN_USER_CREATED = "admin.user_created"
    ADMIN_USER_MODIFIED = "admin.user_modified"
    ADMIN_USER_DELETED = "admin.user_deleted"
    ADMIN_ROLE_CHANGED = "admin.role_changed"
    ADMIN_SETTINGS_CHANGED = "admin.settings_changed"
    
    # Security
    SECURITY_PERMISSION_DENIED = "security.permission_denied"
    SECURITY_RATE_LIMITED = "security.rate_limited"
    SECURITY_SUSPICIOUS_ACTIVITY = "security.suspicious_activity"
    SECURITY_KEY_ROTATED = "security.key_rotated"
    
    # AI
    AI_QUERY = "ai.query"
    AI_RESPONSE = "ai.response"
    AI_CONTEXT_ACCESSED = "ai.context_accessed"


class AuditSeverity(Enum):
    """Severity Levels für Audit Events"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AuditEntry:
    """Einzelner Audit-Log-Eintrag"""
    entry_id: str
    timestamp: datetime
    action: str
    severity: AuditSeverity
    
    # Actor Information
    user_id: Optional[str]
    tenant_id: str
    session_id: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    
    # Target Information
    resource_type: Optional[str]
    resource_id: Optional[str]
    
    # Details
    details: Dict[str, Any]
    
    # Integrity
    previous_hash: Optional[str]
    entry_hash: str
    
    # Metadata
    request_id: Optional[str] = None
    correlation_id: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """Konvertiert zu Dictionary"""
        result = asdict(self)
        result["timestamp"] = self.timestamp.isoformat()
        result["severity"] = self.severity.value
        return result
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'AuditEntry':
        """Erstellt aus Dictionary"""
        data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        data["severity"] = AuditSeverity(data["severity"])
        return cls(**data)


class HashChain:
    """
    Hash Chain für Tamper Detection.
    Jeder Eintrag enthält Hash des vorherigen Eintrags.
    """
    
    def __init__(self, algorithm: str = "sha256"):
        self.algorithm = algorithm
        self._last_hash: Optional[str] = None
        self._lock = threading.Lock()
    
    def compute_hash(self, entry: AuditEntry) -> str:
        """Berechnet Hash für Entry"""
        # Hash-relevant fields (ohne entry_hash selbst)
        hash_data = {
            "entry_id": entry.entry_id,
            "timestamp": entry.timestamp.isoformat(),
            "action": entry.action,
            "user_id": entry.user_id,
            "tenant_id": entry.tenant_id,
            "resource_type": entry.resource_type,
            "resource_id": entry.resource_id,
            "details": entry.details,
            "previous_hash": entry.previous_hash
        }
        
        serialized = json.dumps(hash_data, sort_keys=True)
        return hashlib.sha256(serialized.encode()).hexdigest()
    
    def chain_entry(self, entry: AuditEntry) -> AuditEntry:
        """Fügt Entry zur Hash Chain hinzu"""
        with self._lock:
            entry.previous_hash = self._last_hash
            entry.entry_hash = self.compute_hash(entry)
            self._last_hash = entry.entry_hash
            return entry
    
    def verify_chain(self, entries: List[AuditEntry]) -> bool:
        """Verifiziert Integrität der Hash Chain"""
        if not entries:
            return True
        
        for i, entry in enumerate(entries):
            # Verify hash
            expected_hash = self.compute_hash(entry)
            if entry.entry_hash != expected_hash:
                logger.error(f"Hash mismatch at entry {entry.entry_id}")
                return False
            
            # Verify chain linkage
            if i > 0:
                if entry.previous_hash != entries[i-1].entry_hash:
                    logger.error(f"Chain break at entry {entry.entry_id}")
                    return False
        
        return True


class AuditStorage:
    """
    Abstract Base für Audit Storage Backends.
    """
    
    async def store(self, entry: AuditEntry) -> None:
        raise NotImplementedError
    
    async def query(
        self,
        tenant_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        actions: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[AuditEntry]:
        raise NotImplementedError
    
    async def get_by_id(self, entry_id: str) -> Optional[AuditEntry]:
        raise NotImplementedError


class InMemoryAuditStorage(AuditStorage):
    """In-Memory Storage für Development/Testing"""
    
    def __init__(self, max_entries: int = 100000):
        self._entries: Dict[str, AuditEntry] = {}
        self._by_tenant: Dict[str, List[str]] = {}
        self._max_entries = max_entries
        self._lock = asyncio.Lock()
    
    async def store(self, entry: AuditEntry) -> None:
        async with self._lock:
            self._entries[entry.entry_id] = entry
            
            if entry.tenant_id not in self._by_tenant:
                self._by_tenant[entry.tenant_id] = []
            self._by_tenant[entry.tenant_id].append(entry.entry_id)
            
            # Cleanup wenn zu viele Entries
            if len(self._entries) > self._max_entries:
                oldest_ids = list(self._entries.keys())[:1000]
                for eid in oldest_ids:
                    del self._entries[eid]
    
    async def query(
        self,
        tenant_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        actions: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[AuditEntry]:
        entry_ids = self._by_tenant.get(tenant_id, [])
        entries = [self._entries[eid] for eid in entry_ids if eid in self._entries]
        
        # Filter
        if start_time:
            entries = [e for e in entries if e.timestamp >= start_time]
        if end_time:
            entries = [e for e in entries if e.timestamp <= end_time]
        if actions:
            entries = [e for e in entries if e.action in actions]
        if user_id:
            entries = [e for e in entries if e.user_id == user_id]
        if resource_type:
            entries = [e for e in entries if e.resource_type == resource_type]
        
        # Sort by timestamp desc
        entries.sort(key=lambda e: e.timestamp, reverse=True)
        
        return entries[offset:offset + limit]
    
    async def get_by_id(self, entry_id: str) -> Optional[AuditEntry]:
        return self._entries.get(entry_id)


class AuditLogger:
    """
    Haupt-Audit-Logger mit async Support.
    """
    
    def __init__(
        self,
        storage: AuditStorage,
        enable_hash_chain: bool = True,
        buffer_size: int = 100,
        flush_interval: float = 5.0
    ):
        self._storage = storage
        self._hash_chain = HashChain() if enable_hash_chain else None
        self._buffer: deque = deque(maxlen=buffer_size)
        self._flush_interval = flush_interval
        self._flush_task: Optional[asyncio.Task] = None
        self._subscribers: List[Callable[[AuditEntry], None]] = []
        self._running = False
    
    async def start(self):
        """Startet Background Flush Task"""
        self._running = True
        self._flush_task = asyncio.create_task(self._flush_loop())
    
    async def stop(self):
        """Stoppt Logger und flusht Buffer"""
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self._flush_buffer()
    
    async def _flush_loop(self):
        """Background Flush Loop"""
        while self._running:
            await asyncio.sleep(self._flush_interval)
            await self._flush_buffer()
    
    async def _flush_buffer(self):
        """Flusht Buffer zu Storage"""
        while self._buffer:
            entry = self._buffer.popleft()
            try:
                await self._storage.store(entry)
            except Exception as e:
                logger.error(f"Failed to store audit entry: {e}")
                # Re-add to buffer on failure
                self._buffer.appendleft(entry)
                break
    
    def subscribe(self, callback: Callable[[AuditEntry], None]):
        """Registriert Subscriber für Real-time Events"""
        self._subscribers.append(callback)
    
    def _notify_subscribers(self, entry: AuditEntry):
        """Benachrichtigt alle Subscriber"""
        for callback in self._subscribers:
            try:
                callback(entry)
            except Exception as e:
                logger.error(f"Subscriber error: {e}")
    
    async def log(
        self,
        action: Union[AuditAction, str],
        tenant_id: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        severity: AuditSeverity = AuditSeverity.INFO,
        request_id: Optional[str] = None,
        correlation_id: Optional[str] = None
    ) -> AuditEntry:
        """
        Erstellt neuen Audit-Log-Eintrag.
        
        Args:
            action: Audit-Aktion (AuditAction oder String)
            tenant_id: Tenant ID
            user_id: Optional User ID
            session_id: Optional Session ID
            ip_address: Optional Client IP
            user_agent: Optional User Agent
            resource_type: Typ der betroffenen Ressource
            resource_id: ID der betroffenen Ressource
            details: Zusätzliche Details
            severity: Severity Level
            request_id: Request ID für Tracing
            correlation_id: Correlation ID für verteilte Systeme
            
        Returns:
            Erstellter AuditEntry
        """
        action_str = action.value if isinstance(action, AuditAction) else action
        
        entry = AuditEntry(
            entry_id=str(uuid4()),
            timestamp=datetime.utcnow(),
            action=action_str,
            severity=severity,
            user_id=user_id,
            tenant_id=tenant_id,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details or {},
            previous_hash=None,
            entry_hash="",
            request_id=request_id,
            correlation_id=correlation_id
        )
        
        # Hash Chain Integration
        if self._hash_chain:
            entry = self._hash_chain.chain_entry(entry)
        else:
            entry.entry_hash = hashlib.sha256(
                json.dumps(entry.to_dict(), sort_keys=True).encode()
            ).hexdigest()
        
        # Buffer für async Storage
        self._buffer.append(entry)
        
        # Notify Subscribers (synchron)
        self._notify_subscribers(entry)
        
        return entry
    
    async def query(
        self,
        tenant_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        actions: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[AuditEntry]:
        """Query Audit Logs"""
        return await self._storage.query(
            tenant_id=tenant_id,
            start_time=start_time,
            end_time=end_time,
            actions=actions,
            user_id=user_id,
            resource_type=resource_type,
            limit=limit,
            offset=offset
        )
    
    async def verify_integrity(
        self,
        tenant_id: str,
        start_time: datetime,
        end_time: datetime
    ) -> Dict[str, Any]:
        """
        Verifiziert Integrität der Audit Logs.
        
        Returns:
            Verification Report
        """
        entries = await self._storage.query(
            tenant_id=tenant_id,
            start_time=start_time,
            end_time=end_time,
            limit=10000
        )
        
        # Sort chronologically for chain verification
        entries.sort(key=lambda e: e.timestamp)
        
        is_valid = True
        issues = []
        
        if self._hash_chain:
            is_valid = self._hash_chain.verify_chain(entries)
            if not is_valid:
                issues.append("Hash chain verification failed")
        
        return {
            "verified": is_valid,
            "entries_checked": len(entries),
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "issues": issues
        }


class AuditQueryBuilder:
    """Fluent API für Audit Queries"""
    
    def __init__(self, logger: AuditLogger, tenant_id: str):
        self._logger = logger
        self._tenant_id = tenant_id
        self._start_time: Optional[datetime] = None
        self._end_time: Optional[datetime] = None
        self._actions: Optional[List[str]] = None
        self._user_id: Optional[str] = None
        self._resource_type: Optional[str] = None
        self._limit: int = 100
        self._offset: int = 0
    
    def since(self, time: datetime) -> 'AuditQueryBuilder':
        self._start_time = time
        return self
    
    def until(self, time: datetime) -> 'AuditQueryBuilder':
        self._end_time = time
        return self
    
    def last_hours(self, hours: int) -> 'AuditQueryBuilder':
        self._start_time = datetime.utcnow() - timedelta(hours=hours)
        return self
    
    def last_days(self, days: int) -> 'AuditQueryBuilder':
        self._start_time = datetime.utcnow() - timedelta(days=days)
        return self
    
    def for_user(self, user_id: str) -> 'AuditQueryBuilder':
        self._user_id = user_id
        return self
    
    def for_resource(self, resource_type: str) -> 'AuditQueryBuilder':
        self._resource_type = resource_type
        return self
    
    def with_actions(self, *actions: Union[AuditAction, str]) -> 'AuditQueryBuilder':
        self._actions = [
            a.value if isinstance(a, AuditAction) else a 
            for a in actions
        ]
        return self
    
    def limit(self, n: int) -> 'AuditQueryBuilder':
        self._limit = n
        return self
    
    def offset(self, n: int) -> 'AuditQueryBuilder':
        self._offset = n
        return self
    
    async def execute(self) -> List[AuditEntry]:
        return await self._logger.query(
            tenant_id=self._tenant_id,
            start_time=self._start_time,
            end_time=self._end_time,
            actions=self._actions,
            user_id=self._user_id,
            resource_type=self._resource_type,
            limit=self._limit,
            offset=self._offset
        )


class SensitiveDataAccessLogger:
    """
    Spezialisierter Logger für Zugriffe auf sensitive Daten.
    Automatische Alerts bei verdächtigen Mustern.
    """
    
    def __init__(
        self,
        audit_logger: AuditLogger,
        alert_threshold: int = 10,
        alert_window_minutes: int = 5
    ):
        self._audit = audit_logger
        self._access_counts: Dict[str, List[datetime]] = {}
        self._threshold = alert_threshold
        self._window = timedelta(minutes=alert_window_minutes)
        self._alert_callbacks: List[Callable] = []
    
    def on_alert(self, callback: Callable):
        """Registriert Alert Callback"""
        self._alert_callbacks.append(callback)
    
    async def log_access(
        self,
        tenant_id: str,
        user_id: str,
        resource_type: str,
        resource_id: str,
        field_name: str,
        access_reason: str,
        ip_address: Optional[str] = None
    ):
        """Loggt Zugriff auf sensitive Daten"""
        await self._audit.log(
            action=AuditAction.SENSITIVE_ACCESS,
            tenant_id=tenant_id,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            ip_address=ip_address,
            severity=AuditSeverity.WARNING,
            details={
                "field": field_name,
                "reason": access_reason
            }
        )
        
        # Track für Anomalie-Detection
        await self._track_access(user_id, tenant_id)
    
    async def _track_access(self, user_id: str, tenant_id: str):
        """Trackt Zugriffe für Anomalie-Detection"""
        key = f"{tenant_id}:{user_id}"
        now = datetime.utcnow()
        
        if key not in self._access_counts:
            self._access_counts[key] = []
        
        # Cleanup alte Einträge
        cutoff = now - self._window
        self._access_counts[key] = [
            t for t in self._access_counts[key] 
            if t > cutoff
        ]
        
        # Neuen Zugriff hinzufügen
        self._access_counts[key].append(now)
        
        # Alert wenn Threshold überschritten
        if len(self._access_counts[key]) >= self._threshold:
            await self._trigger_alert(user_id, tenant_id)
    
    async def _trigger_alert(self, user_id: str, tenant_id: str):
        """Triggert Alert für verdächtiges Muster"""
        await self._audit.log(
            action=AuditAction.SECURITY_SUSPICIOUS_ACTIVITY,
            tenant_id=tenant_id,
            user_id=user_id,
            severity=AuditSeverity.CRITICAL,
            details={
                "type": "excessive_sensitive_access",
                "threshold": self._threshold,
                "window_minutes": self._window.seconds // 60
            }
        )
        
        for callback in self._alert_callbacks:
            try:
                callback(user_id, tenant_id, "excessive_sensitive_access")
            except Exception as e:
                logger.error(f"Alert callback error: {e}")


# Factory Function
def create_audit_system(
    enable_hash_chain: bool = True
) -> Tuple[AuditLogger, SensitiveDataAccessLogger]:
    """
    Factory für Audit System.
    
    Returns:
        Tuple mit AuditLogger und SensitiveDataAccessLogger
    """
    storage = InMemoryAuditStorage()
    audit_logger = AuditLogger(storage, enable_hash_chain=enable_hash_chain)
    sensitive_logger = SensitiveDataAccessLogger(audit_logger)
    
    return audit_logger, sensitive_logger
