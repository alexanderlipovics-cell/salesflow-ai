"""
SalesFlow AI - Advanced Rate Limiting System
============================================
Multi-Tier Rate Limiting für Enterprise Security.

Features:
- Per-Tenant Limits
- Per-Endpoint Limits
- Per-User Limits
- Sliding Window Algorithm
- Token Bucket für Bursts
- Distributed Rate Limiting (Redis-ready)
- AI-Injection Protection
"""

import time
import asyncio
import hashlib
import re
from datetime import datetime, timedelta
from typing import Any, Optional, Dict, List, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import threading
import logging

logger = logging.getLogger(__name__)


class RateLimitTier(Enum):
    """Rate Limit Tiers für verschiedene Subscription-Level"""
    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"
    UNLIMITED = "unlimited"


@dataclass
class RateLimitConfig:
    """Konfiguration für Rate Limits"""
    requests_per_minute: int
    requests_per_hour: int
    requests_per_day: int
    burst_size: int  # Max Burst für Token Bucket
    ai_requests_per_minute: int  # Spezielle Limits für AI-Endpoints
    ai_requests_per_day: int
    
    @classmethod
    def for_tier(cls, tier: RateLimitTier) -> 'RateLimitConfig':
        """Gibt Config für Tier zurück"""
        configs = {
            RateLimitTier.FREE: cls(
                requests_per_minute=30,
                requests_per_hour=500,
                requests_per_day=2000,
                burst_size=10,
                ai_requests_per_minute=5,
                ai_requests_per_day=50
            ),
            RateLimitTier.STARTER: cls(
                requests_per_minute=60,
                requests_per_hour=2000,
                requests_per_day=10000,
                burst_size=20,
                ai_requests_per_minute=15,
                ai_requests_per_day=200
            ),
            RateLimitTier.PROFESSIONAL: cls(
                requests_per_minute=120,
                requests_per_hour=5000,
                requests_per_day=50000,
                burst_size=50,
                ai_requests_per_minute=30,
                ai_requests_per_day=500
            ),
            RateLimitTier.ENTERPRISE: cls(
                requests_per_minute=300,
                requests_per_hour=15000,
                requests_per_day=200000,
                burst_size=100,
                ai_requests_per_minute=60,
                ai_requests_per_day=2000
            ),
            RateLimitTier.UNLIMITED: cls(
                requests_per_minute=10000,
                requests_per_hour=100000,
                requests_per_day=1000000,
                burst_size=500,
                ai_requests_per_minute=1000,
                ai_requests_per_day=50000
            ),
        }
        return configs.get(tier, configs[RateLimitTier.FREE])


@dataclass
class EndpointLimit:
    """Spezifische Limits für Endpoints"""
    path_pattern: str
    requests_per_minute: int
    cost: int = 1  # Request-Kosten (höher für teure Operationen)
    requires_auth: bool = True
    is_ai_endpoint: bool = False


class SlidingWindowCounter:
    """
    Sliding Window Rate Limiter.
    Präziser als Fixed Window, memory-effizient.
    """
    
    def __init__(self, window_size_seconds: int, max_requests: int):
        self.window_size = window_size_seconds
        self.max_requests = max_requests
        self._counts: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()
    
    def is_allowed(self, key: str) -> Tuple[bool, Dict[str, Any]]:
        """
        Prüft ob Request erlaubt ist.
        
        Returns:
            (is_allowed, rate_limit_info)
        """
        now = time.time()
        window_start = now - self.window_size
        
        with self._lock:
            # Cleanup alte Requests
            self._counts[key] = [
                ts for ts in self._counts[key] 
                if ts > window_start
            ]
            
            current_count = len(self._counts[key])
            remaining = max(0, self.max_requests - current_count)
            
            if current_count >= self.max_requests:
                # Rate limited
                oldest = self._counts[key][0] if self._counts[key] else now
                retry_after = int(oldest + self.window_size - now) + 1
                
                return False, {
                    "limit": self.max_requests,
                    "remaining": 0,
                    "reset": int(oldest + self.window_size),
                    "retry_after": retry_after
                }
            
            # Request erlaubt
            self._counts[key].append(now)
            
            return True, {
                "limit": self.max_requests,
                "remaining": remaining - 1,
                "reset": int(now + self.window_size)
            }
    
    def get_usage(self, key: str) -> Dict[str, Any]:
        """Gibt aktuelle Usage zurück"""
        now = time.time()
        window_start = now - self.window_size
        
        with self._lock:
            self._counts[key] = [
                ts for ts in self._counts[key]
                if ts > window_start
            ]
            current_count = len(self._counts[key])
        
        return {
            "current": current_count,
            "limit": self.max_requests,
            "remaining": max(0, self.max_requests - current_count),
            "window_seconds": self.window_size
        }


class TokenBucket:
    """
    Token Bucket für Burst-Handling.
    Erlaubt kurze Bursts, verhindert sustained high rate.
    """
    
    def __init__(
        self,
        capacity: int,
        refill_rate: float,  # Tokens pro Sekunde
        initial_tokens: Optional[int] = None
    ):
        self.capacity = capacity
        self.refill_rate = refill_rate
        self._tokens: Dict[str, float] = {}
        self._last_refill: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._initial = initial_tokens or capacity
    
    def _refill(self, key: str, now: float):
        """Füllt Bucket mit neuen Tokens"""
        if key not in self._tokens:
            self._tokens[key] = self._initial
            self._last_refill[key] = now
            return
        
        elapsed = now - self._last_refill[key]
        new_tokens = elapsed * self.refill_rate
        self._tokens[key] = min(self.capacity, self._tokens[key] + new_tokens)
        self._last_refill[key] = now
    
    def consume(self, key: str, tokens: int = 1) -> Tuple[bool, Dict[str, Any]]:
        """
        Versucht Tokens zu konsumieren.
        
        Returns:
            (success, bucket_info)
        """
        now = time.time()
        
        with self._lock:
            self._refill(key, now)
            
            available = self._tokens[key]
            
            if available >= tokens:
                self._tokens[key] -= tokens
                return True, {
                    "tokens_remaining": int(self._tokens[key]),
                    "capacity": self.capacity,
                    "refill_rate": self.refill_rate
                }
            
            # Nicht genug Tokens
            wait_time = (tokens - available) / self.refill_rate
            
            return False, {
                "tokens_remaining": int(available),
                "capacity": self.capacity,
                "retry_after": int(wait_time) + 1
            }


class RateLimiter:
    """
    Multi-Tier Rate Limiter mit verschiedenen Algorithmen.
    """
    
    # Endpoint-spezifische Limits
    ENDPOINT_LIMITS = [
        EndpointLimit("/api/auth/login", 5, cost=2),  # Brute-Force Protection
        EndpointLimit("/api/auth/register", 3, cost=3),
        EndpointLimit("/api/auth/password-reset", 3, cost=2),
        EndpointLimit("/api/ai/.*", 10, cost=5, is_ai_endpoint=True),
        EndpointLimit("/api/export/.*", 5, cost=10),
        EndpointLimit("/api/bulk/.*", 2, cost=20),
        EndpointLimit("/api/search", 30, cost=2),
        EndpointLimit("/api/leads", 60, cost=1),
    ]
    
    def __init__(
        self,
        default_tier: RateLimitTier = RateLimitTier.STARTER,
        audit_logger=None
    ):
        self.default_tier = default_tier
        self.audit = audit_logger
        
        # Rate Limiters pro Zeitfenster
        self._minute_limiters: Dict[str, SlidingWindowCounter] = {}
        self._hour_limiters: Dict[str, SlidingWindowCounter] = {}
        self._day_limiters: Dict[str, SlidingWindowCounter] = {}
        
        # Token Buckets pro Tenant
        self._buckets: Dict[str, TokenBucket] = {}
        
        # Tier-Configs
        self._tier_configs: Dict[str, RateLimitConfig] = {}
        
        # Blocked Keys (für temporäre Blocks)
        self._blocked: Dict[str, datetime] = {}
        self._block_lock = threading.Lock()
    
    def _get_config(self, tenant_id: str) -> RateLimitConfig:
        """Holt Config für Tenant"""
        if tenant_id not in self._tier_configs:
            self._tier_configs[tenant_id] = RateLimitConfig.for_tier(
                self.default_tier
            )
        return self._tier_configs[tenant_id]
    
    def set_tenant_tier(self, tenant_id: str, tier: RateLimitTier):
        """Setzt Tier für Tenant"""
        self._tier_configs[tenant_id] = RateLimitConfig.for_tier(tier)
        
        # Update Limiters
        config = self._tier_configs[tenant_id]
        self._minute_limiters[tenant_id] = SlidingWindowCounter(
            60, config.requests_per_minute
        )
        self._hour_limiters[tenant_id] = SlidingWindowCounter(
            3600, config.requests_per_hour
        )
        self._day_limiters[tenant_id] = SlidingWindowCounter(
            86400, config.requests_per_day
        )
        self._buckets[tenant_id] = TokenBucket(
            config.burst_size,
            config.requests_per_minute / 60.0
        )
    
    def _get_endpoint_limit(self, path: str) -> Optional[EndpointLimit]:
        """Findet passendes Endpoint-Limit"""
        for limit in self.ENDPOINT_LIMITS:
            if re.match(limit.path_pattern, path):
                return limit
        return None
    
    def is_blocked(self, key: str) -> bool:
        """Prüft ob Key temporär geblockt ist"""
        with self._block_lock:
            if key in self._blocked:
                if datetime.utcnow() < self._blocked[key]:
                    return True
                del self._blocked[key]
        return False
    
    def block_temporarily(self, key: str, duration_seconds: int):
        """Blockt Key temporär"""
        with self._block_lock:
            self._blocked[key] = datetime.utcnow() + timedelta(
                seconds=duration_seconds
            )
    
    async def check_rate_limit(
        self,
        tenant_id: str,
        user_id: Optional[str],
        path: str,
        ip_address: str
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Prüft alle Rate Limits.
        
        Returns:
            (is_allowed, rate_limit_headers)
        """
        # Composite Keys
        tenant_key = f"tenant:{tenant_id}"
        user_key = f"user:{tenant_id}:{user_id}" if user_id else None
        ip_key = f"ip:{ip_address}"
        
        # Check Blocks
        for key in [tenant_key, user_key, ip_key]:
            if key and self.is_blocked(key):
                if self.audit:
                    await self.audit.log(
                        action="security.rate_limited",
                        tenant_id=tenant_id,
                        user_id=user_id,
                        ip_address=ip_address,
                        details={
                            "reason": "blocked",
                            "path": path
                        }
                    )
                return False, {
                    "X-RateLimit-Limit": "0",
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": "60"
                }
        
        # Initialize Limiters wenn nötig
        config = self._get_config(tenant_id)
        
        if tenant_id not in self._minute_limiters:
            self.set_tenant_tier(tenant_id, self.default_tier)
        
        # Endpoint-spezifisches Limit
        endpoint_limit = self._get_endpoint_limit(path)
        cost = endpoint_limit.cost if endpoint_limit else 1
        
        # Check Minute Limit
        minute_limiter = self._minute_limiters[tenant_id]
        allowed, minute_info = minute_limiter.is_allowed(tenant_key)
        
        if not allowed:
            if self.audit:
                await self.audit.log(
                    action="security.rate_limited",
                    tenant_id=tenant_id,
                    user_id=user_id,
                    ip_address=ip_address,
                    details={
                        "limit_type": "minute",
                        "path": path
                    }
                )
            return False, self._build_headers(minute_info)
        
        # Check Hour Limit
        hour_limiter = self._hour_limiters[tenant_id]
        allowed, hour_info = hour_limiter.is_allowed(tenant_key)
        
        if not allowed:
            return False, self._build_headers(hour_info)
        
        # Check Day Limit
        day_limiter = self._day_limiters[tenant_id]
        allowed, day_info = day_limiter.is_allowed(tenant_key)
        
        if not allowed:
            return False, self._build_headers(day_info)
        
        # Check Burst (Token Bucket)
        bucket = self._buckets[tenant_id]
        allowed, bucket_info = bucket.consume(tenant_key, cost)
        
        if not allowed:
            return False, self._build_headers({
                **minute_info,
                "retry_after": bucket_info.get("retry_after", 1)
            })
        
        # Special AI Limits
        if endpoint_limit and endpoint_limit.is_ai_endpoint:
            ai_allowed = await self._check_ai_limits(
                tenant_id, user_id, config
            )
            if not ai_allowed:
                return False, {
                    "X-RateLimit-Limit": str(config.ai_requests_per_minute),
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": "60"
                }
        
        return True, self._build_headers(minute_info)
    
    async def _check_ai_limits(
        self,
        tenant_id: str,
        user_id: Optional[str],
        config: RateLimitConfig
    ) -> bool:
        """Prüft spezielle AI-Limits"""
        ai_key = f"ai:{tenant_id}"
        
        if ai_key not in self._minute_limiters:
            self._minute_limiters[ai_key] = SlidingWindowCounter(
                60, config.ai_requests_per_minute
            )
        
        allowed, _ = self._minute_limiters[ai_key].is_allowed(ai_key)
        return allowed
    
    def _build_headers(self, info: Dict[str, Any]) -> Dict[str, str]:
        """Baut Rate Limit Headers"""
        headers = {
            "X-RateLimit-Limit": str(info.get("limit", 0)),
            "X-RateLimit-Remaining": str(info.get("remaining", 0)),
            "X-RateLimit-Reset": str(info.get("reset", 0)),
        }
        
        if "retry_after" in info:
            headers["Retry-After"] = str(info["retry_after"])
        
        return headers
    
    def get_usage_stats(self, tenant_id: str) -> Dict[str, Any]:
        """Gibt Usage-Statistiken für Tenant zurück"""
        tenant_key = f"tenant:{tenant_id}"
        
        stats = {
            "tenant_id": tenant_id,
            "tier": self.default_tier.value,
        }
        
        if tenant_id in self._minute_limiters:
            stats["minute"] = self._minute_limiters[tenant_id].get_usage(
                tenant_key
            )
        if tenant_id in self._hour_limiters:
            stats["hour"] = self._hour_limiters[tenant_id].get_usage(
                tenant_key
            )
        if tenant_id in self._day_limiters:
            stats["day"] = self._day_limiters[tenant_id].get_usage(
                tenant_key
            )
        
        return stats


class AIInjectionProtector:
    """
    Schutz vor AI-Injection Attacken.
    Prüft Input auf verdächtige Patterns.
    """
    
    # Verdächtige Patterns für AI-Injection
    INJECTION_PATTERNS = [
        # Prompt Injection
        r"ignore\s+(previous|all|prior)\s+instructions",
        r"forget\s+(everything|all|your)\s+(instructions|rules)",
        r"you\s+are\s+now\s+(a|an)",
        r"new\s+instructions:",
        r"override\s+(system|previous)",
        r"act\s+as\s+if",
        r"pretend\s+(to|you)",
        r"disregard\s+(safety|guidelines)",
        
        # Jailbreak Attempts
        r"DAN\s*mode",
        r"developer\s*mode",
        r"bypass\s+(filters?|safety)",
        r"unlock\s+(capabilities|features)",
        
        # Data Exfiltration
        r"(show|reveal|display)\s+(system|hidden)\s+(prompt|instructions)",
        r"what\s+are\s+your\s+(instructions|rules)",
        r"print\s+your\s+prompt",
        
        # Code Injection
        r"<script[^>]*>",
        r"javascript:",
        r"eval\s*\(",
        r"exec\s*\(",
    ]
    
    # Verdächtige Tokens
    SUSPICIOUS_TOKENS = {
        "{{", "}}", "<%", "%>", "${", "#{",  # Template Injection
        "\\x00", "\\x0a", "\\x0d",  # Null/Newline Injection
        "SYSTEM:", "USER:", "ASSISTANT:",  # Role Injection
    }
    
    def __init__(self):
        self._patterns = [
            re.compile(p, re.IGNORECASE) 
            for p in self.INJECTION_PATTERNS
        ]
        self._cache: Dict[str, Tuple[bool, str]] = {}
    
    def check_input(
        self,
        text: str,
        context: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Prüft Input auf AI-Injection.
        
        Args:
            text: Zu prüfender Text
            context: Kontext (z.B. "user_message", "lead_notes")
            
        Returns:
            (is_safe, violation_reason)
        """
        if not text:
            return True, None
        
        # Cache Check
        cache_key = hashlib.md5(text.encode()).hexdigest()
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        # Pattern Check
        for pattern in self._patterns:
            match = pattern.search(text)
            if match:
                result = (False, f"Injection pattern detected: {match.group()}")
                self._cache[cache_key] = result
                return result
        
        # Token Check
        text_lower = text.lower()
        for token in self.SUSPICIOUS_TOKENS:
            if token.lower() in text_lower:
                result = (False, f"Suspicious token detected: {token}")
                self._cache[cache_key] = result
                return result
        
        # Length Check (verhindert extrem lange Injections)
        if len(text) > 50000:
            result = (False, "Input too long (possible injection)")
            self._cache[cache_key] = result
            return result
        
        result = (True, None)
        self._cache[cache_key] = result
        return result
    
    def sanitize_for_ai(
        self,
        text: str,
        max_length: int = 10000
    ) -> str:
        """
        Sanitized Text für AI-Verarbeitung.
        Entfernt/escaped verdächtige Patterns.
        """
        if not text:
            return text
        
        # Truncate
        text = text[:max_length]
        
        # Escape verdächtige Tokens
        for token in self.SUSPICIOUS_TOKENS:
            text = text.replace(token, f"[FILTERED:{token}]")
        
        # Entferne Steuerzeichen
        text = ''.join(
            char for char in text 
            if char.isprintable() or char in '\n\r\t'
        )
        
        return text


# FastAPI Middleware
class RateLimitMiddleware:
    """
    FastAPI Middleware für Rate Limiting.
    """
    
    def __init__(
        self,
        app,
        rate_limiter: RateLimiter,
        exclude_paths: Optional[set] = None
    ):
        self.app = app
        self.limiter = rate_limiter
        self.exclude = exclude_paths or {"/health", "/metrics", "/docs"}
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        path = scope.get("path", "")
        
        if path in self.exclude:
            await self.app(scope, receive, send)
            return
        
        # Extract Info from Request
        headers = dict(scope.get("headers", []))
        tenant_id = headers.get(b"x-tenant-id", b"default").decode()
        user_id = headers.get(b"x-user-id", b"").decode() or None
        
        # Get Client IP
        client = scope.get("client")
        ip_address = client[0] if client else "unknown"
        
        # Forwarded IP (wenn hinter Proxy)
        forwarded = headers.get(b"x-forwarded-for", b"").decode()
        if forwarded:
            ip_address = forwarded.split(",")[0].strip()
        
        # Check Rate Limit
        allowed, rate_headers = await self.limiter.check_rate_limit(
            tenant_id=tenant_id,
            user_id=user_id,
            path=path,
            ip_address=ip_address
        )
        
        if not allowed:
            # Return 429 Too Many Requests
            response_headers = [
                (b"content-type", b"application/json"),
            ] + [
                (k.lower().encode(), v.encode()) 
                for k, v in rate_headers.items()
            ]
            
            await send({
                "type": "http.response.start",
                "status": 429,
                "headers": response_headers
            })
            
            await send({
                "type": "http.response.body",
                "body": b'{"error": "rate_limit_exceeded", "message": "Too many requests"}'
            })
            return
        
        # Add Rate Limit Headers to Response
        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                for name, value in rate_headers.items():
                    headers.append((name.lower().encode(), value.encode()))
                message["headers"] = headers
            await send(message)
        
        await self.app(scope, receive, send_with_headers)


# Factory
def create_rate_limit_system(
    default_tier: RateLimitTier = RateLimitTier.STARTER,
    audit_logger=None
) -> Tuple[RateLimiter, AIInjectionProtector]:
    """Factory für Rate Limit System"""
    limiter = RateLimiter(default_tier=default_tier, audit_logger=audit_logger)
    protector = AIInjectionProtector()
    return limiter, protector
