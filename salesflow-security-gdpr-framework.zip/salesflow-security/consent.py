"""
SalesFlow AI - Consent Management System
========================================
Granulares Consent Management nach DSGVO Art. 7.

Features:
- Granulare Consent-Kategorien
- Audit Trail für alle Consent-Änderungen
- Consent Versioning
- Withdrawal Support
- Double Opt-In
"""

import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Any, Optional, Dict, List, Set
from dataclasses import dataclass, field, asdict
from enum import Enum
from uuid import uuid4
import json
import logging

logger = logging.getLogger(__name__)


class ConsentPurpose(Enum):
    """Zwecke für Datenverarbeitung nach DSGVO"""
    
    # Kernfunktionalität
    ESSENTIAL = "essential"                    # Notwendig für Service
    
    # Marketing
    MARKETING_EMAIL = "marketing_email"        # Email Marketing
    MARKETING_SMS = "marketing_sms"            # SMS Marketing
    MARKETING_PUSH = "marketing_push"          # Push Notifications
    MARKETING_PROFILING = "marketing_profiling"  # Profiling für Marketing
    
    # Analytics
    ANALYTICS_BASIC = "analytics_basic"        # Basis-Analytics
    ANALYTICS_ADVANCED = "analytics_advanced"  # Erweiterte Analytics
    ANALYTICS_AI = "analytics_ai"              # KI-basierte Analyse
    
    # Third Party
    THIRD_PARTY_CRM = "third_party_crm"        # CRM Integration
    THIRD_PARTY_SOCIAL = "third_party_social"  # Social Media
    THIRD_PARTY_ADVERTISING = "third_party_ads"  # Werbung
    
    # Spezifisch
    AI_TRAINING = "ai_training"                # KI-Training mit Daten
    DATA_SHARING = "data_sharing"              # Daten-Sharing mit Partnern
    CROSS_DEVICE = "cross_device"              # Cross-Device Tracking


class ConsentStatus(Enum):
    """Status einer Einwilligung"""
    GRANTED = "granted"
    DENIED = "denied"
    WITHDRAWN = "withdrawn"
    EXPIRED = "expired"
    PENDING = "pending"


@dataclass
class ConsentMetadata:
    """Metadaten für Consent-Nachweis"""
    ip_address: str
    user_agent: str
    consent_ui_version: str
    language: str
    geolocation: Optional[str] = None


@dataclass
class ConsentRecord:
    """Einzelne Consent-Aufzeichnung"""
    consent_id: str
    user_id: str
    tenant_id: str
    purpose: ConsentPurpose
    status: ConsentStatus
    granted_at: datetime
    expires_at: Optional[datetime]
    withdrawn_at: Optional[datetime]
    version: int
    metadata: ConsentMetadata
    legal_text_hash: str  # Hash der angezeigten Rechtlichen Info
    source: str  # registration, settings, popup, etc.
    
    def to_dict(self) -> Dict:
        result = asdict(self)
        result["purpose"] = self.purpose.value
        result["status"] = self.status.value
        result["granted_at"] = self.granted_at.isoformat()
        if self.expires_at:
            result["expires_at"] = self.expires_at.isoformat()
        if self.withdrawn_at:
            result["withdrawn_at"] = self.withdrawn_at.isoformat()
        result["metadata"] = asdict(self.metadata)
        return result
    
    def is_valid(self) -> bool:
        """Prüft ob Consent aktuell gültig ist"""
        if self.status != ConsentStatus.GRANTED:
            return False
        if self.withdrawn_at:
            return False
        if self.expires_at and datetime.utcnow() > self.expires_at:
            return False
        return True


@dataclass
class ConsentBundle:
    """Bündel aller Consents eines Users"""
    user_id: str
    tenant_id: str
    consents: Dict[str, ConsentRecord]  # purpose -> record
    created_at: datetime
    last_updated: datetime
    
    def get_consent(self, purpose: ConsentPurpose) -> Optional[ConsentRecord]:
        return self.consents.get(purpose.value)
    
    def has_valid_consent(self, purpose: ConsentPurpose) -> bool:
        record = self.get_consent(purpose)
        return record is not None and record.is_valid()
    
    def get_valid_purposes(self) -> List[ConsentPurpose]:
        return [
            ConsentPurpose(purpose)
            for purpose, record in self.consents.items()
            if record.is_valid()
        ]


class ConsentPolicy:
    """
    Definiert Consent-Anforderungen und Abhängigkeiten.
    """
    
    # Zwecke die für Service essentiell sind (kein Consent nötig)
    ESSENTIAL_PURPOSES = {ConsentPurpose.ESSENTIAL}
    
    # Consent-Abhängigkeiten (A requires B)
    DEPENDENCIES = {
        ConsentPurpose.MARKETING_PROFILING: {ConsentPurpose.ANALYTICS_BASIC},
        ConsentPurpose.ANALYTICS_ADVANCED: {ConsentPurpose.ANALYTICS_BASIC},
        ConsentPurpose.ANALYTICS_AI: {ConsentPurpose.ANALYTICS_ADVANCED},
        ConsentPurpose.THIRD_PARTY_ADVERTISING: {ConsentPurpose.MARKETING_PROFILING},
        ConsentPurpose.AI_TRAINING: {ConsentPurpose.ANALYTICS_AI},
    }
    
    # Standard-Ablaufzeiten (Tage)
    DEFAULT_EXPIRY = {
        ConsentPurpose.MARKETING_EMAIL: 365,
        ConsentPurpose.MARKETING_SMS: 180,
        ConsentPurpose.MARKETING_PUSH: 180,
        ConsentPurpose.MARKETING_PROFILING: 365,
        ConsentPurpose.ANALYTICS_BASIC: 730,
        ConsentPurpose.ANALYTICS_ADVANCED: 365,
        ConsentPurpose.ANALYTICS_AI: 180,
        ConsentPurpose.THIRD_PARTY_CRM: 365,
        ConsentPurpose.THIRD_PARTY_SOCIAL: 180,
        ConsentPurpose.THIRD_PARTY_ADVERTISING: 90,
        ConsentPurpose.AI_TRAINING: 365,
        ConsentPurpose.DATA_SHARING: 180,
        ConsentPurpose.CROSS_DEVICE: 365,
    }
    
    # Beschreibungen für UI
    PURPOSE_DESCRIPTIONS = {
        ConsentPurpose.ESSENTIAL: {
            "de": "Notwendig für die Grundfunktionen des Services",
            "en": "Required for basic service functionality"
        },
        ConsentPurpose.MARKETING_EMAIL: {
            "de": "Wir senden Ihnen Marketing-E-Mails zu Produkten und Angeboten",
            "en": "We will send you marketing emails about products and offers"
        },
        ConsentPurpose.MARKETING_SMS: {
            "de": "Wir senden Ihnen Marketing-SMS zu Angeboten",
            "en": "We will send you marketing SMS about offers"
        },
        ConsentPurpose.ANALYTICS_BASIC: {
            "de": "Anonyme Nutzungsstatistiken zur Service-Verbesserung",
            "en": "Anonymous usage statistics to improve the service"
        },
        ConsentPurpose.ANALYTICS_AI: {
            "de": "KI-gestützte Analyse Ihres Nutzungsverhaltens für personalisierte Empfehlungen",
            "en": "AI-powered analysis of your usage for personalized recommendations"
        },
        ConsentPurpose.AI_TRAINING: {
            "de": "Nutzung Ihrer Daten zum Training unserer KI-Modelle",
            "en": "Use of your data to train our AI models"
        },
    }
    
    @classmethod
    def is_essential(cls, purpose: ConsentPurpose) -> bool:
        return purpose in cls.ESSENTIAL_PURPOSES
    
    @classmethod
    def get_dependencies(cls, purpose: ConsentPurpose) -> Set[ConsentPurpose]:
        """Gibt alle Abhängigkeiten für einen Zweck zurück"""
        direct = cls.DEPENDENCIES.get(purpose, set())
        all_deps = set(direct)
        
        # Transitive Abhängigkeiten
        for dep in direct:
            all_deps.update(cls.get_dependencies(dep))
        
        return all_deps
    
    @classmethod
    def get_default_expiry(cls, purpose: ConsentPurpose) -> Optional[datetime]:
        days = cls.DEFAULT_EXPIRY.get(purpose)
        if days:
            return datetime.utcnow() + timedelta(days=days)
        return None
    
    @classmethod
    def get_description(cls, purpose: ConsentPurpose, lang: str = "de") -> str:
        descs = cls.PURPOSE_DESCRIPTIONS.get(purpose, {})
        return descs.get(lang, descs.get("en", str(purpose.value)))


class DoubleOptInManager:
    """
    Verwaltet Double Opt-In Prozess.
    Speziell für Marketing-Einwilligungen.
    """
    
    def __init__(self, token_validity_hours: int = 48):
        self._pending: Dict[str, Dict] = {}  # token -> pending consent
        self._validity = timedelta(hours=token_validity_hours)
    
    def create_verification(
        self,
        user_id: str,
        tenant_id: str,
        purpose: ConsentPurpose,
        email: str
    ) -> str:
        """
        Erstellt Verifizierungs-Token für Double Opt-In.
        
        Returns:
            Verification Token
        """
        token = secrets.token_urlsafe(32)
        
        self._pending[token] = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "purpose": purpose.value,
            "email": email,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + self._validity).isoformat()
        }
        
        return token
    
    def verify_and_consume(self, token: str) -> Optional[Dict]:
        """
        Verifiziert Token und markiert als verwendet.
        
        Returns:
            Pending Consent Data oder None
        """
        if token not in self._pending:
            return None
        
        pending = self._pending[token]
        expires_at = datetime.fromisoformat(pending["expires_at"])
        
        if datetime.utcnow() > expires_at:
            del self._pending[token]
            return None
        
        # Token konsumieren
        del self._pending[token]
        return pending
    
    def cleanup_expired(self):
        """Entfernt abgelaufene Tokens"""
        now = datetime.utcnow()
        expired = [
            token for token, data in self._pending.items()
            if datetime.fromisoformat(data["expires_at"]) < now
        ]
        for token in expired:
            del self._pending[token]


class ConsentStorage:
    """
    In-Memory Consent Storage.
    In Production: PostgreSQL mit Versionierung.
    """
    
    def __init__(self):
        self._bundles: Dict[str, ConsentBundle] = {}  # user_id -> bundle
        self._history: Dict[str, List[ConsentRecord]] = {}  # user_id -> history
    
    def get_bundle(self, user_id: str, tenant_id: str) -> Optional[ConsentBundle]:
        return self._bundles.get(f"{tenant_id}:{user_id}")
    
    def save_bundle(self, bundle: ConsentBundle):
        key = f"{bundle.tenant_id}:{bundle.user_id}"
        self._bundles[key] = bundle
    
    def add_to_history(self, record: ConsentRecord):
        key = f"{record.tenant_id}:{record.user_id}"
        if key not in self._history:
            self._history[key] = []
        self._history[key].append(record)
    
    def get_history(
        self,
        user_id: str,
        tenant_id: str,
        purpose: Optional[ConsentPurpose] = None
    ) -> List[ConsentRecord]:
        key = f"{tenant_id}:{user_id}"
        history = self._history.get(key, [])
        
        if purpose:
            history = [r for r in history if r.purpose == purpose]
        
        return sorted(history, key=lambda r: r.granted_at, reverse=True)


class ConsentManager:
    """
    Hauptklasse für Consent Management.
    """
    
    def __init__(
        self,
        storage: Optional[ConsentStorage] = None,
        audit_logger=None,
        require_double_optin: bool = True
    ):
        self._storage = storage or ConsentStorage()
        self._audit = audit_logger
        self._double_optin = DoubleOptInManager() if require_double_optin else None
        self._marketing_purposes = {
            ConsentPurpose.MARKETING_EMAIL,
            ConsentPurpose.MARKETING_SMS,
            ConsentPurpose.MARKETING_PUSH
        }
    
    async def grant_consent(
        self,
        user_id: str,
        tenant_id: str,
        purposes: List[ConsentPurpose],
        metadata: ConsentMetadata,
        legal_text: str,
        source: str = "settings"
    ) -> List[ConsentRecord]:
        """
        Erteilt Consent für mehrere Zwecke.
        
        Args:
            user_id: User ID
            tenant_id: Tenant ID
            purposes: Liste der Zwecke
            metadata: Consent-Metadaten
            legal_text: Angezeigte rechtliche Informationen
            source: Quelle der Einwilligung
            
        Returns:
            Liste der erstellten ConsentRecords
        """
        legal_hash = hashlib.sha256(legal_text.encode()).hexdigest()[:16]
        records = []
        
        # Hole oder erstelle Bundle
        bundle = self._storage.get_bundle(user_id, tenant_id)
        if not bundle:
            bundle = ConsentBundle(
                user_id=user_id,
                tenant_id=tenant_id,
                consents={},
                created_at=datetime.utcnow(),
                last_updated=datetime.utcnow()
            )
        
        for purpose in purposes:
            # Prüfe Abhängigkeiten
            deps = ConsentPolicy.get_dependencies(purpose)
            for dep in deps:
                if not bundle.has_valid_consent(dep):
                    if dep not in purposes:
                        logger.warning(
                            f"Consent {purpose.value} requires {dep.value}"
                        )
        
            # Ermittle Version
            history = self._storage.get_history(user_id, tenant_id, purpose)
            version = len(history) + 1
            
            # Bestimme Status
            needs_verification = (
                self._double_optin and 
                purpose in self._marketing_purposes
            )
            status = (
                ConsentStatus.PENDING if needs_verification 
                else ConsentStatus.GRANTED
            )
            
            record = ConsentRecord(
                consent_id=str(uuid4()),
                user_id=user_id,
                tenant_id=tenant_id,
                purpose=purpose,
                status=status,
                granted_at=datetime.utcnow(),
                expires_at=ConsentPolicy.get_default_expiry(purpose),
                withdrawn_at=None,
                version=version,
                metadata=metadata,
                legal_text_hash=legal_hash,
                source=source
            )
            
            bundle.consents[purpose.value] = record
            self._storage.add_to_history(record)
            records.append(record)
            
            # Audit
            if self._audit:
                await self._audit.log(
                    action="gdpr.consent_granted",
                    tenant_id=tenant_id,
                    user_id=user_id,
                    details={
                        "purpose": purpose.value,
                        "version": version,
                        "source": source,
                        "status": status.value
                    }
                )
        
        bundle.last_updated = datetime.utcnow()
        self._storage.save_bundle(bundle)
        
        return records
    
    async def withdraw_consent(
        self,
        user_id: str,
        tenant_id: str,
        purposes: List[ConsentPurpose],
        reason: Optional[str] = None
    ) -> List[ConsentRecord]:
        """
        Widerruft Consent für mehrere Zwecke.
        """
        bundle = self._storage.get_bundle(user_id, tenant_id)
        if not bundle:
            return []
        
        withdrawn = []
        
        for purpose in purposes:
            record = bundle.get_consent(purpose)
            if not record or record.status == ConsentStatus.WITHDRAWN:
                continue
            
            record.status = ConsentStatus.WITHDRAWN
            record.withdrawn_at = datetime.utcnow()
            
            self._storage.add_to_history(record)
            withdrawn.append(record)
            
            # Audit
            if self._audit:
                await self._audit.log(
                    action="gdpr.consent_revoked",
                    tenant_id=tenant_id,
                    user_id=user_id,
                    details={
                        "purpose": purpose.value,
                        "reason": reason
                    }
                )
            
            # Widerrufe abhängige Consents
            for other_purpose in ConsentPurpose:
                deps = ConsentPolicy.get_dependencies(other_purpose)
                if purpose in deps:
                    other_record = bundle.get_consent(other_purpose)
                    if other_record and other_record.status == ConsentStatus.GRANTED:
                        other_record.status = ConsentStatus.WITHDRAWN
                        other_record.withdrawn_at = datetime.utcnow()
                        withdrawn.append(other_record)
        
        bundle.last_updated = datetime.utcnow()
        self._storage.save_bundle(bundle)
        
        return withdrawn
    
    def check_consent(
        self,
        user_id: str,
        tenant_id: str,
        purpose: ConsentPurpose
    ) -> bool:
        """
        Prüft ob User gültigen Consent hat.
        """
        if ConsentPolicy.is_essential(purpose):
            return True
        
        bundle = self._storage.get_bundle(user_id, tenant_id)
        if not bundle:
            return False
        
        return bundle.has_valid_consent(purpose)
    
    def require_consent(
        self,
        purpose: ConsentPurpose
    ):
        """
        Decorator für Funktionen die Consent benötigen.
        
        Usage:
            @consent_manager.require_consent(ConsentPurpose.ANALYTICS_AI)
            async def analyze_user_behavior(user_id, tenant_id, ...):
                ...
        """
        def decorator(func):
            async def wrapper(user_id: str, tenant_id: str, *args, **kwargs):
                if not self.check_consent(user_id, tenant_id, purpose):
                    raise PermissionError(
                        f"Consent required for {purpose.value}"
                    )
                return await func(user_id, tenant_id, *args, **kwargs)
            return wrapper
        return decorator
    
    def get_consent_status(
        self,
        user_id: str,
        tenant_id: str
    ) -> Dict[str, Any]:
        """
        Gibt vollständigen Consent-Status zurück.
        Für UI-Anzeige.
        """
        bundle = self._storage.get_bundle(user_id, tenant_id)
        
        status = {}
        for purpose in ConsentPurpose:
            record = bundle.get_consent(purpose) if bundle else None
            
            status[purpose.value] = {
                "granted": record.is_valid() if record else False,
                "status": record.status.value if record else "none",
                "granted_at": record.granted_at.isoformat() if record else None,
                "expires_at": (
                    record.expires_at.isoformat() 
                    if record and record.expires_at else None
                ),
                "is_essential": ConsentPolicy.is_essential(purpose),
                "description_de": ConsentPolicy.get_description(purpose, "de"),
                "description_en": ConsentPolicy.get_description(purpose, "en"),
                "dependencies": [
                    dep.value for dep in ConsentPolicy.get_dependencies(purpose)
                ]
            }
        
        return {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "last_updated": (
                bundle.last_updated.isoformat() if bundle else None
            ),
            "consents": status
        }
    
    def get_consent_history(
        self,
        user_id: str,
        tenant_id: str,
        purpose: Optional[ConsentPurpose] = None
    ) -> List[Dict]:
        """
        Gibt Consent-Historie zurück.
        Für DSGVO-Nachweispflicht.
        """
        history = self._storage.get_history(user_id, tenant_id, purpose)
        return [record.to_dict() for record in history]


# Consent Middleware für FastAPI
class ConsentMiddleware:
    """
    FastAPI Middleware für automatische Consent-Prüfung.
    """
    
    ENDPOINT_REQUIREMENTS = {
        "/api/marketing/send-email": ConsentPurpose.MARKETING_EMAIL,
        "/api/marketing/send-sms": ConsentPurpose.MARKETING_SMS,
        "/api/analytics/advanced": ConsentPurpose.ANALYTICS_ADVANCED,
        "/api/ai/analyze": ConsentPurpose.ANALYTICS_AI,
        "/api/ai/train": ConsentPurpose.AI_TRAINING,
    }
    
    def __init__(self, consent_manager: ConsentManager):
        self._manager = consent_manager
    
    async def __call__(self, request, call_next):
        path = request.url.path
        required = self.ENDPOINT_REQUIREMENTS.get(path)
        
        if required:
            user_id = getattr(request.state, "user_id", None)
            tenant_id = getattr(request.state, "tenant_id", None)
            
            if user_id and tenant_id:
                if not self._manager.check_consent(user_id, tenant_id, required):
                    from fastapi.responses import JSONResponse
                    return JSONResponse(
                        status_code=403,
                        content={
                            "error": "consent_required",
                            "purpose": required.value,
                            "message": f"Consent required for {required.value}"
                        }
                    )
        
        return await call_next(request)


# Factory
def create_consent_system(
    audit_logger=None,
    require_double_optin: bool = True
) -> ConsentManager:
    """Factory für Consent System"""
    storage = ConsentStorage()
    return ConsentManager(
        storage=storage,
        audit_logger=audit_logger,
        require_double_optin=require_double_optin
    )
