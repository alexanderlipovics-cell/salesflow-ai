"""
SalesFlow AI - GDPR API Router
==============================
REST API für DSGVO-Betroffenenrechte.

Endpoints:
- POST /api/gdpr/access-request    - Auskunftsanfrage (Art. 15)
- POST /api/gdpr/deletion-request  - Löschanfrage (Art. 17)
- GET  /api/gdpr/export           - Datenexport (Art. 20)
- GET  /api/gdpr/consent          - Consent-Status
- POST /api/gdpr/consent          - Consent erteilen
- DELETE /api/gdpr/consent        - Consent widerrufen
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel, EmailStr, Field
import logging

# Import Security Module
from ..security import (
    GDPRComplianceManager,
    ConsentManager,
    ConsentPurpose,
    ConsentMetadata,
    DataSubjectRequest,
    AuditLogger,
    AuditAction,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/gdpr", tags=["GDPR"])


# ============================================================
# Request/Response Models
# ============================================================

class AccessRequestCreate(BaseModel):
    """Request für Auskunftsanfrage"""
    email: EmailStr
    include_categories: Optional[List[str]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "user@example.com",
                "include_categories": ["profile", "contacts", "conversations"]
            }
        }


class DeletionRequestCreate(BaseModel):
    """Request für Löschanfrage"""
    email: EmailStr
    reason: Optional[str] = None
    confirm_deletion: bool = Field(
        ...,
        description="Muss True sein um Löschung zu bestätigen"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "user@example.com",
                "reason": "Möchte meine Daten nicht mehr bei Ihnen haben",
                "confirm_deletion": True
            }
        }


class VerificationRequest(BaseModel):
    """Request für Verifizierung"""
    request_id: str
    token: str


class ConsentGrant(BaseModel):
    """Request für Consent-Erteilung"""
    purposes: List[str]
    legal_text_acknowledged: bool = Field(
        ...,
        description="Bestätigung dass Datenschutzerklärung gelesen wurde"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "purposes": ["analytics_basic", "marketing_email"],
                "legal_text_acknowledged": True
            }
        }


class ConsentWithdraw(BaseModel):
    """Request für Consent-Widerruf"""
    purposes: List[str]
    reason: Optional[str] = None


class DataSubjectRequestResponse(BaseModel):
    """Response für Betroffenenanfragen"""
    request_id: str
    status: str
    type: str
    created_at: str
    verification_required: bool
    message: str


class ConsentStatusResponse(BaseModel):
    """Response für Consent-Status"""
    user_id: str
    tenant_id: str
    last_updated: Optional[str]
    consents: Dict[str, Any]


# ============================================================
# Dependency Injection
# ============================================================

# Diese würden in Production aus DI Container kommen
_gdpr_manager: Optional[GDPRComplianceManager] = None
_consent_manager: Optional[ConsentManager] = None
_audit_logger: Optional[AuditLogger] = None


async def get_gdpr_manager() -> GDPRComplianceManager:
    """Dependency für GDPR Manager"""
    global _gdpr_manager
    if not _gdpr_manager:
        _gdpr_manager = GDPRComplianceManager(
            db_session=None,  # In Production: echte DB Session
            audit_logger=_audit_logger
        )
    return _gdpr_manager


async def get_consent_manager() -> ConsentManager:
    """Dependency für Consent Manager"""
    global _consent_manager
    if not _consent_manager:
        from ..security import create_consent_system
        _consent_manager = create_consent_system(
            audit_logger=_audit_logger
        )
    return _consent_manager


async def get_current_user(request: Request) -> Dict[str, str]:
    """
    Dependency für aktuellen User.
    In Production: JWT Token Validation
    """
    # Placeholder - würde aus JWT kommen
    user_id = request.headers.get("X-User-ID", "test-user")
    tenant_id = request.headers.get("X-Tenant-ID", "test-tenant")
    email = request.headers.get("X-User-Email", "user@example.com")
    
    return {
        "user_id": user_id,
        "tenant_id": tenant_id,
        "email": email
    }


def get_request_metadata(request: Request) -> ConsentMetadata:
    """Extrahiert Metadata aus Request für Consent"""
    return ConsentMetadata(
        ip_address=request.client.host if request.client else "unknown",
        user_agent=request.headers.get("User-Agent", "unknown"),
        consent_ui_version="1.0.0",
        language=request.headers.get("Accept-Language", "de-DE").split(",")[0]
    )


# ============================================================
# GDPR Endpoints - Auskunft & Löschung
# ============================================================

@router.post(
    "/access-request",
    response_model=DataSubjectRequestResponse,
    summary="Auskunftsanfrage erstellen (Art. 15 DSGVO)",
    description="""
    Erstellt eine Auskunftsanfrage nach Art. 15 DSGVO.
    
    Der Nutzer erhält eine Email zur Verifizierung.
    Nach Verifizierung werden alle gespeicherten Daten exportiert.
    
    **Frist:** 30 Tage nach Verifizierung
    """
)
async def create_access_request(
    request_data: AccessRequestCreate,
    background_tasks: BackgroundTasks,
    request: Request,
    current_user: Dict = Depends(get_current_user),
    gdpr_manager: GDPRComplianceManager = Depends(get_gdpr_manager)
):
    """Erstellt Auskunftsanfrage"""
    try:
        dsr = await gdpr_manager.create_access_request(
            user_id=current_user["user_id"],
            tenant_id=current_user["tenant_id"],
            email=request_data.email
        )
        
        # Send Verification Email (Background)
        background_tasks.add_task(
            send_verification_email,
            email=request_data.email,
            request_id=dsr.request_id,
            token=dsr.verification_token,
            request_type="access"
        )
        
        return DataSubjectRequestResponse(
            request_id=dsr.request_id,
            status=dsr.status,
            type="access",
            created_at=dsr.requested_at.isoformat(),
            verification_required=True,
            message="Verifizierungs-Email wurde gesendet. Bitte bestätigen Sie Ihre Anfrage."
        )
        
    except Exception as e:
        logger.error(f"Access request error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/deletion-request",
    response_model=DataSubjectRequestResponse,
    summary="Löschanfrage erstellen (Art. 17 DSGVO)",
    description="""
    Erstellt eine Löschanfrage nach Art. 17 DSGVO (Recht auf Vergessenwerden).
    
    **Wichtig:** Diese Aktion kann nicht rückgängig gemacht werden!
    
    Nach Verifizierung werden alle personenbezogenen Daten gelöscht,
    außer solche die gesetzlichen Aufbewahrungsfristen unterliegen.
    """
)
async def create_deletion_request(
    request_data: DeletionRequestCreate,
    background_tasks: BackgroundTasks,
    request: Request,
    current_user: Dict = Depends(get_current_user),
    gdpr_manager: GDPRComplianceManager = Depends(get_gdpr_manager)
):
    """Erstellt Löschanfrage"""
    if not request_data.confirm_deletion:
        raise HTTPException(
            status_code=400,
            detail="Löschung muss explizit bestätigt werden (confirm_deletion=true)"
        )
    
    try:
        dsr = await gdpr_manager.create_deletion_request(
            user_id=current_user["user_id"],
            tenant_id=current_user["tenant_id"],
            email=request_data.email
        )
        
        # Send Verification Email
        background_tasks.add_task(
            send_verification_email,
            email=request_data.email,
            request_id=dsr.request_id,
            token=dsr.verification_token,
            request_type="deletion"
        )
        
        return DataSubjectRequestResponse(
            request_id=dsr.request_id,
            status=dsr.status,
            type="deletion",
            created_at=dsr.requested_at.isoformat(),
            verification_required=True,
            message="Verifizierungs-Email wurde gesendet. Nach Bestätigung werden Ihre Daten unwiderruflich gelöscht."
        )
        
    except Exception as e:
        logger.error(f"Deletion request error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/verify",
    summary="Betroffenenanfrage verifizieren",
    description="Verifiziert eine Auskunfts- oder Löschanfrage mit dem Token aus der Email."
)
async def verify_request(
    verification: VerificationRequest,
    background_tasks: BackgroundTasks,
    gdpr_manager: GDPRComplianceManager = Depends(get_gdpr_manager)
):
    """Verifiziert Anfrage und führt sie aus"""
    verified = gdpr_manager.verify_request(
        verification.request_id,
        verification.token
    )
    
    if not verified:
        raise HTTPException(
            status_code=400,
            detail="Ungültiger oder abgelaufener Verifizierungs-Token"
        )
    
    # Get Request Status
    status = gdpr_manager.get_request_status(verification.request_id)
    
    if not status:
        raise HTTPException(status_code=404, detail="Anfrage nicht gefunden")
    
    # Execute Request (Background für lange Operationen)
    if status["type"] == "access":
        background_tasks.add_task(
            execute_access_request,
            gdpr_manager,
            verification.request_id
        )
        return {
            "status": "processing",
            "message": "Ihre Daten werden exportiert. Sie erhalten eine Email wenn der Export fertig ist."
        }
    elif status["type"] == "erasure":
        background_tasks.add_task(
            execute_deletion_request,
            gdpr_manager,
            verification.request_id
        )
        return {
            "status": "processing",
            "message": "Ihre Daten werden gelöscht. Sie erhalten eine Bestätigungs-Email."
        }
    
    return {"status": "verified"}


@router.get(
    "/request-status/{request_id}",
    summary="Status einer Betroffenenanfrage abrufen"
)
async def get_request_status(
    request_id: str,
    current_user: Dict = Depends(get_current_user),
    gdpr_manager: GDPRComplianceManager = Depends(get_gdpr_manager)
):
    """Gibt Status einer Anfrage zurück"""
    status = gdpr_manager.get_request_status(request_id)
    
    if not status:
        raise HTTPException(status_code=404, detail="Anfrage nicht gefunden")
    
    return status


@router.get(
    "/export",
    summary="Daten exportieren (Art. 20 DSGVO)",
    description="Exportiert alle personenbezogenen Daten im JSON-Format."
)
async def export_data(
    format: str = "json",
    current_user: Dict = Depends(get_current_user),
    gdpr_manager: GDPRComplianceManager = Depends(get_gdpr_manager)
):
    """Direkter Datenexport ohne formale Anfrage"""
    try:
        export = await gdpr_manager.data_exporter.export_user_data(
            user_id=current_user["user_id"],
            tenant_id=current_user["tenant_id"],
            format=format
        )
        
        return export
        
    except Exception as e:
        logger.error(f"Export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# Consent Endpoints
# ============================================================

@router.get(
    "/consent",
    response_model=ConsentStatusResponse,
    summary="Consent-Status abrufen",
    description="Zeigt alle aktuellen Einwilligungen und deren Status."
)
async def get_consent_status(
    current_user: Dict = Depends(get_current_user),
    consent_manager: ConsentManager = Depends(get_consent_manager)
):
    """Gibt aktuellen Consent-Status zurück"""
    status = consent_manager.get_consent_status(
        user_id=current_user["user_id"],
        tenant_id=current_user["tenant_id"]
    )
    
    return ConsentStatusResponse(**status)


@router.post(
    "/consent",
    summary="Einwilligung erteilen",
    description="""
    Erteilt Einwilligung für einen oder mehrere Verarbeitungszwecke.
    
    **Verfügbare Zwecke:**
    - `essential` - Notwendig für Service (kann nicht abgelehnt werden)
    - `marketing_email` - Email Marketing
    - `marketing_sms` - SMS Marketing
    - `analytics_basic` - Basis Analytics
    - `analytics_ai` - KI-basierte Analyse
    - `ai_training` - KI-Training mit Ihren Daten
    """
)
async def grant_consent(
    consent_data: ConsentGrant,
    request: Request,
    current_user: Dict = Depends(get_current_user),
    consent_manager: ConsentManager = Depends(get_consent_manager)
):
    """Erteilt Consent"""
    if not consent_data.legal_text_acknowledged:
        raise HTTPException(
            status_code=400,
            detail="Datenschutzerklärung muss bestätigt werden"
        )
    
    try:
        # Parse Purposes
        purposes = []
        for p in consent_data.purposes:
            try:
                purposes.append(ConsentPurpose(p))
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Ungültiger Zweck: {p}"
                )
        
        metadata = get_request_metadata(request)
        
        # Legal Text (in Production aus DB)
        legal_text = """
        Datenschutzerklärung SalesFlow AI
        Version 1.0 - Stand: 2024
        
        Wir verarbeiten Ihre Daten gemäß DSGVO...
        """
        
        records = await consent_manager.grant_consent(
            user_id=current_user["user_id"],
            tenant_id=current_user["tenant_id"],
            purposes=purposes,
            metadata=metadata,
            legal_text=legal_text,
            source="api"
        )
        
        return {
            "status": "success",
            "granted": [r.purpose.value for r in records],
            "pending_verification": [
                r.purpose.value for r in records 
                if r.status.value == "pending"
            ]
        }
        
    except Exception as e:
        logger.error(f"Consent grant error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete(
    "/consent",
    summary="Einwilligung widerrufen",
    description="Widerruft Einwilligung für einen oder mehrere Verarbeitungszwecke."
)
async def withdraw_consent(
    consent_data: ConsentWithdraw,
    current_user: Dict = Depends(get_current_user),
    consent_manager: ConsentManager = Depends(get_consent_manager)
):
    """Widerruft Consent"""
    try:
        purposes = []
        for p in consent_data.purposes:
            try:
                purposes.append(ConsentPurpose(p))
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Ungültiger Zweck: {p}"
                )
        
        records = await consent_manager.withdraw_consent(
            user_id=current_user["user_id"],
            tenant_id=current_user["tenant_id"],
            purposes=purposes,
            reason=consent_data.reason
        )
        
        return {
            "status": "success",
            "withdrawn": [r.purpose.value for r in records],
            "message": "Ihre Einwilligungen wurden widerrufen. Verarbeitung wird eingestellt."
        }
        
    except Exception as e:
        logger.error(f"Consent withdraw error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/consent/history",
    summary="Consent-Historie abrufen",
    description="Zeigt alle historischen Consent-Änderungen für Nachweiszwecke."
)
async def get_consent_history(
    purpose: Optional[str] = None,
    current_user: Dict = Depends(get_current_user),
    consent_manager: ConsentManager = Depends(get_consent_manager)
):
    """Gibt Consent-Historie zurück"""
    purpose_enum = None
    if purpose:
        try:
            purpose_enum = ConsentPurpose(purpose)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Ungültiger Zweck: {purpose}")
    
    history = consent_manager.get_consent_history(
        user_id=current_user["user_id"],
        tenant_id=current_user["tenant_id"],
        purpose=purpose_enum
    )
    
    return {
        "user_id": current_user["user_id"],
        "history": history
    }


# ============================================================
# Processing Activities (Art. 30 DSGVO)
# ============================================================

@router.get(
    "/processing-activities",
    summary="Verarbeitungsverzeichnis abrufen (Art. 30 DSGVO)",
    description="Öffentliches Verzeichnis der Verarbeitungstätigkeiten."
)
async def get_processing_activities():
    """
    Gibt Verzeichnis der Verarbeitungstätigkeiten zurück.
    Öffentlich zugänglich gemäß Transparenzpflicht.
    """
    # In Production aus DB
    return {
        "organization": "SalesFlow AI GmbH",
        "dpo_contact": "datenschutz@salesflow.ai",
        "activities": [
            {
                "name": "CRM Kontaktverwaltung",
                "purpose": "Verwaltung von Geschäftskontakten und Leads",
                "legal_basis": "Vertrag (Art. 6(1)(b))",
                "data_categories": ["Kontaktdaten", "Geschäftsinformationen"],
                "retention": "Bis zur Löschung durch Nutzer oder Vertragsende + 3 Jahre",
                "recipients": ["Interne Mitarbeiter"],
                "third_country_transfers": []
            },
            {
                "name": "KI-gestützte Leadanalyse",
                "purpose": "Automatische Analyse und Scoring von Leads",
                "legal_basis": "Einwilligung (Art. 6(1)(a))",
                "data_categories": ["Kontaktdaten", "Konversationen", "Verhaltensanalyse"],
                "retention": "Bis Widerruf der Einwilligung",
                "recipients": ["KI-Subsysteme", "Interne Mitarbeiter"],
                "third_country_transfers": []
            },
            {
                "name": "Kommunikationshistorie",
                "purpose": "Speicherung von Kundeninteraktionen",
                "legal_basis": "Berechtigtes Interesse (Art. 6(1)(f))",
                "data_categories": ["Nachrichten", "Telefonate", "Meetings"],
                "retention": "2 Jahre nach letztem Kontakt",
                "recipients": ["Interne Mitarbeiter"],
                "third_country_transfers": []
            }
        ],
        "last_updated": "2024-01-01"
    }


# ============================================================
# Helper Functions
# ============================================================

async def send_verification_email(
    email: str,
    request_id: str,
    token: str,
    request_type: str
):
    """Sendet Verifizierungs-Email (Placeholder)"""
    logger.info(f"Sending verification email to {email} for {request_type} request {request_id}")
    # In Production: Email Service aufrufen
    # await email_service.send_template(
    #     to=email,
    #     template="gdpr_verification",
    #     data={
    #         "request_id": request_id,
    #         "token": token,
    #         "type": request_type,
    #         "verification_link": f"https://app.salesflow.ai/gdpr/verify?id={request_id}&token={token}"
    #     }
    # )


async def execute_access_request(
    gdpr_manager: GDPRComplianceManager,
    request_id: str
):
    """Führt Auskunftsanfrage aus (Background)"""
    try:
        export = await gdpr_manager.fulfill_access_request(request_id)
        logger.info(f"Access request {request_id} completed")
        # Email mit Export-Link senden
    except Exception as e:
        logger.error(f"Access request {request_id} failed: {e}")


async def execute_deletion_request(
    gdpr_manager: GDPRComplianceManager,
    request_id: str
):
    """Führt Löschanfrage aus (Background)"""
    try:
        report = await gdpr_manager.execute_deletion_request(request_id)
        logger.info(f"Deletion request {request_id} completed: {report}")
        # Bestätigungs-Email senden
    except Exception as e:
        logger.error(f"Deletion request {request_id} failed: {e}")
