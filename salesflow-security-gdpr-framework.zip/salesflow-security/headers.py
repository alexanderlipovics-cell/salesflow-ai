"""
SalesFlow AI - Security Headers Configuration
==============================================
Enterprise-Grade Security Headers für Zero-Trust Architecture.

Implementiert:
- Content Security Policy (CSP) Level 3
- HTTP Strict Transport Security (HSTS)
- X-Frame-Options
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- Cross-Origin Policies
"""

from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import base64
import secrets


class CSPDirective(Enum):
    """CSP Directives"""
    DEFAULT_SRC = "default-src"
    SCRIPT_SRC = "script-src"
    STYLE_SRC = "style-src"
    IMG_SRC = "img-src"
    FONT_SRC = "font-src"
    CONNECT_SRC = "connect-src"
    MEDIA_SRC = "media-src"
    OBJECT_SRC = "object-src"
    FRAME_SRC = "frame-src"
    FRAME_ANCESTORS = "frame-ancestors"
    BASE_URI = "base-uri"
    FORM_ACTION = "form-action"
    WORKER_SRC = "worker-src"
    MANIFEST_SRC = "manifest-src"
    REPORT_URI = "report-uri"
    REPORT_TO = "report-to"


@dataclass
class CSPPolicy:
    """
    Content Security Policy Builder.
    Level 3 compliant mit Nonce-Support.
    """
    
    default_src: List[str] = field(default_factory=lambda: ["'self'"])
    script_src: List[str] = field(default_factory=lambda: ["'self'"])
    style_src: List[str] = field(default_factory=lambda: ["'self'"])
    img_src: List[str] = field(default_factory=lambda: ["'self'", "data:"])
    font_src: List[str] = field(default_factory=lambda: ["'self'"])
    connect_src: List[str] = field(default_factory=lambda: ["'self'"])
    media_src: List[str] = field(default_factory=lambda: ["'none'"])
    object_src: List[str] = field(default_factory=lambda: ["'none'"])
    frame_src: List[str] = field(default_factory=lambda: ["'none'"])
    frame_ancestors: List[str] = field(default_factory=lambda: ["'none'"])
    base_uri: List[str] = field(default_factory=lambda: ["'self'"])
    form_action: List[str] = field(default_factory=lambda: ["'self'"])
    worker_src: List[str] = field(default_factory=lambda: ["'self'"])
    report_uri: Optional[str] = None
    report_to: Optional[str] = None
    
    # Nonce für inline Scripts/Styles
    _nonce: Optional[str] = None
    
    def generate_nonce(self) -> str:
        """Generiert kryptographisch sicheren Nonce"""
        self._nonce = base64.b64encode(secrets.token_bytes(16)).decode('utf-8')
        return self._nonce
    
    def get_nonce(self) -> Optional[str]:
        """Gibt aktuellen Nonce zurück"""
        return self._nonce
    
    def add_script_hash(self, script_content: str) -> str:
        """
        Berechnet SHA-256 Hash für Inline-Script.
        Für CSP script-src Hash-basierte Allowlist.
        """
        hash_bytes = hashlib.sha256(script_content.encode()).digest()
        hash_b64 = base64.b64encode(hash_bytes).decode('utf-8')
        hash_directive = f"'sha256-{hash_b64}'"
        
        if hash_directive not in self.script_src:
            self.script_src.append(hash_directive)
        
        return hash_directive
    
    def build(self) -> str:
        """Baut CSP Header String"""
        directives = []
        
        # Füge Nonce zu script-src und style-src hinzu
        script_src = self.script_src.copy()
        style_src = self.style_src.copy()
        
        if self._nonce:
            nonce_directive = f"'nonce-{self._nonce}'"
            script_src.append(nonce_directive)
            style_src.append(nonce_directive)
        
        directive_map = {
            "default-src": self.default_src,
            "script-src": script_src,
            "style-src": style_src,
            "img-src": self.img_src,
            "font-src": self.font_src,
            "connect-src": self.connect_src,
            "media-src": self.media_src,
            "object-src": self.object_src,
            "frame-src": self.frame_src,
            "frame-ancestors": self.frame_ancestors,
            "base-uri": self.base_uri,
            "form-action": self.form_action,
            "worker-src": self.worker_src,
        }
        
        for directive, values in directive_map.items():
            if values:
                directives.append(f"{directive} {' '.join(values)}")
        
        if self.report_uri:
            directives.append(f"report-uri {self.report_uri}")
        
        if self.report_to:
            directives.append(f"report-to {self.report_to}")
        
        return "; ".join(directives)


@dataclass
class SecurityHeadersConfig:
    """
    Vollständige Security Headers Konfiguration.
    """
    
    # HSTS Configuration
    hsts_max_age: int = 31536000  # 1 Jahr
    hsts_include_subdomains: bool = True
    hsts_preload: bool = True
    
    # X-Frame-Options
    frame_options: str = "DENY"  # DENY, SAMEORIGIN, ALLOW-FROM
    
    # X-Content-Type-Options
    content_type_nosniff: bool = True
    
    # X-XSS-Protection (deprecated but still useful for old browsers)
    xss_protection: str = "1; mode=block"
    
    # Referrer-Policy
    referrer_policy: str = "strict-origin-when-cross-origin"
    
    # Permissions-Policy (formerly Feature-Policy)
    permissions_policy: Dict[str, List[str]] = field(default_factory=dict)
    
    # Cross-Origin Policies
    cross_origin_embedder_policy: str = "require-corp"
    cross_origin_opener_policy: str = "same-origin"
    cross_origin_resource_policy: str = "same-origin"
    
    # CSP
    csp: CSPPolicy = field(default_factory=CSPPolicy)
    csp_report_only: bool = False
    
    # Cache Control for sensitive pages
    cache_control: str = "no-store, no-cache, must-revalidate, private"
    pragma: str = "no-cache"
    
    def __post_init__(self):
        if not self.permissions_policy:
            self.permissions_policy = {
                "accelerometer": [],
                "camera": [],
                "geolocation": [],
                "gyroscope": [],
                "magnetometer": [],
                "microphone": [],
                "payment": ["self"],
                "usb": [],
                "interest-cohort": [],  # Disable FLoC
            }


class SecurityHeadersBuilder:
    """
    Builder für Security Headers.
    Generiert Headers basierend auf Konfiguration.
    """
    
    def __init__(self, config: Optional[SecurityHeadersConfig] = None):
        self.config = config or SecurityHeadersConfig()
    
    def build_headers(self, include_csp_nonce: bool = True) -> Dict[str, str]:
        """
        Baut alle Security Headers.
        
        Args:
            include_csp_nonce: Generiert neuen CSP Nonce
            
        Returns:
            Dictionary mit allen Headers
        """
        headers = {}
        
        # HSTS
        hsts_value = f"max-age={self.config.hsts_max_age}"
        if self.config.hsts_include_subdomains:
            hsts_value += "; includeSubDomains"
        if self.config.hsts_preload:
            hsts_value += "; preload"
        headers["Strict-Transport-Security"] = hsts_value
        
        # X-Frame-Options
        headers["X-Frame-Options"] = self.config.frame_options
        
        # X-Content-Type-Options
        if self.config.content_type_nosniff:
            headers["X-Content-Type-Options"] = "nosniff"
        
        # X-XSS-Protection
        headers["X-XSS-Protection"] = self.config.xss_protection
        
        # Referrer-Policy
        headers["Referrer-Policy"] = self.config.referrer_policy
        
        # Permissions-Policy
        permissions = []
        for feature, allowed in self.config.permissions_policy.items():
            if not allowed:
                permissions.append(f"{feature}=()")
            else:
                allowed_str = " ".join(allowed)
                permissions.append(f"{feature}=({allowed_str})")
        headers["Permissions-Policy"] = ", ".join(permissions)
        
        # Cross-Origin Policies
        headers["Cross-Origin-Embedder-Policy"] = self.config.cross_origin_embedder_policy
        headers["Cross-Origin-Opener-Policy"] = self.config.cross_origin_opener_policy
        headers["Cross-Origin-Resource-Policy"] = self.config.cross_origin_resource_policy
        
        # CSP
        if include_csp_nonce:
            self.config.csp.generate_nonce()
        
        csp_header = "Content-Security-Policy"
        if self.config.csp_report_only:
            csp_header = "Content-Security-Policy-Report-Only"
        headers[csp_header] = self.config.csp.build()
        
        # Cache Control
        headers["Cache-Control"] = self.config.cache_control
        headers["Pragma"] = self.config.pragma
        
        # Additional Security Headers
        headers["X-DNS-Prefetch-Control"] = "off"
        headers["X-Download-Options"] = "noopen"
        headers["X-Permitted-Cross-Domain-Policies"] = "none"
        
        return headers
    
    def get_csp_nonce(self) -> Optional[str]:
        """Gibt aktuellen CSP Nonce zurück"""
        return self.config.csp.get_nonce()


# Preset Configurations
class SecurityPresets:
    """
    Vordefinierte Security-Konfigurationen.
    """
    
    @staticmethod
    def strict() -> SecurityHeadersConfig:
        """Maximale Sicherheit - für sensitive Bereiche"""
        csp = CSPPolicy(
            default_src=["'none'"],
            script_src=["'self'"],
            style_src=["'self'"],
            img_src=["'self'"],
            font_src=["'self'"],
            connect_src=["'self'"],
            media_src=["'none'"],
            object_src=["'none'"],
            frame_src=["'none'"],
            frame_ancestors=["'none'"],
            base_uri=["'self'"],
            form_action=["'self'"],
        )
        
        return SecurityHeadersConfig(
            csp=csp,
            frame_options="DENY",
            referrer_policy="no-referrer",
        )
    
    @staticmethod
    def standard() -> SecurityHeadersConfig:
        """Standard-Sicherheit - für normale Seiten"""
        csp = CSPPolicy(
            default_src=["'self'"],
            script_src=["'self'", "'unsafe-inline'"],  # Für Legacy Support
            style_src=["'self'", "'unsafe-inline'"],
            img_src=["'self'", "data:", "https:"],
            font_src=["'self'", "https://fonts.gstatic.com"],
            connect_src=["'self'", "https://api.salesflow.ai"],
        )
        
        return SecurityHeadersConfig(csp=csp)
    
    @staticmethod
    def api() -> SecurityHeadersConfig:
        """API-Konfiguration - keine HTML-spezifischen Headers"""
        csp = CSPPolicy(
            default_src=["'none'"],
            frame_ancestors=["'none'"],
        )
        
        return SecurityHeadersConfig(
            csp=csp,
            frame_options="DENY",
            referrer_policy="no-referrer",
            cache_control="no-store",
        )
    
    @staticmethod
    def salesflow_production() -> SecurityHeadersConfig:
        """
        SalesFlow AI Production Configuration.
        Optimiert für CRM mit AI-Features.
        """
        csp = CSPPolicy(
            default_src=["'self'"],
            script_src=[
                "'self'",
                "https://cdn.salesflow.ai",
                "https://analytics.salesflow.ai",
            ],
            style_src=[
                "'self'",
                "'unsafe-inline'",  # Für dynamische Styles
                "https://cdn.salesflow.ai",
                "https://fonts.googleapis.com",
            ],
            img_src=[
                "'self'",
                "data:",
                "blob:",
                "https://cdn.salesflow.ai",
                "https://*.gravatar.com",
                "https://ui-avatars.com",
            ],
            font_src=[
                "'self'",
                "https://cdn.salesflow.ai",
                "https://fonts.gstatic.com",
            ],
            connect_src=[
                "'self'",
                "https://api.salesflow.ai",
                "https://ai.salesflow.ai",
                "https://analytics.salesflow.ai",
                "wss://realtime.salesflow.ai",
            ],
            media_src=["'self'", "https://cdn.salesflow.ai"],
            frame_src=["'self'"],  # Für eingebettete Kalender etc.
            frame_ancestors=["'self'"],
            worker_src=["'self'", "blob:"],
            report_uri="https://csp-report.salesflow.ai/report",
        )
        
        permissions = {
            "accelerometer": [],
            "camera": ["self"],  # Für Video-Calls
            "geolocation": ["self"],  # Für Location-Features
            "gyroscope": [],
            "magnetometer": [],
            "microphone": ["self"],  # Für Voice-Notes
            "payment": [],
            "usb": [],
            "interest-cohort": [],
        }
        
        return SecurityHeadersConfig(
            csp=csp,
            permissions_policy=permissions,
            hsts_max_age=63072000,  # 2 Jahre
            hsts_preload=True,
        )


# FastAPI Middleware
class SecurityHeadersMiddleware:
    """
    FastAPI Middleware für Security Headers.
    """
    
    def __init__(
        self,
        app,
        config: Optional[SecurityHeadersConfig] = None,
        exclude_paths: Optional[Set[str]] = None
    ):
        self.app = app
        self.builder = SecurityHeadersBuilder(
            config or SecurityPresets.salesflow_production()
        )
        self.exclude_paths = exclude_paths or {"/health", "/metrics"}
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        path = scope.get("path", "")
        
        # Skip für excluded paths
        if path in self.exclude_paths:
            await self.app(scope, receive, send)
            return
        
        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                headers = dict(message.get("headers", []))
                
                # Füge Security Headers hinzu
                security_headers = self.builder.build_headers()
                for name, value in security_headers.items():
                    headers[name.lower().encode()] = value.encode()
                
                message["headers"] = list(headers.items())
            
            await send(message)
        
        await self.app(scope, receive, send_with_headers)


# Helper für Template Rendering
def get_csp_nonce_for_template(request) -> str:
    """
    Gibt CSP Nonce für Template zurück.
    Für Inline-Scripts in Templates.
    
    Usage in Jinja2:
        <script nonce="{{ csp_nonce }}">
            // Inline script
        </script>
    """
    nonce = getattr(request.state, 'csp_nonce', None)
    if not nonce:
        builder = SecurityHeadersBuilder()
        nonce = builder.config.csp.generate_nonce()
        request.state.csp_nonce = nonce
    return nonce


# CSP Violation Report Handler
async def handle_csp_report(report: dict) -> None:
    """
    Handler für CSP Violation Reports.
    Loggt Violations für Monitoring.
    """
    import logging
    logger = logging.getLogger("csp_violations")
    
    violated_directive = report.get("violated-directive", "unknown")
    blocked_uri = report.get("blocked-uri", "unknown")
    document_uri = report.get("document-uri", "unknown")
    
    logger.warning(
        f"CSP Violation: {violated_directive} blocked {blocked_uri} "
        f"on {document_uri}"
    )
