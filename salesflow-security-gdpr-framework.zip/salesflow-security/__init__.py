"""
SalesFlow AI - Security Module
==============================
Enterprise-Grade Security & GDPR Compliance Framework.

Components:
- Field-Level Encryption (AES-256-GCM)
- GDPR Compliance (Art. 15, 17, 20)
- Audit Logging (SOC 2 Ready)
- Consent Management
- Security Headers
- Advanced Rate Limiting
"""

from .encryption import (
    # Enums
    SensitivityLevel,
    
    # Data Classes
    EncryptedField,
    EncryptionKey,
    
    # Services
    KeyDerivationService,
    FieldEncryptionEngine,
    KeyRotationManager,
    TransparentEncryptionProxy,
    BackupEncryption,
    
    # Factory
    create_encryption_system,
    generate_master_key,
)

from .gdpr import (
    # Enums
    DataCategory,
    LegalBasis,
    DeletionStatus,
    
    # Data Classes
    DataSubjectRequest,
    ProcessingActivity,
    
    # Services
    DeletionCascade,
    DataExporter,
    DataMinimizer,
    GDPRComplianceManager,
)

from .audit import (
    # Enums
    AuditAction,
    AuditSeverity,
    
    # Data Classes
    AuditEntry,
    
    # Services
    HashChain,
    AuditStorage,
    InMemoryAuditStorage,
    AuditLogger,
    AuditQueryBuilder,
    SensitiveDataAccessLogger,
    
    # Factory
    create_audit_system,
)

from .consent import (
    # Enums
    ConsentPurpose,
    ConsentStatus,
    
    # Data Classes
    ConsentMetadata,
    ConsentRecord,
    ConsentBundle,
    
    # Services
    ConsentPolicy,
    DoubleOptInManager,
    ConsentStorage,
    ConsentManager,
    ConsentMiddleware,
    
    # Factory
    create_consent_system,
)

from .headers import (
    # Enums
    CSPDirective,
    
    # Data Classes
    CSPPolicy,
    SecurityHeadersConfig,
    
    # Services
    SecurityHeadersBuilder,
    SecurityPresets,
    SecurityHeadersMiddleware,
    
    # Helpers
    get_csp_nonce_for_template,
    handle_csp_report,
)

from .rate_limit import (
    # Enums
    RateLimitTier,
    
    # Data Classes
    RateLimitConfig,
    EndpointLimit,
    
    # Services
    SlidingWindowCounter,
    TokenBucket,
    RateLimiter,
    AIInjectionProtector,
    RateLimitMiddleware,
    
    # Factory
    create_rate_limit_system,
)


__all__ = [
    # Encryption
    "SensitivityLevel",
    "EncryptedField",
    "EncryptionKey",
    "KeyDerivationService",
    "FieldEncryptionEngine",
    "KeyRotationManager",
    "TransparentEncryptionProxy",
    "BackupEncryption",
    "create_encryption_system",
    "generate_master_key",
    
    # GDPR
    "DataCategory",
    "LegalBasis",
    "DeletionStatus",
    "DataSubjectRequest",
    "ProcessingActivity",
    "DeletionCascade",
    "DataExporter",
    "DataMinimizer",
    "GDPRComplianceManager",
    
    # Audit
    "AuditAction",
    "AuditSeverity",
    "AuditEntry",
    "HashChain",
    "AuditStorage",
    "InMemoryAuditStorage",
    "AuditLogger",
    "AuditQueryBuilder",
    "SensitiveDataAccessLogger",
    "create_audit_system",
    
    # Consent
    "ConsentPurpose",
    "ConsentStatus",
    "ConsentMetadata",
    "ConsentRecord",
    "ConsentBundle",
    "ConsentPolicy",
    "DoubleOptInManager",
    "ConsentStorage",
    "ConsentManager",
    "ConsentMiddleware",
    "create_consent_system",
    
    # Headers
    "CSPDirective",
    "CSPPolicy",
    "SecurityHeadersConfig",
    "SecurityHeadersBuilder",
    "SecurityPresets",
    "SecurityHeadersMiddleware",
    "get_csp_nonce_for_template",
    "handle_csp_report",
    
    # Rate Limit
    "RateLimitTier",
    "RateLimitConfig",
    "EndpointLimit",
    "SlidingWindowCounter",
    "TokenBucket",
    "RateLimiter",
    "AIInjectionProtector",
    "RateLimitMiddleware",
    "create_rate_limit_system",
]


# Version
__version__ = "1.0.0"
