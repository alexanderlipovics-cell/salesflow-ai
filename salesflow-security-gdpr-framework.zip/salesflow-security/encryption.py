"""
SalesFlow AI - Field-Level Encryption System
=============================================
FIPS 140-2 compliant AES-256-GCM encryption für sensitive PII Felder.
Tenant-isolierte Keys mit automatischer Key-Rotation.

Performance Target: <10ms Encryption Overhead
"""

import os
import base64
import hashlib
import secrets
import json
from datetime import datetime, timedelta
from typing import Any, Optional, Dict, List, Tuple
from dataclasses import dataclass, field
from functools import lru_cache
from enum import Enum
import struct

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet
import asyncio
from concurrent.futures import ThreadPoolExecutor


class SensitivityLevel(Enum):
    """Klassifizierung der Datensensitivität nach DSGVO Art. 9"""
    PUBLIC = "public"                    # Öffentlich zugänglich
    INTERNAL = "internal"                # Intern, nicht sensitiv
    CONFIDENTIAL = "confidential"        # Vertraulich (normale PII)
    PII_SENSITIVE = "pii_sensitive"      # Besonders schützenswert
    HEALTH_DATA = "health_data"          # Art. 9 - Gesundheitsdaten
    FINANCIAL = "financial"              # Finanzdaten


@dataclass
class EncryptedField:
    """Container für verschlüsselte Daten mit Metadaten"""
    ciphertext: bytes
    nonce: bytes
    key_version: int
    tenant_id: str
    sensitivity: SensitivityLevel
    encrypted_at: datetime
    algorithm: str = "AES-256-GCM"
    
    def to_storage_format(self) -> str:
        """Serialisiert für DB-Speicherung"""
        payload = {
            "v": self.key_version,
            "t": self.tenant_id,
            "s": self.sensitivity.value,
            "a": self.algorithm,
            "ts": self.encrypted_at.isoformat(),
            "n": base64.b64encode(self.nonce).decode('utf-8'),
            "c": base64.b64encode(self.ciphertext).decode('utf-8')
        }
        return f"$ENC${base64.b64encode(json.dumps(payload).encode()).decode()}"
    
    @classmethod
    def from_storage_format(cls, data: str) -> 'EncryptedField':
        """Deserialisiert aus DB-Format"""
        if not data.startswith("$ENC$"):
            raise ValueError("Invalid encrypted field format")
        
        payload = json.loads(base64.b64decode(data[5:]).decode())
        return cls(
            ciphertext=base64.b64decode(payload["c"]),
            nonce=base64.b64decode(payload["n"]),
            key_version=payload["v"],
            tenant_id=payload["t"],
            sensitivity=SensitivityLevel(payload["s"]),
            encrypted_at=datetime.fromisoformat(payload["ts"]),
            algorithm=payload["a"]
        )


@dataclass
class EncryptionKey:
    """Verschlüsselungs-Key mit Metadaten"""
    key_id: str
    key_material: bytes
    version: int
    tenant_id: str
    created_at: datetime
    expires_at: datetime
    is_active: bool = True
    rotation_scheduled: Optional[datetime] = None
    
    def is_expired(self) -> bool:
        return datetime.utcnow() > self.expires_at
    
    def needs_rotation(self) -> bool:
        if self.rotation_scheduled:
            return datetime.utcnow() > self.rotation_scheduled
        # Default: Rotation nach 90 Tagen
        return (datetime.utcnow() - self.created_at) > timedelta(days=90)


class KeyDerivationService:
    """
    Hierarchisches Key Management nach NIST SP 800-108.
    Master Key -> Tenant Key -> Field Key
    """
    
    def __init__(self, master_key: bytes):
        if len(master_key) != 32:
            raise ValueError("Master key must be 256 bits (32 bytes)")
        self._master_key = master_key
        
    def derive_tenant_key(self, tenant_id: str, version: int = 1) -> bytes:
        """Leitet Tenant-spezifischen Key vom Master Key ab"""
        context = f"salesflow:tenant:{tenant_id}:v{version}".encode()
        
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=hashlib.sha256(tenant_id.encode()).digest(),
            info=context,
            backend=default_backend()
        )
        return hkdf.derive(self._master_key)
    
    def derive_field_key(self, tenant_key: bytes, field_name: str) -> bytes:
        """Leitet Field-spezifischen Key vom Tenant Key ab"""
        context = f"salesflow:field:{field_name}".encode()
        
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=context,
            backend=default_backend()
        )
        return hkdf.derive(tenant_key)


class FieldEncryptionEngine:
    """
    AES-256-GCM Encryption Engine für Field-Level Encryption.
    Thread-safe mit Connection Pooling für Performance.
    """
    
    def __init__(self, key_service: KeyDerivationService):
        self._key_service = key_service
        self._key_cache: Dict[str, Tuple[bytes, datetime]] = {}
        self._cache_ttl = timedelta(minutes=5)
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._lock = asyncio.Lock()
    
    def _get_cached_key(self, tenant_id: str, version: int) -> Optional[bytes]:
        """Holt Key aus Cache wenn noch gültig"""
        cache_key = f"{tenant_id}:v{version}"
        if cache_key in self._key_cache:
            key, cached_at = self._key_cache[cache_key]
            if datetime.utcnow() - cached_at < self._cache_ttl:
                return key
            del self._key_cache[cache_key]
        return None
    
    def _cache_key(self, tenant_id: str, version: int, key: bytes):
        """Speichert Key im Cache"""
        cache_key = f"{tenant_id}:v{version}"
        self._key_cache[cache_key] = (key, datetime.utcnow())
        
        # Cache Cleanup - max 1000 Einträge
        if len(self._key_cache) > 1000:
            oldest = sorted(self._key_cache.items(), key=lambda x: x[1][1])[:100]
            for k, _ in oldest:
                del self._key_cache[k]
    
    def encrypt(
        self,
        plaintext: str,
        tenant_id: str,
        sensitivity: SensitivityLevel,
        key_version: int = 1,
        associated_data: Optional[bytes] = None
    ) -> EncryptedField:
        """
        Verschlüsselt Plaintext mit AES-256-GCM.
        
        Args:
            plaintext: Zu verschlüsselnde Daten
            tenant_id: Tenant-Identifier für Key-Isolation
            sensitivity: Sensitivitätslevel nach DSGVO
            key_version: Key Version für Rotation
            associated_data: AAD für authentifizierte Verschlüsselung
            
        Returns:
            EncryptedField mit allen Metadaten
        """
        # Key aus Cache oder neu ableiten
        key = self._get_cached_key(tenant_id, key_version)
        if not key:
            key = self._key_service.derive_tenant_key(tenant_id, key_version)
            self._cache_key(tenant_id, key_version, key)
        
        # 96-bit Nonce (NIST empfohlen für GCM)
        nonce = secrets.token_bytes(12)
        
        # AES-256-GCM Encryption
        aesgcm = AESGCM(key)
        
        # AAD enthält Metadaten für Integritätsprüfung
        aad = associated_data or f"{tenant_id}:{sensitivity.value}".encode()
        
        ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), aad)
        
        return EncryptedField(
            ciphertext=ciphertext,
            nonce=nonce,
            key_version=key_version,
            tenant_id=tenant_id,
            sensitivity=sensitivity,
            encrypted_at=datetime.utcnow()
        )
    
    def decrypt(
        self,
        encrypted: EncryptedField,
        associated_data: Optional[bytes] = None
    ) -> str:
        """
        Entschlüsselt EncryptedField zurück zu Plaintext.
        
        Args:
            encrypted: Verschlüsselte Daten mit Metadaten
            associated_data: Muss mit Encryption AAD übereinstimmen
            
        Returns:
            Entschlüsselter Plaintext
        """
        key = self._get_cached_key(encrypted.tenant_id, encrypted.key_version)
        if not key:
            key = self._key_service.derive_tenant_key(
                encrypted.tenant_id, 
                encrypted.key_version
            )
            self._cache_key(encrypted.tenant_id, encrypted.key_version, key)
        
        aesgcm = AESGCM(key)
        
        aad = associated_data or f"{encrypted.tenant_id}:{encrypted.sensitivity.value}".encode()
        
        plaintext = aesgcm.decrypt(encrypted.nonce, encrypted.ciphertext, aad)
        
        return plaintext.decode('utf-8')
    
    async def encrypt_async(
        self,
        plaintext: str,
        tenant_id: str,
        sensitivity: SensitivityLevel,
        key_version: int = 1
    ) -> EncryptedField:
        """Async Wrapper für nicht-blockierende Encryption"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor,
            self.encrypt,
            plaintext, tenant_id, sensitivity, key_version, None
        )
    
    async def decrypt_async(self, encrypted: EncryptedField) -> str:
        """Async Wrapper für nicht-blockierende Decryption"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor,
            self.decrypt,
            encrypted, None
        )


class KeyRotationManager:
    """
    Automatische Key-Rotation mit Zero-Downtime.
    Unterstützt Re-Encryption bestehender Daten.
    """
    
    def __init__(
        self,
        key_service: KeyDerivationService,
        encryption_engine: FieldEncryptionEngine
    ):
        self._key_service = key_service
        self._engine = encryption_engine
        self._active_versions: Dict[str, int] = {}  # tenant_id -> active_version
    
    def get_active_version(self, tenant_id: str) -> int:
        """Gibt aktive Key-Version für Tenant zurück"""
        return self._active_versions.get(tenant_id, 1)
    
    def rotate_key(self, tenant_id: str) -> int:
        """
        Rotiert Key für Tenant.
        Alte Version bleibt für Decryption verfügbar.
        
        Returns:
            Neue Key-Version
        """
        current = self.get_active_version(tenant_id)
        new_version = current + 1
        self._active_versions[tenant_id] = new_version
        
        return new_version
    
    def re_encrypt(
        self,
        encrypted: EncryptedField,
        new_version: Optional[int] = None
    ) -> EncryptedField:
        """
        Re-Encrypted Daten mit neuer Key-Version.
        Für Batch-Migration nach Key-Rotation.
        """
        # Decrypt mit alter Version
        plaintext = self._engine.decrypt(encrypted)
        
        # Encrypt mit neuer Version
        target_version = new_version or self.get_active_version(encrypted.tenant_id)
        
        return self._engine.encrypt(
            plaintext=plaintext,
            tenant_id=encrypted.tenant_id,
            sensitivity=encrypted.sensitivity,
            key_version=target_version
        )
    
    async def batch_re_encrypt(
        self,
        encrypted_fields: List[EncryptedField],
        new_version: int,
        batch_size: int = 100
    ) -> List[EncryptedField]:
        """
        Batch Re-Encryption für große Datenmengen.
        Verarbeitet in Batches für Memory-Effizienz.
        """
        results = []
        
        for i in range(0, len(encrypted_fields), batch_size):
            batch = encrypted_fields[i:i + batch_size]
            
            tasks = [
                asyncio.create_task(
                    self._async_re_encrypt(ef, new_version)
                )
                for ef in batch
            ]
            
            batch_results = await asyncio.gather(*tasks)
            results.extend(batch_results)
            
            # Yield control für andere Tasks
            await asyncio.sleep(0)
        
        return results
    
    async def _async_re_encrypt(
        self,
        encrypted: EncryptedField,
        new_version: int
    ) -> EncryptedField:
        """Async Re-Encryption Helper"""
        plaintext = await self._engine.decrypt_async(encrypted)
        return await self._engine.encrypt_async(
            plaintext=plaintext,
            tenant_id=encrypted.tenant_id,
            sensitivity=encrypted.sensitivity,
            key_version=new_version
        )


class TransparentEncryptionProxy:
    """
    SQLAlchemy-kompatible Transparent Encryption.
    App sieht Plaintext, DB speichert Ciphertext.
    """
    
    SENSITIVE_FIELDS = {
        # Tabelle -> [Felder]
        "leads": ["personal_notes", "health_info", "income_data"],
        "contacts": ["notes", "sensitive_tags"],
        "conversations": ["ai_summary", "sentiment_analysis"],
        "users": ["phone_number", "address"],
        "financial_records": ["amount", "commission", "bonus"],
    }
    
    FIELD_SENSITIVITY = {
        "personal_notes": SensitivityLevel.PII_SENSITIVE,
        "health_info": SensitivityLevel.HEALTH_DATA,
        "income_data": SensitivityLevel.FINANCIAL,
        "notes": SensitivityLevel.CONFIDENTIAL,
        "sensitive_tags": SensitivityLevel.PII_SENSITIVE,
        "ai_summary": SensitivityLevel.CONFIDENTIAL,
        "sentiment_analysis": SensitivityLevel.CONFIDENTIAL,
        "phone_number": SensitivityLevel.PII_SENSITIVE,
        "address": SensitivityLevel.PII_SENSITIVE,
        "amount": SensitivityLevel.FINANCIAL,
        "commission": SensitivityLevel.FINANCIAL,
        "bonus": SensitivityLevel.FINANCIAL,
    }
    
    def __init__(self, encryption_engine: FieldEncryptionEngine):
        self._engine = encryption_engine
    
    def is_encrypted(self, value: str) -> bool:
        """Prüft ob Wert bereits verschlüsselt ist"""
        return isinstance(value, str) and value.startswith("$ENC$")
    
    def should_encrypt(self, table: str, field: str) -> bool:
        """Prüft ob Feld verschlüsselt werden soll"""
        return field in self.SENSITIVE_FIELDS.get(table, [])
    
    def encrypt_field(
        self,
        value: Any,
        table: str,
        field: str,
        tenant_id: str
    ) -> str:
        """Verschlüsselt Feldwert wenn nötig"""
        if value is None:
            return None
        
        if not self.should_encrypt(table, field):
            return value
        
        if self.is_encrypted(str(value)):
            return value
        
        sensitivity = self.FIELD_SENSITIVITY.get(
            field, 
            SensitivityLevel.CONFIDENTIAL
        )
        
        encrypted = self._engine.encrypt(
            plaintext=str(value),
            tenant_id=tenant_id,
            sensitivity=sensitivity
        )
        
        return encrypted.to_storage_format()
    
    def decrypt_field(self, value: str) -> str:
        """Entschlüsselt Feldwert wenn nötig"""
        if value is None:
            return None
        
        if not self.is_encrypted(value):
            return value
        
        encrypted = EncryptedField.from_storage_format(value)
        return self._engine.decrypt(encrypted)
    
    def encrypt_row(
        self,
        table: str,
        row: Dict[str, Any],
        tenant_id: str
    ) -> Dict[str, Any]:
        """Verschlüsselt alle sensitiven Felder in einer Row"""
        result = row.copy()
        
        for field in self.SENSITIVE_FIELDS.get(table, []):
            if field in result:
                result[field] = self.encrypt_field(
                    result[field], table, field, tenant_id
                )
        
        return result
    
    def decrypt_row(self, table: str, row: Dict[str, Any]) -> Dict[str, Any]:
        """Entschlüsselt alle sensitiven Felder in einer Row"""
        result = row.copy()
        
        for field in self.SENSITIVE_FIELDS.get(table, []):
            if field in result:
                result[field] = self.decrypt_field(result[field])
        
        return result


class BackupEncryption:
    """
    Verschlüsselung für Backup/Restore Operationen.
    Verwendet separate Backup-Keys für Defense in Depth.
    """
    
    def __init__(self, backup_key: bytes):
        if len(backup_key) != 32:
            raise ValueError("Backup key must be 256 bits")
        self._fernet = Fernet(base64.urlsafe_b64encode(backup_key))
    
    def encrypt_backup(self, data: bytes) -> bytes:
        """Verschlüsselt Backup-Daten"""
        return self._fernet.encrypt(data)
    
    def decrypt_backup(self, encrypted: bytes) -> bytes:
        """Entschlüsselt Backup-Daten"""
        return self._fernet.decrypt(encrypted)
    
    def create_encrypted_export(
        self,
        rows: List[Dict[str, Any]],
        metadata: Dict[str, Any]
    ) -> bytes:
        """
        Erstellt verschlüsselten Export für DSGVO Data Portability.
        """
        export_data = {
            "version": "1.0",
            "exported_at": datetime.utcnow().isoformat(),
            "metadata": metadata,
            "data": rows
        }
        
        serialized = json.dumps(export_data, default=str).encode('utf-8')
        return self.encrypt_backup(serialized)


# Factory Functions für einfache Initialisierung
def create_encryption_system(master_key_hex: str) -> Tuple[
    KeyDerivationService,
    FieldEncryptionEngine,
    KeyRotationManager,
    TransparentEncryptionProxy
]:
    """
    Factory für komplettes Encryption System.
    
    Args:
        master_key_hex: 64-Zeichen Hex String (256 bit)
        
    Returns:
        Tuple mit allen Komponenten
    """
    master_key = bytes.fromhex(master_key_hex)
    
    key_service = KeyDerivationService(master_key)
    engine = FieldEncryptionEngine(key_service)
    rotation_manager = KeyRotationManager(key_service, engine)
    proxy = TransparentEncryptionProxy(engine)
    
    return key_service, engine, rotation_manager, proxy


def generate_master_key() -> str:
    """Generiert kryptographisch sicheren Master Key"""
    return secrets.token_hex(32)
