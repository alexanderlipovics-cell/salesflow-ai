// ============================================
// 🔍 RAPIDAPI LEAD FINDER - Netlify Function
// Real Lead Discovery from Social Media
// ============================================

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// RapidAPI Keys
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY;

// API Endpoints
const APIS = {
  instagram: {
    search: 'https://instagram-scraper-api2.p.rapidapi.com/v1/search_users',
    profile: 'https://instagram-scraper-api2.p.rapidapi.com/v1/info',
    host: 'instagram-scraper-api2.p.rapidapi.com'
  },
  linkedin: {
    search: 'https://linkedin-data-api.p.rapidapi.com/search-people',
    profile: 'https://linkedin-data-api.p.rapidapi.com/get-profile-data-by-url',
    host: 'linkedin-data-api.p.rapidapi.com'
  },
  tiktok: {
    search: 'https://tiktok-scraper7.p.rapidapi.com/user/search',
    profile: 'https://tiktok-scraper7.p.rapidapi.com/user/info',
    host: 'tiktok-scraper7.p.rapidapi.com'
  }
};

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK PLAN & API KEY
    // ============================================
    async function checkAccess(userId) {
      if (!RAPIDAPI_KEY) {
        return { allowed: false, reason: 'RapidAPI Key nicht konfiguriert' };
      }

      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';
      
      if (plan === 'free' || plan === 'pro') {
        return { allowed: false, reason: 'Lead Finder nur im Business Plan verfügbar' };
      }

      return { allowed: true };
    }

    // ============================================
    // SEARCH INSTAGRAM
    // ============================================
    if (action === 'search-instagram') {
      const { userId, keyword, limit = 10 } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      const response = await fetch(`${APIS.instagram.search}?search_query=${encodeURIComponent(keyword)}`, {
        headers: {
          'X-RapidAPI-Key': RAPIDAPI_KEY,
          'X-RapidAPI-Host': APIS.instagram.host
        }
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Instagram search failed');
      }

      // Transform results
      const leads = (result.data?.items || result.users || []).slice(0, limit).map(user => ({
        name: user.full_name || user.fullName || user.username,
        username: user.username,
        platform: 'instagram',
        followers: user.follower_count || user.followers || 0,
        bio: user.biography || user.bio || '',
        profile_url: `https://instagram.com/${user.username}`,
        profile_pic: user.profile_pic_url || user.profilePicUrl,
        is_verified: user.is_verified || false,
        is_business: user.is_business_account || user.is_professional_account || false
      }));

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ leads, total: leads.length })
      };
    }

    // ============================================
    // SEARCH LINKEDIN
    // ============================================
    if (action === 'search-linkedin') {
      const { userId, keyword, location, limit = 10 } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      const params = new URLSearchParams({
        keywords: keyword,
        ...(location && { geo: location }),
        start: '0'
      });

      const response = await fetch(`${APIS.linkedin.search}?${params}`, {
        headers: {
          'X-RapidAPI-Key': RAPIDAPI_KEY,
          'X-RapidAPI-Host': APIS.linkedin.host
        }
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'LinkedIn search failed');
      }

      const leads = (result.data || result.items || []).slice(0, limit).map(user => ({
        name: user.full_name || `${user.firstName || ''} ${user.lastName || ''}`.trim(),
        username: user.public_identifier || user.profileId,
        platform: 'linkedin',
        title: user.headline || user.title || '',
        company: user.company || user.current_company || '',
        location: user.location || '',
        profile_url: user.profile_url || `https://linkedin.com/in/${user.public_identifier}`,
        profile_pic: user.profile_picture || user.profilePicture,
        connections: user.connections_count || 0
      }));

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ leads, total: leads.length })
      };
    }

    // ============================================
    // SEARCH TIKTOK
    // ============================================
    if (action === 'search-tiktok') {
      const { userId, keyword, limit = 10 } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      const response = await fetch(`${APIS.tiktok.search}?keywords=${encodeURIComponent(keyword)}&count=${limit}`, {
        headers: {
          'X-RapidAPI-Key': RAPIDAPI_KEY,
          'X-RapidAPI-Host': APIS.tiktok.host
        }
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'TikTok search failed');
      }

      const leads = (result.data?.user_list || result.users || []).slice(0, limit).map(user => ({
        name: user.nickname || user.uniqueId,
        username: user.unique_id || user.uniqueId,
        platform: 'tiktok',
        followers: user.follower_count || user.followerCount || 0,
        likes: user.total_favorited || user.heartCount || 0,
        bio: user.signature || user.bio || '',
        profile_url: `https://tiktok.com/@${user.unique_id || user.uniqueId}`,
        profile_pic: user.avatar_thumb || user.avatarThumb,
        is_verified: user.verified || false
      }));

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ leads, total: leads.length })
      };
    }

    // ============================================
    // GET PROFILE DETAILS
    // ============================================
    if (action === 'get-profile') {
      const { userId, platform, username } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      let response, result;

      if (platform === 'instagram') {
        response = await fetch(`${APIS.instagram.profile}?username_or_id_or_url=${encodeURIComponent(username)}`, {
          headers: {
            'X-RapidAPI-Key': RAPIDAPI_KEY,
            'X-RapidAPI-Host': APIS.instagram.host
          }
        });
        result = await response.json();

        const user = result.data || result;
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            profile: {
              name: user.full_name,
              username: user.username,
              platform: 'instagram',
              bio: user.biography,
              followers: user.follower_count,
              following: user.following_count,
              posts: user.media_count,
              website: user.external_url,
              email: user.public_email,
              phone: user.public_phone_number,
              is_business: user.is_business_account,
              business_category: user.business_category_name,
              profile_pic: user.profile_pic_url_hd
            }
          })
        };
      }

      if (platform === 'linkedin') {
        response = await fetch(`${APIS.linkedin.profile}?url=${encodeURIComponent(`https://linkedin.com/in/${username}`)}`, {
          headers: {
            'X-RapidAPI-Key': RAPIDAPI_KEY,
            'X-RapidAPI-Host': APIS.linkedin.host
          }
        });
        result = await response.json();

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            profile: {
              name: `${result.firstName} ${result.lastName}`,
              username: result.publicIdentifier,
              platform: 'linkedin',
              title: result.headline,
              summary: result.summary,
              location: result.geo?.full,
              company: result.position?.[0]?.companyName,
              email: result.emailAddress,
              connections: result.connectionsCount,
              profile_pic: result.profilePicture
            }
          })
        };
      }

      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Platform not supported' })
      };
    }

    // ============================================
    // IMPORT LEADS TO DATABASE
    // ============================================
    if (action === 'import') {
      const { userId, teamId, leads } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      const leadsToInsert = leads.map(lead => ({
        user_id: userId,
        team_id: teamId,
        name: lead.name,
        status: 'new',
        source: lead.platform,
        source_url: lead.profile_url,
        notes: `${lead.bio || ''}\n\nFollowers: ${lead.followers || 'N/A'}`,
        instagram: lead.platform === 'instagram' ? lead.username : null,
        linkedin: lead.platform === 'linkedin' ? lead.username : null,
        tiktok: lead.platform === 'tiktok' ? lead.username : null
      }));

      const { data: inserted, error } = await supabase
        .from('leads')
        .insert(leadsToInsert)
        .select();

      if (error) throw error;

      // Log activities
      for (const lead of inserted) {
        await supabase.from('activities').insert({
          user_id: userId,
          team_id: teamId,
          lead_id: lead.id,
          type: 'lead_created',
          title: `Lead importiert: ${lead.name}`,
          metadata: { source: lead.source }
        });
      }

      // Increment usage
      await supabase.rpc('increment_usage', { p_user_id: userId, p_type: 'lead' });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ imported: inserted.length, leads: inserted })
      };
    }

    // ============================================
    // SEARCH ALL PLATFORMS
    // ============================================
    if (action === 'search-all') {
      const { userId, keyword, platforms = ['instagram', 'linkedin', 'tiktok'] } = data;

      const check = await checkAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      const results = {};
      const errors = {};

      // Search in parallel
      const searches = platforms.map(async (platform) => {
        try {
          const searchAction = `search-${platform}`;
          const response = await exports.handler({
            ...event,
            body: JSON.stringify({
              action: searchAction,
              data: { userId, keyword, limit: 5 }
            })
          });
          
          const body = JSON.parse(response.body);
          results[platform] = body.leads || [];
        } catch (err) {
          errors[platform] = err.message;
          results[platform] = [];
        }
      });

      await Promise.all(searches);

      // Combine and dedupe
      const allLeads = Object.values(results).flat();

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          leads: allLeads,
          byPlatform: results,
          errors: Object.keys(errors).length > 0 ? errors : undefined
        })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Lead Finder error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
