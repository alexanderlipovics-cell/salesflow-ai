// ============================================
// 💳 STRIPE BILLING - Netlify Function
// ============================================

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Price IDs from Stripe Dashboard
const PRICE_IDS = {
  pro_monthly: process.env.STRIPE_PRICE_PRO_MONTHLY,
  pro_yearly: process.env.STRIPE_PRICE_PRO_YEARLY,
  business_monthly: process.env.STRIPE_PRICE_BUSINESS_MONTHLY,
  business_yearly: process.env.STRIPE_PRICE_BUSINESS_YEARLY,
  enterprise_monthly: process.env.STRIPE_PRICE_ENTERPRISE_MONTHLY,
  enterprise_yearly: process.env.STRIPE_PRICE_ENTERPRISE_YEARLY,
};

const PLAN_MAP = {
  [process.env.STRIPE_PRICE_PRO_MONTHLY]: 'pro',
  [process.env.STRIPE_PRICE_PRO_YEARLY]: 'pro',
  [process.env.STRIPE_PRICE_BUSINESS_MONTHLY]: 'business',
  [process.env.STRIPE_PRICE_BUSINESS_YEARLY]: 'business',
  [process.env.STRIPE_PRICE_ENTERPRISE_MONTHLY]: 'enterprise',
  [process.env.STRIPE_PRICE_ENTERPRISE_YEARLY]: 'enterprise',
};

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CREATE CHECKOUT SESSION
    // ============================================
    if (action === 'create-checkout') {
      const { userId, email, priceKey, successUrl, cancelUrl } = data;

      // Get or create Stripe customer
      let customerId;
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('stripe_customer_id')
        .eq('user_id', userId)
        .single();

      if (sub?.stripe_customer_id) {
        customerId = sub.stripe_customer_id;
      } else {
        const customer = await stripe.customers.create({
          email,
          metadata: { userId }
        });
        customerId = customer.id;

        // Save customer ID
        await supabase
          .from('subscriptions')
          .upsert({
            user_id: userId,
            stripe_customer_id: customerId,
            plan: 'free',
            status: 'active'
          });
      }

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        line_items: [{
          price: PRICE_IDS[priceKey],
          quantity: 1,
        }],
        mode: 'subscription',
        success_url: successUrl || `${process.env.APP_URL}/settings?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: cancelUrl || `${process.env.APP_URL}/pricing`,
        metadata: { userId },
        subscription_data: {
          metadata: { userId }
        },
        allow_promotion_codes: true,
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ sessionId: session.id, url: session.url })
      };
    }

    // ============================================
    // CREATE CUSTOMER PORTAL
    // ============================================
    if (action === 'create-portal') {
      const { userId, returnUrl } = data;

      const { data: sub } = await supabase
        .from('subscriptions')
        .select('stripe_customer_id')
        .eq('user_id', userId)
        .single();

      if (!sub?.stripe_customer_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'No subscription found' })
        };
      }

      const session = await stripe.billingPortal.sessions.create({
        customer: sub.stripe_customer_id,
        return_url: returnUrl || `${process.env.APP_URL}/settings`,
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ url: session.url })
      };
    }

    // ============================================
    // GET SUBSCRIPTION STATUS
    // ============================================
    if (action === 'get-subscription') {
      const { userId } = data;

      const { data: sub } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', userId)
        .single();

      const { data: limits } = await supabase
        .from('plan_limits')
        .select('*')
        .eq('plan', sub?.plan || 'free')
        .single();

      const { data: usage } = await supabase
        .from('usage')
        .select('*')
        .eq('user_id', userId)
        .eq('month', new Date().toISOString().slice(0, 7))
        .single();

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          subscription: sub || { plan: 'free', status: 'active' },
          limits: limits || { max_leads: 50, max_ai_requests: 100, max_team_members: 1 },
          usage: usage || { ai_requests: 0, emails_sent: 0, whatsapp_sent: 0, leads_created: 0 }
        })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Stripe error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
