// ============================================
// 📊 REPORTING DASHBOARD - Netlify Function
// ============================================

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // DASHBOARD OVERVIEW
    // ============================================
    if (action === 'overview') {
      const { userId, teamId, period = '30d' } = data;

      const daysAgo = parseInt(period) || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      // Build base query
      const userFilter = teamId 
        ? `user_id.eq.${userId},team_id.eq.${teamId}`
        : `user_id.eq.${userId}`;

      // Total Leads
      const { count: totalLeads } = await supabase
        .from('leads')
        .select('*', { count: 'exact', head: true })
        .or(userFilter);

      // Leads by Status
      const { data: leadsByStatus } = await supabase
        .from('leads')
        .select('status')
        .or(userFilter);

      const statusCounts = {
        new: 0, hot: 0, warm: 0, cold: 0, customer: 0, partner: 0, lost: 0
      };
      leadsByStatus?.forEach(l => {
        statusCounts[l.status] = (statusCounts[l.status] || 0) + 1;
      });

      // New Leads in Period
      const { count: newLeads } = await supabase
        .from('leads')
        .select('*', { count: 'exact', head: true })
        .or(userFilter)
        .gte('created_at', startDate.toISOString());

      // Total Customers
      const { count: totalCustomers } = await supabase
        .from('customers')
        .select('*', { count: 'exact', head: true })
        .or(userFilter);

      // Total Partners
      const { count: totalPartners } = await supabase
        .from('partners')
        .select('*', { count: 'exact', head: true })
        .or(userFilter);

      // Pipeline Value
      const { data: pipelineData } = await supabase
        .from('leads')
        .select('deal_value, probability')
        .or(userFilter)
        .in('status', ['hot', 'warm', 'new']);

      const pipelineValue = pipelineData?.reduce((sum, l) => {
        return sum + (l.deal_value || 0);
      }, 0) || 0;

      const weightedPipeline = pipelineData?.reduce((sum, l) => {
        return sum + ((l.deal_value || 0) * (l.probability || 50) / 100);
      }, 0) || 0;

      // Conversion Rate
      const conversionRate = totalLeads > 0 
        ? ((totalCustomers + totalPartners) / totalLeads * 100).toFixed(1)
        : 0;

      // Activities in Period
      const { count: activitiesCount } = await supabase
        .from('activities')
        .select('*', { count: 'exact', head: true })
        .or(userFilter)
        .gte('created_at', startDate.toISOString());

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          overview: {
            totalLeads,
            newLeads,
            totalCustomers,
            totalPartners,
            pipelineValue,
            weightedPipeline,
            conversionRate: parseFloat(conversionRate),
            activitiesCount
          },
          byStatus: statusCounts,
          period: `${daysAgo} Tage`
        })
      };
    }

    // ============================================
    // LEAD FUNNEL
    // ============================================
    if (action === 'funnel') {
      const { userId, teamId, period = '30d' } = data;

      const daysAgo = parseInt(period) || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      const userFilter = teamId 
        ? `user_id.eq.${userId},team_id.eq.${teamId}`
        : `user_id.eq.${userId}`;

      // Get all activities for funnel
      const { data: activities } = await supabase
        .from('activities')
        .select('type, lead_id')
        .or(userFilter)
        .gte('created_at', startDate.toISOString());

      // Count stages
      const funnel = {
        leads_created: new Set(),
        contacted: new Set(),
        qualified: new Set(),
        proposal: new Set(),
        won: new Set(),
        lost: new Set()
      };

      activities?.forEach(a => {
        if (a.type === 'lead_created') funnel.leads_created.add(a.lead_id);
        if (['email_sent', 'whatsapp_sent', 'message_sent'].includes(a.type)) funnel.contacted.add(a.lead_id);
        if (a.type === 'status_changed') funnel.qualified.add(a.lead_id);
        if (a.type === 'deal_won') funnel.won.add(a.lead_id);
        if (a.type === 'deal_lost') funnel.lost.add(a.lead_id);
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          funnel: {
            leads_created: funnel.leads_created.size,
            contacted: funnel.contacted.size,
            qualified: funnel.qualified.size,
            won: funnel.won.size,
            lost: funnel.lost.size
          }
        })
      };
    }

    // ============================================
    // ACTIVITY TIMELINE
    // ============================================
    if (action === 'activity-timeline') {
      const { userId, teamId, days = 30 } = data;

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const userFilter = teamId 
        ? `user_id.eq.${userId},team_id.eq.${teamId}`
        : `user_id.eq.${userId}`;

      const { data: activities } = await supabase
        .from('activities')
        .select('created_at, type')
        .or(userFilter)
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: true });

      // Group by day
      const byDay = {};
      activities?.forEach(a => {
        const day = a.created_at.split('T')[0];
        if (!byDay[day]) {
          byDay[day] = { total: 0, byType: {} };
        }
        byDay[day].total++;
        byDay[day].byType[a.type] = (byDay[day].byType[a.type] || 0) + 1;
      });

      // Fill missing days
      const timeline = [];
      for (let d = new Date(startDate); d <= new Date(); d.setDate(d.getDate() + 1)) {
        const day = d.toISOString().split('T')[0];
        timeline.push({
          date: day,
          total: byDay[day]?.total || 0,
          byType: byDay[day]?.byType || {}
        });
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ timeline })
      };
    }

    // ============================================
    // TOP PERFORMERS
    // ============================================
    if (action === 'top-performers') {
      const { userId, teamId, period = '30d' } = data;

      const daysAgo = parseInt(period) || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      // Get all team members
      const { data: members } = await supabase
        .from('team_members')
        .select('user_id')
        .eq('team_id', teamId);

      if (!members || members.length === 0) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ performers: [] })
        };
      }

      const performers = [];

      for (const member of members) {
        // Get user info
        const { data: user } = await supabase.auth.admin.getUserById(member.user_id);

        // Count activities
        const { count: activities } = await supabase
          .from('activities')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', member.user_id)
          .gte('created_at', startDate.toISOString());

        // Count leads created
        const { count: leadsCreated } = await supabase
          .from('leads')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', member.user_id)
          .gte('created_at', startDate.toISOString());

        // Count conversions
        const { count: conversions } = await supabase
          .from('activities')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', member.user_id)
          .eq('type', 'deal_won')
          .gte('created_at', startDate.toISOString());

        performers.push({
          userId: member.user_id,
          name: user?.user?.user_metadata?.name || user?.user?.email,
          activities: activities || 0,
          leadsCreated: leadsCreated || 0,
          conversions: conversions || 0,
          score: (activities || 0) + (leadsCreated || 0) * 2 + (conversions || 0) * 10
        });
      }

      // Sort by score
      performers.sort((a, b) => b.score - a.score);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ performers: performers.slice(0, 10) })
      };
    }

    // ============================================
    // LEAD SOURCES
    // ============================================
    if (action === 'lead-sources') {
      const { userId, teamId } = data;

      const userFilter = teamId 
        ? `user_id.eq.${userId},team_id.eq.${teamId}`
        : `user_id.eq.${userId}`;

      const { data: leads } = await supabase
        .from('leads')
        .select('source, status, deal_value')
        .or(userFilter);

      const sources = {};
      leads?.forEach(l => {
        const source = l.source || 'Unbekannt';
        if (!sources[source]) {
          sources[source] = { count: 0, value: 0, converted: 0 };
        }
        sources[source].count++;
        sources[source].value += l.deal_value || 0;
        if (['customer', 'partner'].includes(l.status)) {
          sources[source].converted++;
        }
      });

      // Convert to array and sort
      const sourcesArray = Object.entries(sources)
        .map(([name, data]) => ({
          name,
          ...data,
          conversionRate: data.count > 0 ? (data.converted / data.count * 100).toFixed(1) : 0
        }))
        .sort((a, b) => b.count - a.count);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ sources: sourcesArray })
      };
    }

    // ============================================
    // GENERATE REPORT
    // ============================================
    if (action === 'generate') {
      const { userId, teamId, type = 'weekly', startDate, endDate } = data;

      // Calculate period
      let periodStart, periodEnd;
      const now = new Date();

      if (startDate && endDate) {
        periodStart = new Date(startDate);
        periodEnd = new Date(endDate);
      } else if (type === 'daily') {
        periodStart = new Date(now.setHours(0, 0, 0, 0));
        periodEnd = new Date();
      } else if (type === 'weekly') {
        periodStart = new Date(now.setDate(now.getDate() - 7));
        periodEnd = new Date();
      } else if (type === 'monthly') {
        periodStart = new Date(now.setMonth(now.getMonth() - 1));
        periodEnd = new Date();
      }

      // Gather all data
      const [overview, funnel, timeline, sources] = await Promise.all([
        getOverview(userId, teamId, periodStart),
        getFunnel(userId, teamId, periodStart),
        getTimeline(userId, teamId, periodStart),
        getSources(userId, teamId)
      ]);

      const reportData = {
        overview,
        funnel,
        timeline,
        sources,
        generatedAt: new Date().toISOString()
      };

      // Save report
      const { data: report, error } = await supabase
        .from('reports')
        .insert({
          user_id: userId,
          team_id: teamId,
          type,
          period_start: periodStart.toISOString().split('T')[0],
          period_end: periodEnd.toISOString().split('T')[0],
          data: reportData
        })
        .select()
        .single();

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ report })
      };
    }

    // ============================================
    // GET SAVED REPORTS
    // ============================================
    if (action === 'list-reports') {
      const { userId, teamId, limit = 20 } = data;

      const userFilter = teamId 
        ? `user_id.eq.${userId},team_id.eq.${teamId}`
        : `user_id.eq.${userId}`;

      const { data: reports, error } = await supabase
        .from('reports')
        .select('*')
        .or(userFilter)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ reports })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Reporting error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};

// Helper functions
async function getOverview(userId, teamId, startDate) {
  // Implementation same as 'overview' action
  return {};
}

async function getFunnel(userId, teamId, startDate) {
  // Implementation same as 'funnel' action
  return {};
}

async function getTimeline(userId, teamId, startDate) {
  // Implementation same as 'activity-timeline' action
  return [];
}

async function getSources(userId, teamId) {
  // Implementation same as 'lead-sources' action
  return [];
}
