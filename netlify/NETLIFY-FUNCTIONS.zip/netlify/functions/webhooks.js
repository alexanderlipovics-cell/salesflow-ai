// ============================================
// 🔗 WEBHOOK SYSTEM - Netlify Function
// ============================================

const { createClient } = require('@supabase/supabase-js');
const crypto = require('crypto');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK PLAN LIMITS
    // ============================================
    async function checkWebhookAccess(userId) {
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';
      
      if (plan === 'free' || plan === 'pro') {
        return { allowed: false, reason: 'Webhooks nur im Business Plan' };
      }

      return { allowed: true };
    }

    // ============================================
    // CREATE WEBHOOK
    // ============================================
    if (action === 'create') {
      const { userId, teamId, name, url, events } = data;

      const check = await checkWebhookAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      // Generate secret for signature verification
      const secret = crypto.randomBytes(32).toString('hex');

      const { data: webhook, error } = await supabase
        .from('webhooks')
        .insert({
          user_id: userId,
          team_id: teamId,
          name,
          url,
          secret,
          events,
          is_active: true
        })
        .select()
        .single();

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ webhook: { ...webhook, secret } })
      };
    }

    // ============================================
    // LIST WEBHOOKS
    // ============================================
    if (action === 'list') {
      const { userId, teamId } = data;

      let query = supabase
        .from('webhooks')
        .select('*')
        .order('created_at', { ascending: false });

      if (teamId) {
        query = query.or(`user_id.eq.${userId},team_id.eq.${teamId}`);
      } else {
        query = query.eq('user_id', userId);
      }

      const { data: webhooks, error } = await query;

      if (error) throw error;

      // Remove secrets from response
      const safeWebhooks = webhooks.map(w => ({ ...w, secret: undefined }));

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ webhooks: safeWebhooks })
      };
    }

    // ============================================
    // UPDATE WEBHOOK
    // ============================================
    if (action === 'update') {
      const { userId, webhookId, name, url, events, isActive } = data;

      const updates = {};
      if (name !== undefined) updates.name = name;
      if (url !== undefined) updates.url = url;
      if (events !== undefined) updates.events = events;
      if (isActive !== undefined) updates.is_active = isActive;

      const { data: webhook, error } = await supabase
        .from('webhooks')
        .update(updates)
        .eq('id', webhookId)
        .eq('user_id', userId)
        .select()
        .single();

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ webhook: { ...webhook, secret: undefined } })
      };
    }

    // ============================================
    // DELETE WEBHOOK
    // ============================================
    if (action === 'delete') {
      const { userId, webhookId } = data;

      const { error } = await supabase
        .from('webhooks')
        .delete()
        .eq('id', webhookId)
        .eq('user_id', userId);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    // ============================================
    // TEST WEBHOOK
    // ============================================
    if (action === 'test') {
      const { userId, webhookId } = data;

      const { data: webhook, error } = await supabase
        .from('webhooks')
        .select('*')
        .eq('id', webhookId)
        .eq('user_id', userId)
        .single();

      if (error || !webhook) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ error: 'Webhook nicht gefunden' })
        };
      }

      const testPayload = {
        event: 'test',
        timestamp: new Date().toISOString(),
        data: {
          message: 'This is a test webhook from SalesFlow AI'
        }
      };

      const result = await triggerWebhook(webhook, 'test', testPayload);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result)
      };
    }

    // ============================================
    // GET WEBHOOK LOGS
    // ============================================
    if (action === 'logs') {
      const { userId, webhookId, limit = 50 } = data;

      const { data: logs, error } = await supabase
        .from('webhook_logs')
        .select('*')
        .eq('webhook_id', webhookId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ logs })
      };
    }

    // ============================================
    // TRIGGER WEBHOOKS (Internal)
    // ============================================
    if (action === 'trigger') {
      const { eventType, payload, userId, teamId } = data;

      // Find all active webhooks for this event
      let query = supabase
        .from('webhooks')
        .select('*')
        .eq('is_active', true)
        .contains('events', [eventType]);

      if (teamId) {
        query = query.or(`user_id.eq.${userId},team_id.eq.${teamId}`);
      } else {
        query = query.eq('user_id', userId);
      }

      const { data: webhooks, error } = await query;

      if (error) throw error;

      const results = [];

      for (const webhook of webhooks) {
        const result = await triggerWebhook(webhook, eventType, payload);
        results.push({ webhookId: webhook.id, ...result });
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ triggered: results.length, results })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Webhook error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};

// ============================================
// HELPER: Trigger single webhook
// ============================================
async function triggerWebhook(webhook, eventType, payload) {
  const fullPayload = {
    event: eventType,
    timestamp: new Date().toISOString(),
    webhook_id: webhook.id,
    data: payload
  };

  // Create signature
  const signature = crypto
    .createHmac('sha256', webhook.secret)
    .update(JSON.stringify(fullPayload))
    .digest('hex');

  try {
    const response = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Signature': signature,
        'X-Webhook-Event': eventType
      },
      body: JSON.stringify(fullPayload)
    });

    const responseBody = await response.text();
    const success = response.ok;

    // Log the webhook call
    await supabase.from('webhook_logs').insert({
      webhook_id: webhook.id,
      event: eventType,
      payload: fullPayload,
      response_status: response.status,
      response_body: responseBody.slice(0, 1000),
      success
    });

    // Update webhook stats
    await supabase
      .from('webhooks')
      .update({
        last_triggered_at: new Date().toISOString(),
        success_count: success ? webhook.success_count + 1 : webhook.success_count,
        failure_count: success ? webhook.failure_count : webhook.failure_count + 1
      })
      .eq('id', webhook.id);

    return {
      success,
      status: response.status,
      response: responseBody.slice(0, 200)
    };

  } catch (err) {
    // Log failure
    await supabase.from('webhook_logs').insert({
      webhook_id: webhook.id,
      event: eventType,
      payload: fullPayload,
      success: false,
      error: err.message
    });

    await supabase
      .from('webhooks')
      .update({
        failure_count: webhook.failure_count + 1
      })
      .eq('id', webhook.id);

    return {
      success: false,
      error: err.message
    };
  }
}

// ============================================
// AVAILABLE EVENTS
// ============================================
/*
  - lead.created
  - lead.updated
  - lead.deleted
  - lead.status_changed
  - lead.converted (to customer)
  - customer.created
  - partner.created
  - email.sent
  - email.opened
  - whatsapp.sent
  - whatsapp.delivered
  - whatsapp.read
  - sequence.started
  - sequence.completed
  - deal.won
  - deal.lost
*/
