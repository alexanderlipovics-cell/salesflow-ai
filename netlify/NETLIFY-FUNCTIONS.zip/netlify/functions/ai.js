// ============================================
// 🌐 NEXUS STRATEGY V3.0 - Ultimate Multi-KI Router
// ============================================
// Claude Opus/Sonnet → Strategie, Einwände, Tonalität
// GPT-4o → Vision, Screenshots, Kreativ-Code
// Gemini → Live-Web-Recherche, aktuelle Daten
// DALL-E 3 → Bildgenerierung
// ============================================

const { createClient } = require('@supabase/supabase-js');

// Supabase Client
let supabase = null;
function getSupabase() {
  if (!supabase) {
    const url = process.env.SUPABASE_URL || 'https://kundmxztvhgyuvbkcqzi.supabase.co';
    const key = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;
    if (url && key) supabase = createClient(url, key);
  }
  return supabase;
}

exports.handler = async (event) => {
  const headers = { 
    'Access-Control-Allow-Origin': '*', 
    'Access-Control-Allow-Headers': 'Content-Type', 
    'Content-Type': 'application/json' 
  };
  
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  const startTime = Date.now();
  
  try {
    const { action, data, userId, leadId } = JSON.parse(event.body);
    
    // Alle API Keys
    const CLAUDE_KEY = process.env.ANTHROPIC_API_KEY;
    const OPENAI_KEY = process.env.OPENAI_API_KEY;
    const GEMINI_KEY = process.env.GEMINI_API_KEY;
    
    console.log(`[NEXUS] Action: ${action} | Keys: Claude=${!!CLAUDE_KEY} OpenAI=${!!OPENAI_KEY} Gemini=${!!GEMINI_KEY}`);

    let result;
    let engine;

    // ============================================
    // 🧭 INTELLIGENT ROUTING LOGIC
    // ============================================
    
    // 1. VISION & KREATIV → GPT-4o (beste Bildanalyse)
    if (action === 'scan_screenshot' || action === 'scan_screenshot_extended') {
      engine = 'GPT_VISION';
      result = OPENAI_KEY 
        ? await gpt4Vision(OPENAI_KEY, data, action === 'scan_screenshot_extended')
        : await claudeVision(CLAUDE_KEY, data, action === 'scan_screenshot_extended');
    }
    
    // 2. BILDGENERIERUNG → DALL-E 3 (einzige Option)
    else if (action === 'generate_image') {
      engine = 'DALLE';
      if (!OPENAI_KEY) throw new Error('OpenAI Key benötigt für Bildgenerierung');
      result = await dalleGenerate(OPENAI_KEY, data);
    }
    
    // 3. LIVE-WEB-RECHERCHE → Gemini (Google Search API!)
    else if (action === 'search_leads' || action === 'web_research' || action === 'market_research') {
      engine = 'GEMINI_SEARCH';
      if (GEMINI_KEY) {
        result = await geminiSearch(GEMINI_KEY, action, data);
      } else if (OPENAI_KEY) {
        result = await gpt4Search(OPENAI_KEY, data);
      } else {
        result = await claudeSearch(CLAUDE_KEY, data);
      }
    }
    
    // 4. SCHNELLE ANTWORTEN → GPT-4o Mini (3x faster)
    else if (action === 'quick_message' || action === 'simple_reply' || action === 'translate') {
      engine = 'GPT_MINI';
      result = OPENAI_KEY 
        ? await gpt4Mini(OPENAI_KEY, action, data)
        : await claudeFast(CLAUDE_KEY, action, data);
    }
    
    // 5. MULTI-PERSPEKTIVE EINWÄNDE → Alle 3 KIs!
    else if (action === 'objection_multi') {
      engine = 'MULTI_KI';
      result = await multiKiObjection(CLAUDE_KEY, OPENAI_KEY, GEMINI_KEY, data);
    }
    
    // 6. STRATEGIE & TONALITÄT → Claude (beste Qualität)
    else if (action === 'chat' || action === 'objection' || action === 'strategy' || action === 'analyze_lead') {
      engine = 'CLAUDE_STRATEGY';
      if (!CLAUDE_KEY) throw new Error('Anthropic Key benötigt');
      const leadContext = userId ? await loadLeadContext(userId, leadId) : null;
      result = await claudeStrategy(CLAUDE_KEY, action, data, leadContext);
    }
    
    // 7. LEAD-AWARE MESSAGES → Claude mit Supabase-Kontext
    else if (action === 'generate_message') {
      engine = 'CLAUDE_MESSAGE';
      if (!CLAUDE_KEY) throw new Error('Anthropic Key benötigt');
      const fullLead = userId ? await loadFullLead(userId, leadId || data.leadId) : null;
      result = await claudeMessage(CLAUDE_KEY, data, fullLead);
    }
    
    // DEFAULT → Claude
    else {
      engine = 'CLAUDE_DEFAULT';
      result = await claudeStrategy(CLAUDE_KEY, action, data, null);
    }
    
    const duration = Date.now() - startTime;
    console.log(`[NEXUS] ✓ ${action} | Engine: ${engine} | ${duration}ms`);
    
    return { 
      statusCode: 200, 
      headers, 
      body: JSON.stringify({ 
        success: true, 
        result, 
        engine: result?.engine || engine, 
        duration 
      }) 
    };
    
  } catch (error) {
    console.error('[NEXUS] ERROR:', error.message);
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) };
  }
};

// ============================================
// 🔮 GEMINI - Live Web Search (Google's Stärke!)
// ============================================
async function geminiSearch(apiKey, action, data) {
  const isLeadSearch = action === 'search_leads';
  
  // Gemini 1.5 Pro mit Grounding (Web Search)
  const systemPrompt = isLeadSearch
    ? `Du bist ein Lead-Recherche-Experte. Suche nach echten ${data.platform || 'Social Media'} Profilen.
       Keyword: "${data.keyword}"
       
       Finde 5-10 ECHTE Profile mit:
       - Vollständiger Name
       - Username/Handle
       - Follower-Anzahl (geschätzt wenn nicht sichtbar)
       - Kurze Bio/Beschreibung
       - Geschätzter DISG-Typ (D/I/S/G)
       - Lead-Score (1-100)
       
       JSON Array zurückgeben: [{name, username, followers, bio, disg, score, source}]`
    : `Recherchiere zum Thema: "${data.query || data.keyword}"
       Gib aktuelle, verifizierte Informationen.`;

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ 
        parts: [{ text: systemPrompt }] 
      }],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 2000
      },
      // Grounding mit Google Search (wenn verfügbar)
      tools: [{
        googleSearchRetrieval: {
          dynamicRetrievalConfig: {
            mode: "MODE_DYNAMIC",
            dynamicThreshold: 0.3
          }
        }
      }]
    })
  });

  const result = await response.json();
  
  if (result.error) {
    console.error('[GEMINI] Error:', result.error);
    throw new Error(result.error.message || 'Gemini API Fehler');
  }

  let parsed = result.candidates?.[0]?.content?.parts?.[0]?.text || '';
  
  // Parse JSON from response
  try {
    const match = parsed.match(/\[[\s\S]*\]/);
    if (match) parsed = JSON.parse(match[0]);
  } catch (e) {}

  return { 
    data: parsed, 
    engine: 'gemini-1.5-pro',
    grounded: true,
    source: 'Google Search'
  };
}

// ============================================
// 🎯 MULTI-KI EINWAND-KILLER (Premium Feature!)
// ============================================
async function multiKiObjection(claudeKey, openaiKey, geminiKey, data) {
  const objection = data.objection;
  
  const results = await Promise.allSettled([
    // Claude: Logisch & Strategisch
    claudeKey ? callClaudeObjection(claudeKey, objection, 'logisch') : null,
    // GPT-4o: Kreativ & Provokant
    openaiKey ? callGptObjection(openaiKey, objection, 'provokant') : null,
    // Gemini: Fakten-basiert mit Web-Recherche
    geminiKey ? callGeminiObjection(geminiKey, objection, 'fakten') : null
  ]);

  return {
    data: {
      logic: results[0]?.value?.data || 'Claude nicht verfügbar',
      creative: results[1]?.value?.data || 'GPT nicht verfügbar',
      facts: results[2]?.value?.data || 'Gemini nicht verfügbar'
    },
    engine: 'multi-ki',
    sources: ['claude', 'gpt-4o', 'gemini'].filter((_, i) => results[i]?.status === 'fulfilled')
  };
}

async function callClaudeObjection(apiKey, objection, style) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 150,
      system: `Einwand-Experte. Gib eine ${style}e Antwort (2-3 Sätze). Nur die Antwort, keine Erklärung.`,
      messages: [{ role: 'user', content: `Einwand: "${objection}"` }]
    })
  });
  const result = await response.json();
  return { data: result.content?.[0]?.text };
}

async function callGptObjection(apiKey, objection, style) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'gpt-4o',
      max_tokens: 150,
      messages: [
        { role: 'system', content: `Einwand-Experte. Gib eine ${style}e, mutige Antwort (2-3 Sätze).` },
        { role: 'user', content: `Einwand: "${objection}"` }
      ]
    })
  });
  const result = await response.json();
  return { data: result.choices?.[0]?.message?.content };
}

async function callGeminiObjection(apiKey, objection, style) {
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: `Einwand: "${objection}"\n\nGib eine ${style}-basierte Antwort mit aktuellen Daten (2-3 Sätze).` }] }],
      generationConfig: { maxOutputTokens: 150 }
    })
  });
  const result = await response.json();
  return { data: result.candidates?.[0]?.content?.parts?.[0]?.text };
}

// ============================================
// 🔷 CLAUDE - Strategy & Tonality (Best Quality)
// ============================================
async function claudeStrategy(apiKey, action, data, leadContext) {
  let systemPrompt = '';
  let messages = [];
  let maxTokens = 500;

  // WICHTIG: Kein Markdown verwenden!
  const noMarkdownRule = `

FORMATIERUNG: Antworte OHNE Markdown. Keine Sternchen, keine Rauten, keine Listen mit * oder -. Schreibe normalen Fließtext.`;

  if (action === 'chat') {
    // Build context from both sources
    let contextBlock = '';
    
    // SPECIFIC LEAD referenced by user (via @Name, #lead:Name, etc.)
    if (data.specificLead) {
      const sl = data.specificLead;
      const daysSince = sl.last_contact 
        ? Math.floor((Date.now() - new Date(sl.last_contact)) / (24*60*60*1000))
        : 'unbekannt';
      
      contextBlock = `
=== AKTUELL BESPROCHENER LEAD ===
Name: ${sl.name}
Status: ${sl.status?.toUpperCase() || 'WARM'}
DISG-Typ: ${sl.disg || 'Unbekannt'}
Deal-Wert: €${sl.deal_value || 150}
Letzter Kontakt: vor ${daysSince} Tagen
Email: ${sl.email || '-'}
Telefon: ${sl.phone || '-'}
Notizen: ${sl.notes || 'Keine'}
Tags: ${sl.tags || '-'}

Der User fragt SPEZIELL über diesen Lead. Beziehe dich in deiner Antwort direkt auf ${sl.name}.
`;
    }
    
    // From Supabase (via AI-Cloud-Bridge)
    if (leadContext) {
      contextBlock += `\n=== LEAD-DATENBANK ===\n${leadContext.leads}\n(${leadContext.hotCount} Hot, ${leadContext.warmCount} Warm)`;
    }
    
    // From Frontend (full context with ALL leads)
    if (data.context) {
      contextBlock += `\n${data.context.slice(0, 3000)}`;
    }
    
    if (data.knowledge) {
      contextBlock += `\n=== WISSEN ===\n${data.knowledge.slice(0, 500)}`;
    }
    
    systemPrompt = `Du bist ein erfahrener Sales-Coach für Network Marketing.

${contextBlock}

WICHTIGE REGELN:
1. Du hast Zugriff auf die ECHTEN Lead-Daten oben - NUTZE SIE AKTIV!
2. Wenn der User nach Leads fragt, nenne die KONKRETEN NAMEN aus der Liste.
3. Wenn der User "gib mir Leads" sagt, liste die relevanten Leads MIT NAMEN auf.
4. Priorisiere: Überfällige zuerst, dann Hot, dann Warm.
5. Gib konkrete Handlungsempfehlungen für SPEZIFISCHE Leads.
6. Wenn ein AKTUELL BESPROCHENER LEAD oben steht, beziehe dich direkt auf diese Person.
7. Antworte präzise und handlungsorientiert.

BEISPIEL-ANTWORT wenn User nach Leads fragt:
"Diese Leads solltest du heute kontaktieren:

1. [Name aus Liste] - Hot, X Tage überfällig - Kurzer Check-in
2. [Name aus Liste] - Warm, X Tage - Mehrwert-Nachricht senden
3. [Name aus Liste] - Cold, reaktivieren mit Angebot

Soll ich dir Nachrichten für einen davon schreiben?"

${noMarkdownRule}`;
    
    messages = data.messages || [{ role: 'user', content: data.message }];
    maxTokens = 600;
  }
  
  else if (action === 'objection') {
    systemPrompt = `Einwand-Experte. Gib 3 kurze Antworten (je 1-2 Sätze):
1. LOGISCH - Fakten-basiert
2. EMOTIONAL - Gefühls-basiert
3. PROVOKANT - Mutig/direkt

Antworte als JSON: {"logic":"...", "emotion":"...", "provoke":"..."}
Keine Sternchen oder Formatierung in den Antworten!`;
    messages = [{ role: 'user', content: `Einwand: "${data.objection}"` }];
    maxTokens = 300;
  }
  
  else if (action === 'strategy') {
    let leadsInfo = '';
    if (leadContext) leadsInfo = `\nLeads:\n${leadContext.leads}`;
    if (data.context) leadsInfo += `\n${data.context.slice(0, 1500)}`;
    
    systemPrompt = `Vertriebs-Stratege. Gib eine klare Analyse und konkrete nächste Schritte.${leadsInfo}${noMarkdownRule}`;
    messages = [{ role: 'user', content: data.message || data.question }];
    maxTokens = 400;
  }
  
  else if (action === 'analyze_lead') {
    systemPrompt = `Lead-Analyse. Gib kurz:
- Potenzial (1-10)
- DISG-Typ (wenn erkennbar)
- Beste Ansprache (1 Satz)
- Nächste Aktion (1 Satz)
${noMarkdownRule}`;
    messages = [{ role: 'user', content: JSON.stringify(data.lead || data).slice(0, 800) }];
    maxTokens = 200;
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: maxTokens, system: systemPrompt, messages })
  });

  const result = await response.json();
  if (result.error) throw new Error(result.error.message);

  let parsed = result.content[0].text;
  
  // Clean any remaining markdown
  if (typeof parsed === 'string') {
    parsed = parsed
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/_([^_]+)_/g, '$1')
      .replace(/^#{1,6}\s*/gm, '')
      .replace(/^[\*\-]\s+/gm, '• ');
  }
  
  if (action === 'objection') {
    try { 
      const match = parsed.match(/\{[\s\S]*\}/); 
      if (match) parsed = JSON.parse(match[0]); 
    } catch (e) {}
  }

  return { data: parsed, engine: 'claude-sonnet', hasContext: !!leadContext };
}

// ============================================
// 📝 CLAUDE MESSAGE - Lead-Aware
// ============================================
async function claudeMessage(apiKey, data, fullLead) {
  let leadInfo = '';
  
  if (fullLead) {
    const daysSince = fullLead.last_contact 
      ? Math.floor((Date.now() - new Date(fullLead.last_contact)) / (24*60*60*1000)) : null;
    
    leadInfo = `
LEAD-DETAILS:
- Name: ${fullLead.name}
- Status: ${fullLead.status?.toUpperCase()} ${fullLead.status === 'hot' ? '🔥' : fullLead.status === 'warm' ? '🌤️' : '🥶'}
- DISG: ${fullLead.disg || '?'}
- Letzter Kontakt: ${daysSince !== null ? daysSince + ' Tage' : 'Nie'}
- Deal: €${fullLead.deal_value || 0}
- Notizen: ${fullLead.notes || '-'}`;
  }
  
  const systemPrompt = `WhatsApp-Nachricht schreiben. Max 4 Zeilen. Persönlich.
${leadInfo}
${fullLead?.disg === 'D' ? 'D-Typ: Direkt, kurz' : fullLead?.disg === 'I' ? 'I-Typ: Enthusiastisch' : fullLead?.disg === 'S' ? 'S-Typ: Freundlich, sicher' : fullLead?.disg === 'G' ? 'G-Typ: Fakten' : ''}`;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ 
      model: 'claude-sonnet-4-20250514', max_tokens: 200, system: systemPrompt,
      messages: [{ role: 'user', content: data.prompt || 'Schreibe eine Follow-up Nachricht.' }]
    })
  });

  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  return { data: result.content[0].text, engine: 'claude-sonnet', leadAware: !!fullLead };
}

// ============================================
// ⚡ GPT-4o MINI - 3x Faster!
// ============================================
async function gpt4Mini(apiKey, action, data) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      max_tokens: 150,
      messages: [
        { role: 'system', content: 'Kurze, hilfreiche Antworten. Max 50 Wörter.' },
        { role: 'user', content: data.message || data.prompt }
      ]
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  return { data: result.choices[0].message.content, engine: 'gpt-4o-mini' };
}

async function claudeFast(apiKey, action, data) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ 
      model: 'claude-sonnet-4-20250514', max_tokens: 150,
      system: 'Kurze Antwort. Max 50 Wörter.',
      messages: [{ role: 'user', content: data.message || data.prompt }]
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  return { data: result.content[0].text, engine: 'claude-fast' };
}

// ============================================
// 👁️ GPT-4o VISION
// ============================================
async function gpt4Vision(apiKey, data, extended) {
  const systemPrompt = extended 
    ? `Analysiere das Bild. Extrahiere alle Personen: Name, DISG-Typ (D/I/S/G), Follower, Link. JSON Array.`
    : `Extrahiere alle Namen. JSON: ["Name1", "Name2"]`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'gpt-4o',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: systemPrompt },
          { type: 'image_url', image_url: { url: `data:${data.media_type || 'image/png'};base64,${data.image}` } }
        ]
      }]
    })
  });

  const result = await response.json();
  if (result.error) throw new Error(result.error.message);

  let parsed = result.choices[0].message.content;
  try { const match = parsed.match(/\[[\s\S]*\]/); if (match) parsed = JSON.parse(match[0]); } catch (e) {}
  return { data: parsed, engine: 'gpt-4o-vision' };
}

async function claudeVision(apiKey, data, extended) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ 
      model: 'claude-sonnet-4-20250514', max_tokens: 1000,
      system: extended ? 'Extrahiere Personen: Name, DISG, Follower, Link. JSON Array.' : 'Extrahiere Namen. JSON Array.',
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: data.media_type || 'image/png', data: data.image } },
          { type: 'text', text: 'Analysiere.' }
        ]
      }]
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  let parsed = result.content[0].text;
  try { const match = parsed.match(/\[[\s\S]*\]/); if (match) parsed = JSON.parse(match[0]); } catch (e) {}
  return { data: parsed, engine: 'claude-vision' };
}

// ============================================
// 🎨 DALL-E 3
// ============================================
async function dalleGenerate(apiKey, data) {
  const response = await fetch('https://api.openai.com/v1/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'dall-e-3', prompt: data.prompt, n: 1,
      size: data.size || '1024x1024', quality: data.quality || 'standard'
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  return { url: result.data[0].url, engine: 'dall-e-3' };
}

// ============================================
// 🔍 Search Fallbacks
// ============================================
async function gpt4Search(apiKey, data) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'gpt-4o', max_tokens: 1000,
      messages: [
        { role: 'system', content: `Generiere 5 Profile für ${data.platform}. Keyword: ${data.keyword}. JSON Array.` },
        { role: 'user', content: 'Generiere.' }
      ]
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  let parsed = result.choices[0].message.content;
  try { const match = parsed.match(/\[[\s\S]*\]/); if (match) parsed = JSON.parse(match[0]); } catch (e) {}
  return { data: parsed, engine: 'gpt-4o' };
}

async function claudeSearch(apiKey, data) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ 
      model: 'claude-sonnet-4-20250514', max_tokens: 1000,
      system: `Generiere 5 Profile für ${data.platform}. Keyword: ${data.keyword}. JSON Array.`,
      messages: [{ role: 'user', content: 'Generiere.' }]
    })
  });
  const result = await response.json();
  if (result.error) throw new Error(result.error.message);
  let parsed = result.content[0].text;
  try { const match = parsed.match(/\[[\s\S]*\]/); if (match) parsed = JSON.parse(match[0]); } catch (e) {}
  return { data: parsed, engine: 'claude' };
}

// ============================================
// 📊 SUPABASE BRIDGE
// ============================================
async function loadLeadContext(userId, leadId) {
  const sb = getSupabase();
  if (!sb) return null;
  
  try {
    const { data: leads } = await sb
      .from('leads')
      .select('id, name, status, disg, deal_value, notes, last_contact')
      .eq('user_id', userId)
      .order('status', { ascending: true })
      .limit(10);
    
    if (!leads?.length) return null;
    
    const context = leads.map(l => {
      const days = l.last_contact ? Math.floor((Date.now() - new Date(l.last_contact)) / 86400000) : '?';
      return `• ${l.name} [${l.status?.toUpperCase()}] ${l.disg || ''} | ${days}d | €${l.deal_value || 0}`;
    }).join('\n');
    
    return {
      leads: context,
      hotCount: leads.filter(l => l.status === 'hot').length,
      warmCount: leads.filter(l => l.status === 'warm').length
    };
  } catch (e) { return null; }
}

async function loadFullLead(userId, leadId) {
  if (!leadId) return null;
  const sb = getSupabase();
  if (!sb) return null;
  try {
    const { data } = await sb.from('leads').select('*').eq('id', leadId).eq('user_id', userId).single();
    return data;
  } catch (e) { return null; }
}
