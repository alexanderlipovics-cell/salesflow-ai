// ============================================
// 📧 EMAIL SERVICE - Netlify Function (Resend)
// ============================================

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@salesflow.ai';

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK PLAN LIMITS
    // ============================================
    async function checkEmailLimit(userId) {
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';
      
      if (plan === 'free') {
        return { allowed: false, reason: 'Email nicht im Free Plan verfügbar' };
      }

      return { allowed: true };
    }

    // ============================================
    // SEND SINGLE EMAIL
    // ============================================
    if (action === 'send') {
      const { userId, to, subject, body, leadId, templateId } = data;

      // Check limits
      const limitCheck = await checkEmailLimit(userId);
      if (!limitCheck.allowed) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: limitCheck.reason })
        };
      }

      // Send via Resend
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: FROM_EMAIL,
          to: [to],
          subject,
          html: body.replace(/\n/g, '<br>'),
          tags: [
            { name: 'userId', value: userId },
            { name: 'leadId', value: leadId || 'none' }
          ]
        })
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Email sending failed');
      }

      // Log to database
      await supabase.from('emails_sent').insert({
        user_id: userId,
        lead_id: leadId,
        template_id: templateId,
        to_email: to,
        subject,
        body,
        message_id: result.id,
        status: 'sent'
      });

      // Log activity
      if (leadId) {
        await supabase.from('activities').insert({
          user_id: userId,
          lead_id: leadId,
          type: 'email_sent',
          title: `Email gesendet: ${subject}`,
          metadata: { to, subject, message_id: result.id }
        });
      }

      // Increment usage
      await supabase.rpc('increment_usage', { p_user_id: userId, p_type: 'email' });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, messageId: result.id })
      };
    }

    // ============================================
    // SEND BULK EMAILS
    // ============================================
    if (action === 'send-bulk') {
      const { userId, emails } = data;

      // Check limits
      const limitCheck = await checkEmailLimit(userId);
      if (!limitCheck.allowed) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: limitCheck.reason })
        };
      }

      const results = [];

      for (const email of emails) {
        try {
          const response = await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${RESEND_API_KEY}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              from: FROM_EMAIL,
              to: [email.to],
              subject: email.subject,
              html: email.body.replace(/\n/g, '<br>')
            })
          });

          const result = await response.json();

          await supabase.from('emails_sent').insert({
            user_id: userId,
            lead_id: email.leadId,
            to_email: email.to,
            subject: email.subject,
            body: email.body,
            message_id: result.id,
            status: response.ok ? 'sent' : 'failed'
          });

          results.push({ to: email.to, success: response.ok, messageId: result.id });

          // Rate limiting: 2 emails per second
          await new Promise(r => setTimeout(r, 500));

        } catch (err) {
          results.push({ to: email.to, success: false, error: err.message });
        }
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ results })
      };
    }

    // ============================================
    // GET EMAIL TEMPLATES
    // ============================================
    if (action === 'get-templates') {
      const { userId, teamId } = data;

      let query = supabase
        .from('email_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (teamId) {
        query = query.or(`user_id.eq.${userId},team_id.eq.${teamId}`);
      } else {
        query = query.eq('user_id', userId);
      }

      const { data: templates, error } = await query;

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ templates })
      };
    }

    // ============================================
    // SAVE EMAIL TEMPLATE
    // ============================================
    if (action === 'save-template') {
      const { userId, teamId, name, subject, body, category } = data;

      const { data: template, error } = await supabase
        .from('email_templates')
        .insert({
          user_id: userId,
          team_id: teamId,
          name,
          subject,
          body,
          category
        })
        .select()
        .single();

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ template })
      };
    }

    // ============================================
    // GET EMAIL HISTORY
    // ============================================
    if (action === 'get-history') {
      const { userId, leadId, limit = 50 } = data;

      let query = supabase
        .from('emails_sent')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (leadId) {
        query = query.eq('lead_id', leadId);
      }

      const { data: emails, error } = await query;

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ emails })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Email error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
