// ============================================
// ⏰ CRON JOB HANDLER - Netlify Scheduled Function
// Processes automated sequences every 15 minutes
// ============================================

const { schedule } = require('@netlify/functions');

// This runs every 15 minutes
const handler = async (event) => {
  console.log('[CRON] Starting sequence processor...');

  try {
    // Call the sequences function to process due actions
    const response = await fetch(`${process.env.URL}/.netlify/functions/sequences`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'process',
        data: {}
      })
    });

    const result = await response.json();
    console.log(`[CRON] Processed ${result.processed || 0} sequence actions`);

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'Cron job completed',
        processed: result.processed || 0
      })
    };

  } catch (error) {
    console.error('[CRON] Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};

// Run every 15 minutes
exports.handler = schedule('*/15 * * * *', handler);
