// ============================================
// 🔄 SEQUENCE ENGINE - Netlify Function
// Automated Follow-up Sequences
// ============================================

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK PLAN LIMITS
    // ============================================
    async function checkSequenceAccess(userId) {
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';
      
      if (plan === 'free' || plan === 'pro') {
        return { allowed: false, reason: 'Automatische Sequenzen nur im Business Plan' };
      }

      return { allowed: true };
    }

    // ============================================
    // CREATE SEQUENCE
    // ============================================
    if (action === 'create') {
      const { userId, teamId, name, description, triggerType, triggerConfig, steps } = data;

      const check = await checkSequenceAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      // Create sequence
      const { data: sequence, error: seqError } = await supabase
        .from('sequences')
        .insert({
          user_id: userId,
          team_id: teamId,
          name,
          description,
          trigger_type: triggerType,
          trigger_config: triggerConfig || {}
        })
        .select()
        .single();

      if (seqError) throw seqError;

      // Create steps
      if (steps && steps.length > 0) {
        const stepsToInsert = steps.map((step, index) => ({
          sequence_id: sequence.id,
          step_order: index + 1,
          delay_days: step.delayDays || 0,
          delay_hours: step.delayHours || 0,
          action_type: step.actionType,
          action_config: step.actionConfig,
          condition_type: step.conditionType || 'always'
        }));

        const { error: stepsError } = await supabase
          .from('sequence_steps')
          .insert(stepsToInsert);

        if (stepsError) throw stepsError;
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ sequence })
      };
    }

    // ============================================
    // GET ALL SEQUENCES
    // ============================================
    if (action === 'list') {
      const { userId, teamId } = data;

      let query = supabase
        .from('sequences')
        .select(`
          *,
          sequence_steps (*)
        `)
        .order('created_at', { ascending: false });

      if (teamId) {
        query = query.or(`user_id.eq.${userId},team_id.eq.${teamId}`);
      } else {
        query = query.eq('user_id', userId);
      }

      const { data: sequences, error } = await query;

      if (error) throw error;

      // Count enrollments per sequence
      for (const seq of sequences) {
        const { count } = await supabase
          .from('sequence_enrollments')
          .select('*', { count: 'exact', head: true })
          .eq('sequence_id', seq.id)
          .eq('status', 'active');

        seq.active_enrollments = count || 0;
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ sequences })
      };
    }

    // ============================================
    // ENROLL LEAD IN SEQUENCE
    // ============================================
    if (action === 'enroll') {
      const { userId, sequenceId, leadId } = data;

      const check = await checkSequenceAccess(userId);
      if (!check.allowed) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: check.reason }) };
      }

      // Get first step
      const { data: firstStep } = await supabase
        .from('sequence_steps')
        .select('*')
        .eq('sequence_id', sequenceId)
        .eq('step_order', 1)
        .single();

      // Calculate next action time
      const nextAction = new Date();
      if (firstStep) {
        nextAction.setDate(nextAction.getDate() + (firstStep.delay_days || 0));
        nextAction.setHours(nextAction.getHours() + (firstStep.delay_hours || 0));
      }

      const { data: enrollment, error } = await supabase
        .from('sequence_enrollments')
        .upsert({
          sequence_id: sequenceId,
          lead_id: leadId,
          current_step: 0,
          status: 'active',
          next_action_at: nextAction.toISOString()
        }, {
          onConflict: 'sequence_id,lead_id'
        })
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabase.from('activities').insert({
        user_id: userId,
        lead_id: leadId,
        type: 'sequence_started',
        title: 'In Sequenz eingeschrieben',
        metadata: { sequence_id: sequenceId }
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ enrollment })
      };
    }

    // ============================================
    // STOP ENROLLMENT
    // ============================================
    if (action === 'stop') {
      const { userId, enrollmentId, leadId, sequenceId } = data;

      let query = supabase
        .from('sequence_enrollments')
        .update({ status: 'stopped' });

      if (enrollmentId) {
        query = query.eq('id', enrollmentId);
      } else if (leadId && sequenceId) {
        query = query.eq('lead_id', leadId).eq('sequence_id', sequenceId);
      }

      const { error } = await query;

      if (error) throw error;

      // Log activity
      if (leadId) {
        await supabase.from('activities').insert({
          user_id: userId,
          lead_id: leadId,
          type: 'sequence_stopped',
          title: 'Sequenz gestoppt',
          metadata: { sequence_id: sequenceId }
        });
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    // ============================================
    // PROCESS DUE ACTIONS (Called by Cron)
    // ============================================
    if (action === 'process') {
      // Get all due enrollments
      const { data: dueEnrollments, error } = await supabase
        .from('sequence_enrollments')
        .select(`
          *,
          sequences (*),
          leads (*)
        `)
        .eq('status', 'active')
        .lte('next_action_at', new Date().toISOString())
        .limit(100);

      if (error) throw error;

      const results = [];

      for (const enrollment of dueEnrollments) {
        try {
          // Get current step
          const { data: step } = await supabase
            .from('sequence_steps')
            .select('*')
            .eq('sequence_id', enrollment.sequence_id)
            .eq('step_order', enrollment.current_step + 1)
            .single();

          if (!step) {
            // No more steps - mark as completed
            await supabase
              .from('sequence_enrollments')
              .update({ 
                status: 'completed',
                completed_at: new Date().toISOString()
              })
              .eq('id', enrollment.id);

            results.push({ enrollmentId: enrollment.id, status: 'completed' });
            continue;
          }

          // Execute action based on type
          let actionResult = { success: true };

          if (step.action_type === 'email' && enrollment.leads?.email) {
            // Trigger email function
            const emailResponse = await fetch(`${process.env.URL}/.netlify/functions/email`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'send',
                data: {
                  userId: enrollment.sequences.user_id,
                  to: enrollment.leads.email,
                  subject: step.action_config.subject,
                  body: step.action_config.body.replace('{name}', enrollment.leads.name),
                  leadId: enrollment.lead_id
                }
              })
            });
            actionResult = await emailResponse.json();
          }

          if (step.action_type === 'whatsapp' && enrollment.leads?.phone) {
            const waResponse = await fetch(`${process.env.URL}/.netlify/functions/whatsapp`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'send',
                data: {
                  userId: enrollment.sequences.user_id,
                  to: enrollment.leads.phone,
                  message: step.action_config.message.replace('{name}', enrollment.leads.name),
                  leadId: enrollment.lead_id
                }
              })
            });
            actionResult = await waResponse.json();
          }

          if (step.action_type === 'status_change') {
            await supabase
              .from('leads')
              .update({ status: step.action_config.new_status })
              .eq('id', enrollment.lead_id);
          }

          if (step.action_type === 'tag_add') {
            const { data: lead } = await supabase
              .from('leads')
              .select('tags')
              .eq('id', enrollment.lead_id)
              .single();

            const newTags = [...(lead?.tags || []), step.action_config.tag];
            await supabase
              .from('leads')
              .update({ tags: newTags })
              .eq('id', enrollment.lead_id);
          }

          if (step.action_type === 'webhook') {
            await fetch(step.action_config.url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                event: 'sequence_step',
                lead: enrollment.leads,
                step: step.step_order
              })
            });
          }

          // Get next step
          const { data: nextStep } = await supabase
            .from('sequence_steps')
            .select('*')
            .eq('sequence_id', enrollment.sequence_id)
            .eq('step_order', enrollment.current_step + 2)
            .single();

          // Calculate next action time
          let nextActionAt = null;
          if (nextStep) {
            const next = new Date();
            next.setDate(next.getDate() + (nextStep.delay_days || 0));
            next.setHours(next.getHours() + (nextStep.delay_hours || 0));
            nextActionAt = next.toISOString();
          }

          // Update enrollment
          await supabase
            .from('sequence_enrollments')
            .update({
              current_step: enrollment.current_step + 1,
              next_action_at: nextActionAt,
              status: nextStep ? 'active' : 'completed',
              completed_at: nextStep ? null : new Date().toISOString()
            })
            .eq('id', enrollment.id);

          results.push({ 
            enrollmentId: enrollment.id, 
            step: enrollment.current_step + 1,
            action: step.action_type,
            success: actionResult.success 
          });

        } catch (err) {
          console.error(`Error processing enrollment ${enrollment.id}:`, err);
          results.push({ enrollmentId: enrollment.id, error: err.message });
        }
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ processed: results.length, results })
      };
    }

    // ============================================
    // GET SEQUENCE TEMPLATES
    // ============================================
    if (action === 'get-templates') {
      const templates = [
        {
          name: '7-Tage Follow-up',
          description: 'Klassische Follow-up Sequenz über 7 Tage',
          steps: [
            { delayDays: 0, actionType: 'email', actionConfig: { subject: 'Schön, dass wir uns kennengelernt haben!', body: 'Hey {name}...' } },
            { delayDays: 2, actionType: 'email', actionConfig: { subject: 'Kurze Frage...', body: 'Hey {name}...' } },
            { delayDays: 5, actionType: 'email', actionConfig: { subject: 'Ist das Thema noch aktuell?', body: 'Hey {name}...' } },
            { delayDays: 7, actionType: 'status_change', actionConfig: { new_status: 'cold' } }
          ]
        },
        {
          name: 'WhatsApp Aktivierung',
          description: '3-Tage WhatsApp Sequenz für schnelle Aktivierung',
          steps: [
            { delayDays: 0, delayHours: 2, actionType: 'whatsapp', actionConfig: { message: 'Hey {name}! Kurz und knapp...' } },
            { delayDays: 1, actionType: 'whatsapp', actionConfig: { message: 'Hey {name}, hast du kurz geschaut?' } },
            { delayDays: 3, actionType: 'whatsapp', actionConfig: { message: 'Hey {name}, letzte Frage...' } }
          ]
        },
        {
          name: 'Kunden-Onboarding',
          description: 'Willkommens-Sequenz für neue Kunden',
          steps: [
            { delayDays: 0, actionType: 'email', actionConfig: { subject: 'Willkommen im Team!', body: '...' } },
            { delayDays: 3, actionType: 'email', actionConfig: { subject: 'Dein erster Schritt', body: '...' } },
            { delayDays: 7, actionType: 'whatsapp', actionConfig: { message: 'Hey {name}, wie läufts?' } },
            { delayDays: 14, actionType: 'tag_add', actionConfig: { tag: 'onboarded' } }
          ]
        }
      ];

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ templates })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Sequence error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
