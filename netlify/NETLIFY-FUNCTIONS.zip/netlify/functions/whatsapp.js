// ============================================
// 📱 WHATSAPP CLOUD API - Netlify Function
// ============================================

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// WhatsApp Business API Config
const WHATSAPP_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const WHATSAPP_PHONE_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const WHATSAPP_API_VERSION = 'v17.0';
const WHATSAPP_API_URL = `https://graph.facebook.com/${WHATSAPP_API_VERSION}/${WHATSAPP_PHONE_ID}/messages`;

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK PLAN LIMITS
    // ============================================
    async function checkWhatsAppLimit(userId) {
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';
      
      if (plan === 'free' || plan === 'pro') {
        return { allowed: false, reason: 'WhatsApp nur im Business Plan verfügbar' };
      }

      return { allowed: true };
    }

    // ============================================
    // FORMAT PHONE NUMBER
    // ============================================
    function formatPhone(phone) {
      // Remove all non-digits
      let clean = phone.replace(/\D/g, '');
      
      // Add country code if missing (default: Germany +49)
      if (clean.startsWith('0')) {
        clean = '49' + clean.slice(1);
      } else if (!clean.startsWith('49') && clean.length < 12) {
        clean = '49' + clean;
      }
      
      return clean;
    }

    // ============================================
    // SEND TEXT MESSAGE
    // ============================================
    if (action === 'send') {
      const { userId, to, message, leadId } = data;

      // Check limits
      const limitCheck = await checkWhatsAppLimit(userId);
      if (!limitCheck.allowed) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: limitCheck.reason })
        };
      }

      if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_ID) {
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({ error: 'WhatsApp nicht konfiguriert' })
        };
      }

      const phone = formatPhone(to);

      const response = await fetch(WHATSAPP_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: phone,
          type: 'text',
          text: { body: message }
        })
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error?.message || 'WhatsApp sending failed');
      }

      const wamid = result.messages?.[0]?.id;

      // Log to database
      await supabase.from('whatsapp_messages').insert({
        user_id: userId,
        lead_id: leadId,
        to_phone: phone,
        message,
        wamid,
        status: 'sent'
      });

      // Log activity
      if (leadId) {
        await supabase.from('activities').insert({
          user_id: userId,
          lead_id: leadId,
          type: 'whatsapp_sent',
          title: 'WhatsApp gesendet',
          metadata: { to: phone, wamid, preview: message.slice(0, 50) }
        });
      }

      // Increment usage
      await supabase.rpc('increment_usage', { p_user_id: userId, p_type: 'whatsapp' });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, wamid })
      };
    }

    // ============================================
    // SEND TEMPLATE MESSAGE
    // ============================================
    if (action === 'send-template') {
      const { userId, to, templateName, templateParams, leadId } = data;

      const limitCheck = await checkWhatsAppLimit(userId);
      if (!limitCheck.allowed) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: limitCheck.reason })
        };
      }

      const phone = formatPhone(to);

      // Build template components
      const components = [];
      if (templateParams?.body) {
        components.push({
          type: 'body',
          parameters: templateParams.body.map(text => ({ type: 'text', text }))
        });
      }

      const response = await fetch(WHATSAPP_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: phone,
          type: 'template',
          template: {
            name: templateName,
            language: { code: 'de' },
            components
          }
        })
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error?.message || 'Template sending failed');
      }

      const wamid = result.messages?.[0]?.id;

      await supabase.from('whatsapp_messages').insert({
        user_id: userId,
        lead_id: leadId,
        to_phone: phone,
        message: `[Template: ${templateName}]`,
        template_name: templateName,
        wamid,
        status: 'sent'
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, wamid })
      };
    }

    // ============================================
    // SEND BULK MESSAGES
    // ============================================
    if (action === 'send-bulk') {
      const { userId, messages } = data;

      const limitCheck = await checkWhatsAppLimit(userId);
      if (!limitCheck.allowed) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: limitCheck.reason })
        };
      }

      const results = [];

      for (const msg of messages) {
        try {
          const phone = formatPhone(msg.to);

          const response = await fetch(WHATSAPP_API_URL, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              messaging_product: 'whatsapp',
              recipient_type: 'individual',
              to: phone,
              type: 'text',
              text: { body: msg.message }
            })
          });

          const result = await response.json();
          const wamid = result.messages?.[0]?.id;

          await supabase.from('whatsapp_messages').insert({
            user_id: userId,
            lead_id: msg.leadId,
            to_phone: phone,
            message: msg.message,
            wamid,
            status: response.ok ? 'sent' : 'failed'
          });

          results.push({ to: phone, success: response.ok, wamid });

          // Rate limiting: 1 message per second (WhatsApp limit)
          await new Promise(r => setTimeout(r, 1000));

        } catch (err) {
          results.push({ to: msg.to, success: false, error: err.message });
        }
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ results })
      };
    }

    // ============================================
    // GET MESSAGE HISTORY
    // ============================================
    if (action === 'get-history') {
      const { userId, leadId, limit = 50 } = data;

      let query = supabase
        .from('whatsapp_messages')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (leadId) {
        query = query.eq('lead_id', leadId);
      }

      const { data: messages, error } = await query;

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ messages })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('WhatsApp error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
