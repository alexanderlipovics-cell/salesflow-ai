// ============================================
// 🔔 STRIPE WEBHOOK - Netlify Function
// ============================================

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const PLAN_MAP = {
  [process.env.STRIPE_PRICE_PRO_MONTHLY]: 'pro',
  [process.env.STRIPE_PRICE_PRO_YEARLY]: 'pro',
  [process.env.STRIPE_PRICE_BUSINESS_MONTHLY]: 'business',
  [process.env.STRIPE_PRICE_BUSINESS_YEARLY]: 'business',
  [process.env.STRIPE_PRICE_ENTERPRISE_MONTHLY]: 'enterprise',
  [process.env.STRIPE_PRICE_ENTERPRISE_YEARLY]: 'enterprise',
};

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      webhookSecret
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  const { type, data } = stripeEvent;

  console.log(`[Stripe Webhook] ${type}`);

  try {
    switch (type) {
      // ============================================
      // SUBSCRIPTION CREATED
      // ============================================
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = data.object;
        const customerId = subscription.customer;
        const priceId = subscription.items.data[0]?.price.id;
        const plan = PLAN_MAP[priceId] || 'pro';

        // Find user by customer ID
        const { data: existingSub } = await supabase
          .from('subscriptions')
          .select('user_id')
          .eq('stripe_customer_id', customerId)
          .single();

        if (existingSub) {
          await supabase
            .from('subscriptions')
            .update({
              stripe_subscription_id: subscription.id,
              plan,
              status: subscription.status === 'active' ? 'active' : 
                      subscription.status === 'trialing' ? 'trialing' :
                      subscription.status === 'past_due' ? 'past_due' : 'canceled',
              current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
              current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
              cancel_at_period_end: subscription.cancel_at_period_end,
              updated_at: new Date().toISOString()
            })
            .eq('stripe_customer_id', customerId);

          console.log(`[Stripe] Updated subscription for customer ${customerId} to ${plan}`);
        }
        break;
      }

      // ============================================
      // SUBSCRIPTION DELETED
      // ============================================
      case 'customer.subscription.deleted': {
        const subscription = data.object;
        const customerId = subscription.customer;

        await supabase
          .from('subscriptions')
          .update({
            plan: 'free',
            status: 'canceled',
            stripe_subscription_id: null,
            updated_at: new Date().toISOString()
          })
          .eq('stripe_customer_id', customerId);

        console.log(`[Stripe] Subscription canceled for customer ${customerId}`);
        break;
      }

      // ============================================
      // PAYMENT SUCCEEDED
      // ============================================
      case 'invoice.payment_succeeded': {
        const invoice = data.object;
        console.log(`[Stripe] Payment succeeded for invoice ${invoice.id}`);
        break;
      }

      // ============================================
      // PAYMENT FAILED
      // ============================================
      case 'invoice.payment_failed': {
        const invoice = data.object;
        const customerId = invoice.customer;

        await supabase
          .from('subscriptions')
          .update({
            status: 'past_due',
            updated_at: new Date().toISOString()
          })
          .eq('stripe_customer_id', customerId);

        console.log(`[Stripe] Payment failed for customer ${customerId}`);
        // TODO: Send email notification
        break;
      }

      default:
        console.log(`[Stripe] Unhandled event type: ${type}`);
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) };

  } catch (error) {
    console.error('Webhook handler error:', error);
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
