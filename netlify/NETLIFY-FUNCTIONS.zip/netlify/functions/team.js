// ============================================
// 👥 TEAM MANAGEMENT - Netlify Function
// ============================================

const { createClient } = require('@supabase/supabase-js');
const crypto = require('crypto');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { action, data } = JSON.parse(event.body);

    // ============================================
    // CHECK TEAM LIMITS
    // ============================================
    async function checkTeamLimits(userId) {
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .single();

      const plan = sub?.plan || 'free';

      const { data: limits } = await supabase
        .from('plan_limits')
        .select('max_team_members')
        .eq('plan', plan)
        .single();

      return { plan, maxMembers: limits?.max_team_members || 1 };
    }

    // ============================================
    // CREATE TEAM
    // ============================================
    if (action === 'create') {
      const { userId, name } = data;

      // Check if user already has a team
      const { data: existingTeam } = await supabase
        .from('teams')
        .select('id')
        .eq('owner_id', userId)
        .single();

      if (existingTeam) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Du hast bereits ein Team' })
        };
      }

      // Create team
      const { data: team, error: teamError } = await supabase
        .from('teams')
        .insert({
          name,
          owner_id: userId
        })
        .select()
        .single();

      if (teamError) throw teamError;

      // Add owner as member
      const { error: memberError } = await supabase
        .from('team_members')
        .insert({
          team_id: team.id,
          user_id: userId,
          role: 'owner'
        });

      if (memberError) throw memberError;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ team })
      };
    }

    // ============================================
    // GET MY TEAM
    // ============================================
    if (action === 'get') {
      const { userId } = data;

      // Get team where user is member
      const { data: membership } = await supabase
        .from('team_members')
        .select(`
          role,
          teams (
            id,
            name,
            owner_id,
            created_at
          )
        `)
        .eq('user_id', userId)
        .single();

      if (!membership) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ team: null })
        };
      }

      // Get all members
      const { data: members } = await supabase
        .from('team_members')
        .select(`
          id,
          role,
          joined_at,
          user_id
        `)
        .eq('team_id', membership.teams.id);

      // Get user details for members
      const memberDetails = [];
      for (const member of members) {
        const { data: user } = await supabase.auth.admin.getUserById(member.user_id);
        memberDetails.push({
          ...member,
          email: user?.user?.email,
          name: user?.user?.user_metadata?.name
        });
      }

      // Get pending invites
      const { data: invites } = await supabase
        .from('team_invites')
        .select('*')
        .eq('team_id', membership.teams.id)
        .is('accepted_at', null)
        .gt('expires_at', new Date().toISOString());

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          team: membership.teams,
          myRole: membership.role,
          members: memberDetails,
          invites
        })
      };
    }

    // ============================================
    // INVITE MEMBER
    // ============================================
    if (action === 'invite') {
      const { userId, teamId, email, role = 'member' } = data;

      // Check permissions
      const { data: membership } = await supabase
        .from('team_members')
        .select('role')
        .eq('team_id', teamId)
        .eq('user_id', userId)
        .single();

      if (!membership || !['owner', 'admin'].includes(membership.role)) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Keine Berechtigung' })
        };
      }

      // Check limits
      const limits = await checkTeamLimits(userId);
      const { count: currentMembers } = await supabase
        .from('team_members')
        .select('*', { count: 'exact', head: true })
        .eq('team_id', teamId);

      if (limits.maxMembers > 0 && currentMembers >= limits.maxMembers) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ 
            error: `Dein Plan erlaubt maximal ${limits.maxMembers} Team-Mitglieder. Upgrade auf einen höheren Plan.` 
          })
        };
      }

      // Check if already invited
      const { data: existingInvite } = await supabase
        .from('team_invites')
        .select('id')
        .eq('team_id', teamId)
        .eq('email', email)
        .is('accepted_at', null)
        .single();

      if (existingInvite) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Diese Email wurde bereits eingeladen' })
        };
      }

      // Create invite
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      const { data: invite, error } = await supabase
        .from('team_invites')
        .insert({
          team_id: teamId,
          email,
          role,
          invited_by: userId,
          token,
          expires_at: expiresAt.toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      // TODO: Send invite email
      const inviteUrl = `${process.env.APP_URL}/invite/${token}`;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ invite, inviteUrl })
      };
    }

    // ============================================
    // ACCEPT INVITE
    // ============================================
    if (action === 'accept-invite') {
      const { userId, token } = data;

      // Find invite
      const { data: invite, error: findError } = await supabase
        .from('team_invites')
        .select('*')
        .eq('token', token)
        .is('accepted_at', null)
        .gt('expires_at', new Date().toISOString())
        .single();

      if (findError || !invite) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ error: 'Einladung nicht gefunden oder abgelaufen' })
        };
      }

      // Add to team
      const { error: memberError } = await supabase
        .from('team_members')
        .insert({
          team_id: invite.team_id,
          user_id: userId,
          role: invite.role,
          invited_by: invite.invited_by
        });

      if (memberError) throw memberError;

      // Mark invite as accepted
      await supabase
        .from('team_invites')
        .update({ accepted_at: new Date().toISOString() })
        .eq('id', invite.id);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, teamId: invite.team_id })
      };
    }

    // ============================================
    // REMOVE MEMBER
    // ============================================
    if (action === 'remove-member') {
      const { userId, teamId, memberId } = data;

      // Check permissions
      const { data: membership } = await supabase
        .from('team_members')
        .select('role')
        .eq('team_id', teamId)
        .eq('user_id', userId)
        .single();

      if (!membership || !['owner', 'admin'].includes(membership.role)) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Keine Berechtigung' })
        };
      }

      // Can't remove owner
      const { data: targetMember } = await supabase
        .from('team_members')
        .select('role')
        .eq('id', memberId)
        .single();

      if (targetMember?.role === 'owner') {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Owner kann nicht entfernt werden' })
        };
      }

      const { error } = await supabase
        .from('team_members')
        .delete()
        .eq('id', memberId);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    // ============================================
    // UPDATE MEMBER ROLE
    // ============================================
    if (action === 'update-role') {
      const { userId, teamId, memberId, newRole } = data;

      // Check permissions (only owner can change roles)
      const { data: membership } = await supabase
        .from('team_members')
        .select('role')
        .eq('team_id', teamId)
        .eq('user_id', userId)
        .single();

      if (!membership || membership.role !== 'owner') {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Nur der Owner kann Rollen ändern' })
        };
      }

      const { error } = await supabase
        .from('team_members')
        .update({ role: newRole })
        .eq('id', memberId);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    // ============================================
    // LEAVE TEAM
    // ============================================
    if (action === 'leave') {
      const { userId, teamId } = data;

      // Check if owner (can't leave)
      const { data: membership } = await supabase
        .from('team_members')
        .select('role')
        .eq('team_id', teamId)
        .eq('user_id', userId)
        .single();

      if (membership?.role === 'owner') {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Owner muss das Team übertragen oder löschen' })
        };
      }

      const { error } = await supabase
        .from('team_members')
        .delete()
        .eq('team_id', teamId)
        .eq('user_id', userId);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    // ============================================
    // DELETE TEAM
    // ============================================
    if (action === 'delete') {
      const { userId, teamId } = data;

      // Check if owner
      const { data: team } = await supabase
        .from('teams')
        .select('owner_id')
        .eq('id', teamId)
        .single();

      if (team?.owner_id !== userId) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Nur der Owner kann das Team löschen' })
        };
      }

      // Delete team (cascades to members and invites)
      const { error } = await supabase
        .from('teams')
        .delete()
        .eq('id', teamId);

      if (error) throw error;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unknown action' })
    };

  } catch (error) {
    console.error('Team error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
