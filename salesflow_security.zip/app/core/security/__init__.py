"""
Security Module for SalesFlow AI.

Exports all security components for easy import.
"""

# JWT
from app.core.security.jwt import (
    TokenType,
    TokenPayload,
    TokenPair,
    TokenBlacklist,
    token_blacklist,
    JWTError,
    TokenExpiredError,
    TokenInvalidError,
    TokenBlacklistedError,
    TokenFamilyCompromisedError,
    create_access_token,
    create_refresh_token,
    create_token_pair,
    decode_access_token,
    decode_refresh_token,
    rotate_refresh_token,
    revoke_token,
    revoke_all_user_tokens,
    get_token_fingerprint,
)

# Password
from app.core.security.password import (
    PasswordValidationError,
    PasswordPolicy,
    LoginAttemptTracker,
    login_tracker,
    get_password_policy,
    validate_password,
    validate_password_strength,
    hash_password,
    verify_password,
    generate_password,
    generate_reset_token,
    verify_reset_token,
    check_password_breach,
)

# Sanitization
from app.core.security.sanitization import (
    SanitizationError,
    SanitizationConfig,
    sanitize_string,
    sanitize_dict,
    sanitize_list,
    sanitize_for_log,
    sanitize_email,
    sanitize_url,
    sanitize_filename,
    sanitize_model,
    sanitize_input,
    LogSanitizingFilter,
    check_sql_injection,
    check_path_traversal,
)

# Encryption
from app.core.security.encryption import (
    EncryptionError,
    DecryptionError,
    FieldEncryptor,
    get_encryptor,
    encrypt_field,
    decrypt_field,
    encrypt_deterministic,
    mask_field,
    mask_email,
    mask_phone,
    EncryptedField,
    generate_encryption_key,
    rotate_encryption_key,
)

__all__ = [
    # JWT
    "TokenType",
    "TokenPayload",
    "TokenPair",
    "TokenBlacklist",
    "token_blacklist",
    "JWTError",
    "TokenExpiredError",
    "TokenInvalidError",
    "TokenBlacklistedError",
    "TokenFamilyCompromisedError",
    "create_access_token",
    "create_refresh_token",
    "create_token_pair",
    "decode_access_token",
    "decode_refresh_token",
    "rotate_refresh_token",
    "revoke_token",
    "revoke_all_user_tokens",
    "get_token_fingerprint",
    
    # Password
    "PasswordValidationError",
    "PasswordPolicy",
    "LoginAttemptTracker",
    "login_tracker",
    "get_password_policy",
    "validate_password",
    "validate_password_strength",
    "hash_password",
    "verify_password",
    "generate_password",
    "generate_reset_token",
    "verify_reset_token",
    "check_password_breach",
    
    # Sanitization
    "SanitizationError",
    "SanitizationConfig",
    "sanitize_string",
    "sanitize_dict",
    "sanitize_list",
    "sanitize_for_log",
    "sanitize_email",
    "sanitize_url",
    "sanitize_filename",
    "sanitize_model",
    "sanitize_input",
    "LogSanitizingFilter",
    "check_sql_injection",
    "check_path_traversal",
    
    # Encryption
    "EncryptionError",
    "DecryptionError",
    "FieldEncryptor",
    "get_encryptor",
    "encrypt_field",
    "decrypt_field",
    "encrypt_deterministic",
    "mask_field",
    "mask_email",
    "mask_phone",
    "EncryptedField",
    "generate_encryption_key",
    "rotate_encryption_key",
]
